"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Sparkles, X, Scan, Send, Check, Settings2 } from "lucide-react";
import {
  type AiContext, type AiMode, type AiPlan, callAnthropic, callLocal, callOpenAiCompatible, checkPrint, describeAction, explainOffline,
  extractJson, localModelLoaded, parseRuleCommand, systemPrompt, userPrompt, validatePlan, webGpuAvailable,
} from "@/lib/aiActions";
import { AI_PRESETS, AI_SETTINGS_EVENT, LOCAL_MODELS, readAiSettings, usesCloud, writeAiSettings, type AiSettings } from "@/lib/aiSettings";

export type AiArea = { ids: string[]; snapshot?: string };

type Props = {
  onClose: () => void;
  selectionCount: number;
  getContext: (area: AiArea | null) => AiContext;
  getOverhangs: (ids: string[]) => Promise<{ id: string; area: number }[]>;
  /** Runs the plan as one undo step; never runs anything but the whitelisted actions. */
  applyPlan: (plan: AiPlan) => Promise<{ ok: boolean; message: string }>;
  /** Preview text for smart arrange: how many plates the layout needs. */
  describeArrange: (ids: string[]) => string;
};

type Entry = { who: "user" | "ai"; text: string };

const CHIPS: { mode: AiMode; label: string; hint: string }[] = [
  { mode: "model", label: "Text to model", hint: "e.g. make a 20mm cube, then fillet 2mm" },
  { mode: "check", label: "Check my print", hint: "Looks for overhangs, thin walls, off-plate and floating parts" },
  { mode: "explain", label: "Explain", hint: "What is this and how is it built?" },
  { mode: "arrange", label: "Smart arrange", hint: "Spread the parts across the build plates" },
];

function backendLabel(s: AiSettings) {
  if (usesCloud(s)) return AI_PRESETS.find((p) => p.baseUrl === s.baseUrl)?.label ?? "Your API";
  if (localModelLoaded(s.localModel)) return "On-device";
  return webGpuAvailable() ? "On-device (not loaded)" : "Simple commands";
}

function cropDataUrl(full: string, rect: { left: number; top: number; right: number; bottom: number }): Promise<string | undefined> {
  const canvas = Array.from(document.querySelectorAll("canvas")).sort((a, b) => b.clientWidth * b.clientHeight - a.clientWidth * a.clientHeight)[0];
  if (!canvas) return Promise.resolve(undefined);
  const box = canvas.getBoundingClientRect();
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const sx = img.width / box.width, sy = img.height / box.height;
      const w = Math.max(1, (rect.right - rect.left) * sx), h = Math.max(1, (rect.bottom - rect.top) * sy);
      const scale = Math.min(1, 768 / Math.max(w, h));
      const out = document.createElement("canvas");
      out.width = Math.round(w * scale); out.height = Math.round(h * scale);
      out.getContext("2d")?.drawImage(img, (rect.left - box.left) * sx, (rect.top - box.top) * sy, w, h, 0, 0, out.width, out.height);
      resolve(out.toDataURL("image/png"));
    };
    img.onerror = () => resolve(undefined);
    img.src = full;
  });
}

export function AiPanel({ onClose, selectionCount, getContext, getOverhangs, applyPlan, describeArrange }: Props) {
  const [settings, setSettings] = useState<AiSettings>(() => readAiSettings());
  const [mode, setMode] = useState<AiMode>("model");
  const [text, setText] = useState("");
  const [log, setLog] = useState<Entry[]>([]);
  const [plan, setPlan] = useState<AiPlan | null>(null);
  const [busy, setBusy] = useState(false);
  const [area, setArea] = useState<AiArea | null>(null);
  const [picking, setPicking] = useState(false);
  const [drag, setDrag] = useState<{ x0: number; y0: number; x1: number; y1: number } | null>(null);
  const [consent, setConsent] = useState<{ text: string; mode: AiMode } | null>(null);
  const [progress, setProgress] = useState<{ progress: number; text: string } | null>(null);
  const logRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const read = () => setSettings(readAiSettings());
    window.addEventListener(AI_SETTINGS_EVENT, read);
    return () => window.removeEventListener(AI_SETTINGS_EVENT, read);
  }, []);
  useEffect(() => { logRef.current?.scrollTo({ top: logRef.current.scrollHeight }); }, [log, plan, progress]);

  const say = (who: Entry["who"], t: string) => setLog((l) => [...l.slice(-30), { who, text: t }]);

  const callModel = useCallback(async (prompt: string, m: AiMode, ctx: AiContext): Promise<AiPlan> => {
    const sys = systemPrompt(m);
    const usr = userPrompt(prompt, ctx);
    let answer: string;
    if (usesCloud(settings)) {
      answer = settings.provider === "anthropic"
        ? await callAnthropic(settings, sys, usr, ctx.snapshot)
        : await callOpenAiCompatible(settings, sys, usr, ctx.snapshot);
    } else {
      answer = await callLocal(settings.localModel, sys, usr, (p) => setProgress(p));
      setProgress(null);
    }
    const json = extractJson(answer);
    if (!json) return { summary: "", actions: [], reply: answer.slice(0, 2000) };
    return validatePlan(json, ctx);
  }, [settings]);

  const run = useCallback(async (prompt: string, m: AiMode, consented = false) => {
    if (busy) return;
    setBusy(true);
    setPlan(null);
    try {
      const ctx = getContext(area);
      const ids = ctx.shapes.map((s) => s.id);
      if (m === "check") {
        const p = checkPrint(ctx, await getOverhangs(ids).catch(() => []));
        say("ai", p.findings!.map((f) => `${f.level === "warn" ? "⚠" : "ℹ"} ${f.text}`).join("\n"));
        if (p.actions.length) setPlan(p);
        return;
      }
      if (m === "arrange") {
        if (ids.length === 0) { say("ai", "There is nothing to arrange yet."); return; }
        const names = new Map(ctx.allShapes.map((s) => [s.id, s.name]));
        const p: AiPlan = { summary: describeArrange(ids), actions: [{ op: "arrange_plates", ids }] };
        p.summary = `${describeAction(p.actions[0], names)}. ${p.summary}`;
        setPlan(p);
        return;
      }
      const cloud = usesCloud(settings);
      if (m === "model" && !cloud) {
        const ruled = parseRuleCommand(prompt, ctx);
        if (ruled && ruled.actions.length) { setPlan(ruled); return; }
      }
      if (!cloud) {
        const canLocal = webGpuAvailable();
        if (!canLocal) {
          say("ai", m === "explain" ? explainOffline(ctx) : "I can only follow simple commands on this device (no WebGPU), like “make a 20mm cube”, “move it left 10mm”, “rotate 45”, “make it red”, “fillet 2mm”, “duplicate”, “align left”, “delete”. Add your own API key in Settings › AI for anything more.");
          return;
        }
        if (!localModelLoaded(settings.localModel) && !settings.localConsent && !consented) {
          if (m === "explain") say("ai", explainOffline(ctx));
          setConsent({ text: prompt, mode: m });
          return;
        }
      }
      const p = await callModel(prompt, m, ctx);
      if (p.reply) say("ai", p.reply);
      if (p.actions.length) setPlan(p);
      else if (!p.reply) say("ai", "I could not turn that into changes. Try saying it another way.");
      if (p.warnings?.length) say("ai", p.warnings.join("\n"));
    } catch (error) {
      setProgress(null);
      say("ai", error instanceof Error ? error.message : String(error));
    } finally {
      setBusy(false);
    }
  }, [area, busy, callModel, describeArrange, getContext, getOverhangs, settings]);

  const submit = () => {
    const prompt = text.trim();
    if (!prompt && mode === "model") return;
    say("user", prompt || CHIPS.find((c) => c.mode === mode)!.label);
    setText("");
    void run(prompt || CHIPS.find((c) => c.mode === mode)!.label, mode);
  };

  const pickChip = (m: AiMode) => {
    setMode(m);
    if (m === "check" || m === "arrange" || m === "explain") {
      say("user", CHIPS.find((c) => c.mode === m)!.label);
      void run(m === "explain" ? "Explain what this is and how it is built." : "", m);
    }
  };

  const apply = async () => {
    if (!plan) return;
    setBusy(true);
    const result = await applyPlan(plan);
    setBusy(false);
    say("ai", result.ok ? `✓ ${result.message} (one undo step)` : result.message);
    setPlan(null);
  };

  const finishPick = async (d: { x0: number; y0: number; x1: number; y1: number }) => {
    const rect = { left: Math.min(d.x0, d.x1), top: Math.min(d.y0, d.y1), right: Math.max(d.x0, d.x1), bottom: Math.max(d.y0, d.y1) };
    setPicking(false); setDrag(null);
    if (rect.right - rect.left < 8 || rect.bottom - rect.top < 8) return;
    const ids = window.layerlingShapesInClientRect?.(rect) ?? [];
    let snapshot: string | undefined;
    try { const full = window.layerlingCaptureCanvas?.(); if (full) snapshot = await cropDataUrl(full, rect); } catch { /* no picture */ }
    setArea({ ids, snapshot });
  };

  const names = new Map(getContext(area).allShapes.map((s) => [s.id, s.name]));
  const ctxLabel = area ? `Area: ${area.ids.length} object${area.ids.length === 1 ? "" : "s"}` : selectionCount ? `${selectionCount} selected` : "Whole scene";

  return (
    <>
      {picking ? (
        <div
          className="ai-area-overlay"
          data-testid="ai-area-overlay"
          onPointerDown={(e) => { (e.target as HTMLElement).setPointerCapture?.(e.pointerId); setDrag({ x0: e.clientX, y0: e.clientY, x1: e.clientX, y1: e.clientY }); }}
          onPointerMove={(e) => setDrag((d) => (d ? { ...d, x1: e.clientX, y1: e.clientY } : d))}
          onPointerUp={() => { if (drag) void finishPick(drag); }}
        >
          <div className="ai-area-hint">Drag a box over the part you mean <button type="button" onClick={(e) => { e.stopPropagation(); setPicking(false); }} onPointerDown={(e) => e.stopPropagation()}>Cancel</button></div>
          {drag ? <div className="ai-area-rect" style={{ left: Math.min(drag.x0, drag.x1), top: Math.min(drag.y0, drag.y1), width: Math.abs(drag.x1 - drag.x0), height: Math.abs(drag.y1 - drag.y0) }} /> : null}
        </div>
      ) : null}
      <section className="ai-panel" data-testid="ai-panel" aria-label="AI helper" style={picking ? { display: "none" } : undefined}>
        <header className="ai-head">
          <Sparkles aria-hidden="true" size={16} />
          <strong>AI helper</strong>
          <span className="ai-backend" data-testid="ai-backend">{backendLabel(settings)}</span>
          <button type="button" className="ai-icon" title="AI settings" aria-label="AI settings" onClick={() => window.dispatchEvent(new CustomEvent("layerling:open-workspace-settings", { detail: { section: "ai" } }))}><Settings2 size={15} /></button>
          <button type="button" className="ai-icon" title="Close" aria-label="Close AI helper" onClick={onClose}><X size={16} /></button>
        </header>
        <div className="ai-chips" role="tablist">
          {CHIPS.map((c) => (
            <button key={c.mode} type="button" role="tab" aria-selected={mode === c.mode} className={mode === c.mode ? "active" : ""} title={c.hint} data-testid={`ai-chip-${c.mode}`} onClick={() => pickChip(c.mode)}>{c.label}</button>
          ))}
        </div>
        <div className="ai-context">
          {area?.snapshot ? <img src={area.snapshot} alt="Selected area" className="ai-thumb" /> : null}
          <span data-testid="ai-context">{ctxLabel}</span>
          <button type="button" data-testid="ai-select-area" onClick={() => setPicking(true)}><Scan size={13} /> Select area</button>
          {area ? <button type="button" onClick={() => setArea(null)}>Clear</button> : null}
        </div>
        {log.length || plan || consent || progress ? (
          <div className="ai-log" ref={logRef}>
            {log.map((e, i) => <div key={i} className={`ai-msg ${e.who}`}>{e.text}</div>)}
            {consent ? (
              <div className="ai-card" data-testid="ai-consent">
                <p>Run AI on this device for free? It downloads <b>{LOCAL_MODELS.find((m) => m.id === settings.localModel)?.label ?? settings.localModel}</b> (about {((LOCAL_MODELS.find((m) => m.id === settings.localModel)?.downloadMb ?? 1000) / 1000).toFixed(1)} GB) once; your browser keeps it. Nothing you type leaves the device.</p>
                <div className="ai-row">
                  <button type="button" className="primary" onClick={() => { const c = consent; setConsent(null); writeAiSettings({ ...settings, localConsent: true }); void run(c.text, c.mode, true); }}>Download &amp; run</button>
                  <button type="button" onClick={() => { setConsent(null); say("ai", "OK - I'll stick to simple commands like “make a 20mm cube”."); }}>Not now</button>
                </div>
              </div>
            ) : null}
            {progress ? (
              <div className="ai-card" data-testid="ai-progress">
                <div className="ai-progress"><span style={{ width: `${Math.round(progress.progress * 100)}%` }} /></div>
                <small>{progress.text}</small>
              </div>
            ) : null}
            {plan ? (
              <div className="ai-card ai-preview" data-testid="ai-preview">
                <b>Preview</b>
                <ol>{plan.actions.map((a, i) => <li key={i}>{describeAction(a, names)}</li>)}</ol>
                {plan.warnings?.length ? <small>{plan.warnings.join(" ")}</small> : null}
                <div className="ai-row">
                  <button type="button" className="primary" data-testid="ai-apply" disabled={busy} onClick={() => void apply()}><Check size={14} /> Apply</button>
                  <button type="button" data-testid="ai-cancel" onClick={() => { setPlan(null); say("ai", "Cancelled - nothing changed."); }}>Cancel</button>
                </div>
              </div>
            ) : null}
          </div>
        ) : null}
        <form className="ai-input" onSubmit={(e) => { e.preventDefault(); submit(); }}>
          <textarea
            rows={1}
            value={text}
            data-testid="ai-input"
            placeholder={CHIPS.find((c) => c.mode === mode)!.hint}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(); } e.stopPropagation(); }}
          />
          <button type="submit" className="ai-send" aria-label="Send" disabled={busy} data-testid="ai-send">{busy ? <span className="ai-spin" /> : <Send size={15} />}</button>
        </form>
      </section>
    </>
  );
}

import * as THREE from "three";
import { drawXrayGhost, xrayGhostState } from "./xrayGhosts";
const xrayGhostTickActive = () => xrayGhostState() !== null;
const ghostCenter = new THREE.Vector3(0, 0, 0);
let ghostCenterAge = 1000;
let depthOnlyMaterial: THREE.MeshBasicMaterial | null = null;
function depthOnly() { return (depthOnlyMaterial ??= new THREE.MeshBasicMaterial({ colorWrite: false, side: THREE.DoubleSide })); }
import type { ThreeState } from "@/components/workplane/ViewportOverlays";
import { RENDER_LAYER_SHAPES } from "@/components/workplane/viewportPicking";

/** What drawing one frame needs: the main view's state, or the second view's camera on the same scene. */
export type FrameState = Pick<ThreeState, "renderer" | "scene" | "camera" | "shapeRecords" | "sectionPlane">;

// The cut a hole makes in a body is drawn from depth textures rather than from a
// boolean. A hole fragment lies inside a body when it falls between the body's
// near and its far depth at that pixel, and a body fragment lies inside a hole
// the same way; four depth textures carry those bounds. Nothing runs on the CPU
// for it, so the preview keeps up with a shape while it is being dragged, and no
// result has to be cached or dropped when a gesture starts.
const CUT_PREVIEW_COLOR = 0x30363a;
const CUT_PREVIEW_OPACITY = 0.34;
// Window depth is not linear, so a bias in window units opens a gap where the cut
// meets the surface that grows as the view is pulled back. The band is widened by it
// rather than narrowed, so a hole flush with a face stays visible - the cutter pads
// by 0.05 the same way - and the bias only has to be big enough to break a tie.
const CUT_PREVIEW_DEPTH_BIAS = 1e-7;

type CutPreviewResources = {
  bodiesNear: THREE.WebGLRenderTarget;
  bodiesFar: THREE.WebGLRenderTarget;
  frontDepth: THREE.MeshBasicMaterial;
  backDepth: THREE.MeshBasicMaterial;
  // The hole shaded where it lies inside a body: what is going to be cut out,
  // drawn on the hole itself. Nothing has to know the shape of either body - only
  // whether a fragment sits between the near and the far depth of the other one.
  ink: THREE.ShaderMaterial;
  width: number;
  height: number;
};

// Each renderer has its own: the second view's window draws with a WebGL context of its own,
// and a size shared by both would make each frame throw the other's away.
const cutPreviewResourcesByRenderer = new WeakMap<THREE.WebGLRenderer, CutPreviewResources>();

function cutPreviewInkMaterial() {
  return new THREE.ShaderMaterial({
    transparent: true,
    depthTest: false,
    depthWrite: false,
    // Both sides, so the far wall of a hole that goes right through fills the cut.
    // The stencil keeps one layer per pixel, so the two walls cannot add up to a
    // darker ring.
    side: THREE.DoubleSide,
    stencilWrite: true,
    stencilFunc: THREE.NotEqualStencilFunc,
    stencilRef: 1,
    stencilFail: THREE.KeepStencilOp,
    stencilZFail: THREE.KeepStencilOp,
    stencilZPass: THREE.ReplaceStencilOp,
    uniforms: {
      nearDepth: { value: null },
      farDepth: { value: null },
      resolution: { value: new THREE.Vector2(1, 1) },
      // Written straight into the frame, so the tint keeps the values it was
      // given instead of being converted twice.
      tint: { value: new THREE.Color().setHex(CUT_PREVIEW_COLOR, THREE.LinearSRGBColorSpace) },
      opacity: { value: CUT_PREVIEW_OPACITY },
      bias: { value: CUT_PREVIEW_DEPTH_BIAS },
    },
    vertexShader: [
      "void main() {",
      "  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);",
      "}",
    ].join("\n"),
    fragmentShader: [
      "uniform sampler2D nearDepth;",
      "uniform sampler2D farDepth;",
      "uniform vec2 resolution;",
      "uniform vec3 tint;",
      "uniform float opacity;",
      "uniform float bias;",
      "void main() {",
      "  // Both sides are window-space depth, so they compare directly.",
      "  float depth = gl_FragCoord.z;",
      "  vec2 uv = gl_FragCoord.xy / resolution;",
      "  float near = texture2D(nearDepth, uv).r;",
      "  float far = texture2D(farDepth, uv).r;",
      "  if (depth < near - bias || depth > far + bias) {",
      "    discard;",
      "  }",
      "  gl_FragColor = vec4(tint, opacity);",
      "}",
    ].join("\n"),
  });
}

function cutPreviewDepthTarget(width: number, height: number) {
  const depthTexture = new THREE.DepthTexture(width, height);
  depthTexture.format = THREE.DepthFormat;
  depthTexture.type = THREE.UnsignedIntType;
  const target = new THREE.WebGLRenderTarget(width, height, {
    minFilter: THREE.NearestFilter,
    magFilter: THREE.NearestFilter,
    depthBuffer: true,
    stencilBuffer: false,
    depthTexture,
  });
  target.texture.colorSpace = THREE.NoColorSpace;
  return target;
}

export function disposeCutPreviewResources(renderer: THREE.WebGLRenderer) {
  const resources = cutPreviewResourcesByRenderer.get(renderer);
  if (!resources) {
    return;
  }
  [resources.bodiesNear, resources.bodiesFar].forEach((target) =>
    target.dispose(),
  );
  [
    resources.frontDepth,
    resources.backDepth,
    resources.ink,
  ].forEach((material) => material.dispose());
  cutPreviewResourcesByRenderer.delete(renderer);
}

function cutPreviewResourcesFor(renderer: THREE.WebGLRenderer, width: number, height: number) {
  const cached = cutPreviewResourcesByRenderer.get(renderer);
  if (cached && cached.width === width && cached.height === height) {
    return cached;
  }
  disposeCutPreviewResources(renderer);
  const resources: CutPreviewResources = {
    bodiesNear: cutPreviewDepthTarget(width, height),
    bodiesFar: cutPreviewDepthTarget(width, height),
    frontDepth: new THREE.MeshBasicMaterial({
      colorWrite: false,
      depthWrite: true,
      depthTest: true,
      depthFunc: THREE.LessDepth,
      side: THREE.FrontSide,
    }),
    backDepth: new THREE.MeshBasicMaterial({
      colorWrite: false,
      depthWrite: true,
      depthTest: true,
      depthFunc: THREE.LessDepth,
      side: THREE.BackSide,
    }),
    ink: cutPreviewInkMaterial(),
    width,
    height,
  };
  cutPreviewResourcesByRenderer.set(renderer, resources);
  return resources;
}

function drawCutPreviews(state: FrameState) {
  const bodies: THREE.Object3D[] = [];
  const holes: THREE.Object3D[] = [];
  state.shapeRecords.forEach((record) => {
    const object = record.object;
    if (!object || record.shape.hidden || !object.visible) {
      return;
    }
    if (record.shape.hole) {
      holes.push(object);
    } else {
      bodies.push(object);
    }
  });
  if (bodies.length === 0 || holes.length === 0) {
    return;
  }

  const renderer = state.renderer;
  const scene = state.scene;
  const camera = state.camera;
  const frameTarget = renderer.getRenderTarget();
  const size = frameTarget
    ? new THREE.Vector2(frameTarget.width, frameTarget.height)
    : renderer.getDrawingBufferSize(new THREE.Vector2());
  const resources = cutPreviewResourcesFor(renderer, size.x, size.y);

  const shapes = [...bodies, ...holes];
  const wasVisible = new Map(shapes.map((object) => [object, object.visible] as const));
  const previousAutoClear = renderer.autoClear;
  const previousOverride = scene.overrideMaterial;
  const previousBackground = scene.background;
  const previousMask = camera.layers.mask;

  const renderSet = (visible: THREE.Object3D[]) => {
    const wanted = new Set(visible);
    shapes.forEach((object) => {
      object.visible = wanted.has(object);
    });
  };

  try {
    renderer.autoClear = false;
    camera.layers.set(RENDER_LAYER_SHAPES);
    // A scene background is repainted by every render() call, and this renders
    // the scene four more times; left alone it would wipe the frame.
    scene.background = null;

    // The section plane clips per material, and these are the preview's own: without
    // it the depth textures keep the geometry that was cut away, and the ink lands in
    // the removed half. Where the plane is gone the depth reads 1.0, which discards
    // the ink there by itself.
    const sectionPlane = state.sectionPlane ?? null;
    for (const material of [resources.frontDepth, resources.backDepth]) {
      if ((material.clippingPlanes?.[0] ?? null) !== sectionPlane) {
        material.clippingPlanes = sectionPlane ? [sectionPlane] : null;
        material.needsUpdate = true;
      }
    }

    const depthPass = (
      visible: THREE.Object3D[],
      material: THREE.Material,
      target: THREE.WebGLRenderTarget,
    ) => {
      renderSet(visible);
      renderer.setRenderTarget(target);
      renderer.clear(true, true, false);
      scene.overrideMaterial = material;
      renderer.render(scene, camera);
    };

    depthPass(bodies, resources.frontDepth, resources.bodiesNear);
    depthPass(bodies, resources.backDepth, resources.bodiesFar);

    // The hole is drawn once, over the frame, and shaded where it lies inside a
    // body. The stencil decides which of its fragments gets a pixel: one layer, so
    // the shading stays even wherever the hole turns back on itself.
    resources.ink.uniforms.nearDepth.value = resources.bodiesNear.depthTexture;
    resources.ink.uniforms.farDepth.value = resources.bodiesFar.depthTexture;
    (resources.ink.uniforms.resolution.value as THREE.Vector2).set(
      resources.width,
      resources.height,
    );
    renderSet(holes);
    renderer.setRenderTarget(frameTarget);
    renderer.clear(false, false, true);
    scene.overrideMaterial = resources.ink;
    renderer.render(scene, camera);
  } finally {
    shapes.forEach((object) => {
      object.visible = wasVisible.get(object) ?? true;
    });
    scene.overrideMaterial = previousOverride;
    scene.background = previousBackground;
    camera.layers.mask = previousMask;
    renderer.autoClear = previousAutoClear;
    renderer.setRenderTarget(frameTarget);
  }
}

const plateNormal = new THREE.Vector3();
const plateCenter = new THREE.Vector3();
const plateToCamera = new THREE.Vector3();

/**
 * The plate is see-through and drawn before the see-through bodies, so a body above it is not laid over by
 * it (viewportScene.ts). Seen from below the plate is in front of them instead, and drawn first it hid them
 * completely (#894). From its back side the plate is drawn after them, so they show through it, faded.
 */
function orderPlatesForView(scene: THREE.Scene, camera: THREE.Camera) {
  scene.traverse((object) => {
    if (object.name !== "WorkplaneBase" && object.name !== "WorkplaneBaseReference") return;
    plateNormal.set(0, 0, 1).transformDirection(object.matrixWorld);
    object.getWorldPosition(plateCenter);
    const behind = plateToCamera.copy(camera.position).sub(plateCenter).dot(plateNormal) < 0;
    object.renderOrder = behind ? 10 : -10;
    // Seen from below, the plate itself goes fully see-through so the bodies show; the grid stays.
    if (object.name === "WorkplaneBase") {
      const material = (object as THREE.Mesh).material as THREE.Material;
      if (material.userData.pcShown === undefined) material.userData.pcShown = material.visible;
      material.visible = behind ? false : material.userData.pcShown;
      object.parent?.children.forEach((child) => {
        if (child.name === "BuildPlateModel") child.visible = !behind;
        if ((child as THREE.Mesh).material instanceof THREE.ShadowMaterial) child.visible = !behind;
      });
    }
  });
}

/**
 * Night Vision for the 3D view: the frame is drawn into a texture and put on
 * screen through a red/black shader. A CSS or SVG filter on the canvas is not
 * applied by iOS Safari, so the colour change happens in WebGL itself.
 */
let night: { target: THREE.WebGLRenderTarget; scene: THREE.Scene; camera: THREE.OrthographicCamera; material: THREE.ShaderMaterial } | null = null;
const nightSize = new THREE.Vector2();

function nightPass(renderer: THREE.WebGLRenderer) {
  renderer.getDrawingBufferSize(nightSize);
  if (!night) {
    const target = new THREE.WebGLRenderTarget(nightSize.x, nightSize.y, { samples: 4, depthBuffer: true, stencilBuffer: true });
    const material = new THREE.ShaderMaterial({
      uniforms: { frame: { value: target.texture }, mode: { value: 0 }, res: { value: new THREE.Vector2(1, 1) }, time: { value: 0 } },
      vertexShader: "varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }",
      // mode 0: Night Vision (red on black). mode 1: Thermal - brightness through a rainbow thermal-camera ramp,
      // navy (cold) → purple → blue → cyan → green → yellow → orange → red (hot), plus a faint navy vignette.
      fragmentShader: `uniform sampler2D frame; uniform float mode; varying vec2 vUv;
        vec3 thermal(float t){
          vec3 c0=vec3(0.102,0.102,0.369), c1=vec3(0.36,0.12,0.62), c2=vec3(0.10,0.30,0.95), c3=vec3(0.0,0.85,0.95),
               c4=vec3(0.15,0.90,0.30), c5=vec3(1.0,0.92,0.15), c6=vec3(1.0,0.55,0.05), c7=vec3(0.95,0.12,0.08);
          t=clamp(t,0.0,1.0)*7.0;
          if(t<1.0) return mix(c0,c1,t); if(t<2.0) return mix(c1,c2,t-1.0); if(t<3.0) return mix(c2,c3,t-2.0);
          if(t<4.0) return mix(c3,c4,t-3.0); if(t<5.0) return mix(c4,c5,t-4.0); if(t<6.0) return mix(c5,c6,t-5.0); return mix(c6,c7,t-6.0);
        }
        uniform vec2 res; uniform float time;
        float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233)) + time) * 43758.5453); }
        void main(){ vec4 c = texture2D(frame, vUv); float l = pow(clamp(dot(c.rgb, vec3(0.2126, 0.7152, 0.0722)), 0.0, 1.0), 1.0 / 2.2);
          if (mode > 1.5) {
            l = pow(l, 2.0) * 1.15;
            // X-Ray: blue-violet monochrome. Dark = indigo film, mid = blue-purple, bright (dense / rim) = lavender-white.
            vec3 col = l < 0.5 ? mix(vec3(0.043,0.031,0.125), vec3(0.42,0.40,0.95), l * 2.0) : mix(vec3(0.42,0.40,0.95), vec3(0.94,0.92,1.0), (l - 0.5) * 2.0);
            float scan = 0.94 + 0.06 * sin(vUv.y * res.y * 1.5708);
            float n = (hash(floor(vUv * res)) - 0.5) * 0.035;
            float v = smoothstep(0.4, 1.1, length(vUv - 0.5) * 1.4);
            gl_FragColor = vec4(mix(col * scan + n, vec3(0.03,0.02,0.09), v * 0.45), 1.0); return; }
          if (mode < 0.5) { gl_FragColor = vec4(clamp(l * 1.1, 0.0, 1.0), 0.0, 0.0, 1.0); return; }
          vec3 col = thermal(pow(l, 1.5) * 1.12);
          float v = smoothstep(0.35, 1.05, length(vUv - 0.5) * 1.4);
          gl_FragColor = vec4(mix(col, vec3(0.06,0.06,0.22), v * 0.35), 1.0); }`,
      depthTest: false,
      depthWrite: false,
    });
    const scene = new THREE.Scene();
    scene.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), material));
    night = { target, scene, camera: new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1), material };
  }
  if (night.target.width !== nightSize.x || night.target.height !== nightSize.y) night.target.setSize(nightSize.x, nightSize.y);
  return night;
}

export function nightVisionActive() {
  return typeof document !== "undefined" && document.documentElement.dataset.palette === "night";
}

/** Thermal theme: the 3D frame goes through the same WebGL pass with a thermal-camera colour ramp. */
export function thermalActive() {
  return typeof document !== "undefined" && document.documentElement.dataset.palette === "thermal";
}

/** X-Ray theme: bodies are drawn as see-through film (fresnel rim, additive), then the frame is tinted blue-violet. */
export function xrayActive() {
  return typeof document !== "undefined" && document.documentElement.dataset.palette === "xray";
}
let xrayMaterial: THREE.ShaderMaterial | null = null;
function xrayFilm() {
  if (!xrayMaterial) xrayMaterial = new THREE.ShaderMaterial({
    vertexShader: `varying vec3 vN; varying vec3 vV;
      void main(){ vec4 mv = modelViewMatrix * vec4(position, 1.0); vN = normalize(normalMatrix * normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix * mv; }`,
    fragmentShader: `varying vec3 vN; varying vec3 vV;
      void main(){ float f = pow(1.0 - abs(dot(normalize(vN), normalize(vV))), 2.2);
        vec3 col = mix(vec3(0.30,0.26,0.75) * 0.22, vec3(0.92,0.90,1.0), f);
        gl_FragColor = vec4(col * (0.18 + 0.82 * f), 1.0); }`,
    blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, depthTest: true, side: THREE.DoubleSide,
  });
  return xrayMaterial;
}
const SHAPE_LAYER_BIT = 1 << 1;

export function renderFrame(state: FrameState) {
  orderPlatesForView(state.scene, state.camera);
  const thermalOn = thermalActive();
  const xrayOn = xrayActive();
  if (!nightVisionActive() && !thermalOn && !xrayOn) {
    state.renderer.render(state.scene, state.camera);
    drawCutPreviews(state);
    return;
  }
  const pass = nightPass(state.renderer);
  pass.material.uniforms.mode.value = xrayOn ? 2 : thermalOn ? 1 : 0;
  pass.material.uniforms.res.value.set(pass.target.width, pass.target.height);
  pass.material.uniforms.time.value = (performance.now() / 1000) % 100;
  const previous = state.renderer.getRenderTarget();
  state.renderer.setRenderTarget(pass.target);
  state.renderer.clear(true, true, true);
  if (xrayOn) {
    // Plate, grid and helpers first, then the bodies as additive film on top, so overlaps and insides show through.
    const mask = state.camera.layers.mask;
    const autoClear = state.renderer.autoClear;
    const background = state.scene.background;
    // A ghost (easter egg) goes in first, so the plate and every body draw over it.
    const clearColor = state.renderer.getClearColor(new THREE.Color()); const clearAlpha = state.renderer.getClearAlpha();
    if (background instanceof THREE.Color) state.renderer.setClearColor(background, 1);
    state.renderer.clear(true, true, true);
    state.renderer.autoClear = false;
    state.scene.background = null;
    state.camera.layers.mask = mask & ~SHAPE_LAYER_BIT;
    state.renderer.render(state.scene, state.camera);
    if (xrayGhostTickActive()) {
      // Bodies into depth only, so a ghost behind them is hidden; then the ghost, in world space.
      state.scene.overrideMaterial = depthOnly();
      state.camera.layers.mask = mask & SHAPE_LAYER_BIT;
      state.renderer.render(state.scene, state.camera);
      state.scene.overrideMaterial = null;
      state.camera.layers.mask = mask & ~SHAPE_LAYER_BIT;
      if (++ghostCenterAge > 90) {
        ghostCenterAge = 0;
        const plate = state.scene.getObjectByName("ActiveWorkplane");
        if (plate) new THREE.Box3().setFromObject(plate).getCenter(ghostCenter);
      }
      drawXrayGhost(state.renderer, state.camera, ghostCenter);
    }
    state.scene.overrideMaterial = xrayFilm();
    state.camera.layers.mask = mask & SHAPE_LAYER_BIT;
    state.renderer.render(state.scene, state.camera);
    state.scene.overrideMaterial = null;
    state.scene.background = background;
    state.camera.layers.mask = mask;
    state.renderer.autoClear = autoClear;
    state.renderer.setClearColor(clearColor, clearAlpha);
  } else {
    state.renderer.render(state.scene, state.camera);
  }
  drawCutPreviews(state);
  state.renderer.setRenderTarget(previous);
  state.renderer.render(pass.scene, pass.camera);
}

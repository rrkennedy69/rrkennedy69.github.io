"use client";

import { Printer, Search, X } from "lucide-react";
import { Fragment, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useMovablePanel } from "@/lib/useMovablePanel";
import { t, type MessageKey } from "@/lib/i18n";
import { useLanguage } from "@/lib/useLanguage";
import { GuideHelpLink } from "@/components/GuideHelpLink";
import { SHORTCUT_GROUPS, comboKeys, type Shortcut, type ShortcutGroup } from "@/lib/shortcutCatalog";
import { effectiveCombos, useKeyBindings } from "@/lib/keyBindings";


/**
 * Whether the keyboard is an Apple one - a Mac, or an iPad with a keyboard,
 * which reports itself as a Mac. Browsers do not say "Darwin"; the user agent
 * says Macintosh. The editor takes Cmd wherever it takes Ctrl, and Option is
 * Alt, so the list shows the keys under the names on that keyboard.
 */
export function appleKeyboard() {
  return typeof navigator !== "undefined" && /Macintosh|Mac OS X|iPhone|iPad|iPod/.test(navigator.userAgent);
}

const APPLE_KEY_NAMES: Record<string, string> = { Ctrl: "Cmd", Alt: "Option" };

export function keyLabel(key: string, apple: boolean) {
  if (key === "Click") return t("shortcuts.click");
  if (key === "RightClick") return t("shortcuts.rightClick");
  if (key === "Drag") return t("shortcuts.drag");
  if (key === "Wheel") return t("shortcuts.wheel");
  return apple ? APPLE_KEY_NAMES[key] ?? key : key;
}

/** Lower case and without accents, so "ecran" finds "écran" and "ctrl" finds "Ctrl". */
function searchText(text: string) {
  return text.normalize("NFD").replace(/\p{M}/gu, "").toLocaleLowerCase();
}

/** Chinese and Japanese write words without spaces, so there a single character is a whole word. */
const UNSPACED_SCRIPT = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}]/u;

/** Whether a row is found by every word typed - in its sentence, its group's title or its keys. */
function shortcutMatches(group: ShortcutGroup, shortcut: Shortcut, terms: string[], apple: boolean) {
  const keys = effectiveCombos(group.mode, shortcut).flatMap((combo) => comboKeys(combo).flatMap((key) => [key, keyLabel(key, apple)]));
  const combos = effectiveCombos(group.mode, shortcut).flatMap((combo) => [combo, comboKeys(combo).map((key) => keyLabel(key, apple)).join("+")]);
  const text = searchText([t(group.title), t(shortcut.label), ...combos, ...keys].join(" "));
  const words = text.split(/[^\p{L}\p{N}]+/u);
  const singleKeys = new Set(keys.flatMap((key) => searchText(key).split(/[\s/]+/)));
  return terms.every((term) => {
    if (term.length > 1 || UNSPACED_SCRIPT.test(term)) return text.includes(term);
    return singleKeys.has(term) || words.some((word) => word.startsWith(term));
  });
}

/**
 * The groups with only the rows the search finds, in the window's language and under the key
 * names it shows. A single character is a key or the start of a word, not any letter inside
 * one: "r" finds R and "Rotate", not every sentence with an r in it.
 */
function filterGroups(groups: ShortcutGroup[], query: string, apple: boolean) {
  const terms = searchText(query).split(/\s+/).filter(Boolean);
  if (terms.length === 0) return groups;
  return groups
    .map((group) => ({ ...group, shortcuts: group.shortcuts.filter((shortcut) => shortcutMatches(group, shortcut, terms, apple)) }))
    .filter((group) => group.shortcuts.length > 0);
}

function ShortcutKeys({ combos, apple }: { combos: string[]; apple: boolean }) {
  return (
    <>
      {combos.map((combo, comboIndex) => (
        <Fragment key={combo}>
          {comboIndex > 0 ? <span className="shortcuts-or">{t("shortcuts.or")}</span> : null}
          <span className="shortcuts-combo">
            {comboKeys(combo).map((key, keyIndex) => (
              <Fragment key={key}>
                {keyIndex > 0 ? <span className="shortcuts-plus" aria-hidden="true">+</span> : null}
                <kbd>{keyLabel(key, apple)}</kbd>
              </Fragment>
            ))}
          </span>
        </Fragment>
      ))}
    </>
  );
}

/** The groups with their rows, the same markup in the window and on the printed sheet. */
function ShortcutGroups({ groups }: { groups: ShortcutGroup[] }) {
  useKeyBindings();
  const apple = appleKeyboard();
  return (
    <div className="shortcuts-groups">
      {groups.map((group) => (
        <section className="shortcuts-group" key={group.title}>
          <h3>{t(group.title)}</h3>
          <dl>
            {group.shortcuts.map((shortcut) => (
              <div className="shortcuts-row" key={`${group.title}:${shortcut.label}`}>
                <dt>{t(shortcut.label)}</dt>
                <dd>
                  <ShortcutKeys combos={effectiveCombos(group.mode, shortcut)} apple={apple} />
                </dd>
              </div>
            ))}
          </dl>
        </section>
      ))}
    </div>
  );
}

/** While this attribute is on the page, the print style shows the sheet of shortcuts and nothing else. */
const PRINT_ATTRIBUTE = "data-print-shortcuts";

/**
 * Prints only the list, black on white and in large type (a wish of someone who reads it a lot and found
 * screenshots too blurred). The sheet sits in the body next to the app, hidden on screen; the print style
 * hides everything else while the attribute is set. The attribute comes on with the button and with
 * Ctrl+P alike (beforeprint) and goes away again after printing.
 */
function useShortcutsPrinting() {
  useEffect(() => {
    const on = () => document.documentElement.setAttribute(PRINT_ATTRIBUTE, "");
    const off = () => document.documentElement.removeAttribute(PRINT_ATTRIBUTE);
    window.addEventListener("beforeprint", on);
    window.addEventListener("afterprint", off);
    return () => {
      window.removeEventListener("beforeprint", on);
      window.removeEventListener("afterprint", off);
      off();
    };
  }, []);
  return () => {
    document.documentElement.setAttribute(PRINT_ATTRIBUTE, "");
    window.print();
  };
}

export function ShortcutsModal({ sketchMode, onClose }: { sketchMode: boolean; onClose: () => void }) {
  useLanguage();
  const print = useShortcutsPrinting();
  const modeGroups = SHORTCUT_GROUPS.filter((group) => (group.mode === "sketch") === sketchMode);
  // The search only narrows what the window shows and prints; it starts empty every time.
  const [query, setQuery] = useState("");
  const groups = filterGroups(modeGroups, query, appleKeyboard());
  const searchRef = useRef<HTMLInputElement>(null);
  // Moved by its title bar like every panel, and remembered where it stood.
  const movable = useMovablePanel<HTMLDivElement>("layerling.editor.shortcutsPosition", { floatingStyle: { position: "absolute", margin: 0 } });
  const cardRef = movable.panelRef;

  // Ready to type into the search - except on a touch screen, where focusing it would pop up the keyboard.
  useEffect(() => {
    const touch = typeof window.matchMedia === "function" && window.matchMedia("(pointer: coarse)").matches;
    (touch ? cardRef.current : searchRef.current)?.focus();
  }, []);

  return (
    <div
      className="workspace-modal shortcuts-modal"
      data-compact={modeGroups.length <= 2 ? "true" : undefined}
      role="dialog"
      aria-modal="true"
      aria-label={t("shortcuts.title")}
      // The editor and the viewport both listen for keys on the window. While
      // this dialog is open every key it sees stops here, so reading about a
      // shortcut never triggers it.
      onKeyDown={(event) => {
        event.stopPropagation();
        if (event.key === "Escape") {
          event.preventDefault();
          onClose();
        }
      }}
    >
      <div
        className={`workspace-modal-card shortcuts-modal-card ${movable.moved ? "floating" : ""} ${movable.dragging ? "moving" : ""}`}
        ref={cardRef}
        style={movable.style}
        tabIndex={-1}
        onPointerDown={(event) => event.stopPropagation()}
      >
        <header className="workspace-modal-header movable" title={t("panel.moveHint")} {...movable.handleProps}>
          <strong>{t("shortcuts.title")}</strong>
          <div className="panel-header-actions">
            <GuideHelpLink chapter="shortcuts" />
            <button aria-label={t("shortcuts.print")} title={t("shortcuts.print")} onClick={print}>
              <Printer size={18} />
            </button>
            <button aria-label={t("shortcuts.close")} onClick={onClose}>
              <X size={18} />
            </button>
          </div>
        </header>
        <div className="workspace-modal-content">
          <div className="shortcuts-search">
            <div className="shortcuts-search-box">
              <Search size={15} className="shortcuts-search-icon" aria-hidden="true" />
              <input
                ref={searchRef}
                className="shortcuts-search-input"
                type="text"
                placeholder={t("shortcuts.search")}
                aria-label={t("shortcuts.search")}
                value={query}
                onChange={(event) => setQuery(event.target.value)}
              />
              {query ? (
                <button
                  className="shortcuts-search-clear"
                  type="button"
                  aria-label={t("shortcuts.clearSearch")}
                  title={t("shortcuts.clearSearch")}
                  onClick={() => {
                    setQuery("");
                    searchRef.current?.focus();
                  }}
                >
                  <X size={14} />
                </button>
              ) : null}
            </div>
          </div>
          <div className="workspace-modal-body shortcuts-modal-body">
            <p className="shortcuts-intro">{t("shortcuts.intro")}</p>
            {groups.length > 0 ? <ShortcutGroups groups={groups} /> : <p className="shortcuts-no-matches">{t("shortcuts.noMatches")}</p>}
          </div>
        </div>
      </div>
      <button className="workspace-modal-backdrop" aria-label={t("shortcuts.close")} onClick={onClose} />
      {typeof document === "undefined"
        ? null
        : createPortal(
            <div className="shortcuts-print-sheet" aria-hidden="true">
              <h1>{t("shortcuts.title")}</h1>
              <ShortcutGroups groups={groups} />
            </div>,
            document.body,
          )}
    </div>
  );
}

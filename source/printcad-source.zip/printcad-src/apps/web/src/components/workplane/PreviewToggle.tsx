"use client";
import { setPreviewOn, usePreviewOn } from "@/lib/toolPreview";

/** The Preview checkbox of the modify-tool dialogs: live preview without committing. */
export function PreviewToggle() {
  const on = usePreviewOn();
  return (
    <label className="edge-modifier-check tool-preview-toggle" data-testid="tool-preview-toggle">
      <input type="checkbox" checked={on} onChange={(event) => setPreviewOn(event.currentTarget.checked)} />
      <span>Preview</span>
    </label>
  );
}

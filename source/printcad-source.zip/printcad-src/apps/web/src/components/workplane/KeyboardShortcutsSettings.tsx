"use client";

import { AlertTriangle, Keyboard, RotateCcw } from "lucide-react";
import { Fragment, useEffect, useState } from "react";
import { t } from "@/lib/i18n";
import { SHORTCUT_GROUPS, comboKeys, type ShortcutGroup } from "@/lib/shortcutCatalog";
import { comboFromEvent, conflictsFor, effectiveCombos, isRebindable, resetAllBindings, resetBinding, rowId, setBinding, useKeyBindings } from "@/lib/keyBindings";
import { appleKeyboard, keyLabel } from "./ShortcutsModal";

function Combo({ combo, apple }: { combo: string; apple: boolean }) {
  return (
    <span className="shortcuts-combo">
      {comboKeys(combo).map((key, i) => (
        <Fragment key={`${key}${i}`}>
          {i > 0 ? <span className="shortcuts-plus" aria-hidden="true">+</span> : null}
          <kbd>{keyLabel(key, apple)}</kbd>
        </Fragment>
      ))}
    </span>
  );
}

const MODE_TITLE: Record<ShortcutGroup["mode"], string> = { geometry: "keys.mode3d", sketch: "keys.modeSketch" };

/** Settings > Keyboard shortcuts: every shortcut, grouped, each with rebind and reset. */
export function KeyboardShortcutsSettings() {
  const bindings = useKeyBindings();
  const apple = appleKeyboard();
  const [capturing, setCapturing] = useState<string | null>(null);
  const [warning, setWarning] = useState<{ id: string; text: string } | null>(null);

  useEffect(() => {
    if (!capturing) return;
    const onKey = (event: KeyboardEvent) => {
      event.preventDefault();
      event.stopImmediatePropagation();
      if (event.key === "Escape" && !event.ctrlKey && !event.altKey && !event.shiftKey) {
        setCapturing(null);
        return;
      }
      const combo = comboFromEvent(event);
      if (!combo) return; // a lone modifier: wait for the key
      const clash = conflictsFor(capturing, combo, bindings);
      setBinding(capturing, combo);
      setWarning(clash.length ? { id: capturing, text: t("keys.conflict", { combo, actions: clash.map((c) => t(c.shortcut.label)).join(", ") }) } : null);
      setCapturing(null);
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [capturing, bindings]);

  const customCount = Object.keys(bindings).length;
  return (
    <div className="keys-settings" data-key-capture={capturing ? "" : undefined}>
      <div className="keys-settings-toolbar">
        <span>{t("keys.customCount", { count: customCount })}</span>
        <button type="button" className="keys-reset-all" disabled={customCount === 0} onClick={() => { resetAllBindings(); setWarning(null); }}>
          <RotateCcw size={15} /> {t("keys.resetAll")}
        </button>
      </div>
      {(["geometry", "sketch"] as const).map((mode) => (
        <div key={mode} className="keys-mode">
          <h3 className="keys-mode-title">{t(MODE_TITLE[mode] as never)}</h3>
          {SHORTCUT_GROUPS.filter((g) => g.mode === mode).map((group) => (
            <section key={group.title} className="keys-group">
              <h4>{t(group.title)}</h4>
              {group.shortcuts.map((shortcut, index) => {
                const id = rowId(mode, shortcut);
                const editable = isRebindable(mode, shortcut);
                const combos = effectiveCombos(mode, shortcut, bindings);
                const custom = Boolean(bindings[id]);
                const conflict = editable && combos.some((c) => conflictsFor(id, c, bindings).length > 0);
                return (
                  <div key={`${id}:${index}`} className={`keys-row${custom ? " custom" : ""}${conflict ? " conflict" : ""}`} data-row-id={id}>
                    <span className="keys-action">{t(shortcut.label)}</span>
                    <span className="keys-combo">
                      {capturing === id ? (
                        <span className="keys-capturing">{t("keys.pressKeys")}</span>
                      ) : (
                        combos.map((c, i) => (
                          <Fragment key={c}>
                            {i > 0 ? <span className="shortcuts-or">{t("shortcuts.or")}</span> : null}
                            <Combo combo={c} apple={apple} />
                          </Fragment>
                        ))
                      )}
                      {conflict ? <AlertTriangle size={14} className="keys-conflict-icon" aria-label={t("keys.conflictShort")} /> : null}
                    </span>
                    <span className="keys-buttons">
                      {editable ? (
                        <>
                          <button type="button" className="keys-rebind" aria-pressed={capturing === id} onClick={() => setCapturing(capturing === id ? null : id)}>
                            <Keyboard size={14} /> {capturing === id ? t("keys.cancel") : t("keys.rebind")}
                          </button>
                          <button type="button" className="keys-reset" disabled={!custom} aria-label={t("keys.reset")} title={t("keys.reset")} onClick={() => { resetBinding(id); setWarning(null); }}>
                            <RotateCcw size={14} />
                          </button>
                        </>
                      ) : (
                        <span className="keys-fixed">{t("keys.fixed")}</span>
                      )}
                    </span>
                    {warning?.id === id ? <span className="keys-warning" role="alert"><AlertTriangle size={14} /> {warning.text}</span> : null}
                  </div>
                );
              })}
            </section>
          ))}
        </div>
      ))}
    </div>
  );
}

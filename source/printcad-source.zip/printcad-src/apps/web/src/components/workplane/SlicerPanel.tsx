"use client";

import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { X } from "lucide-react";
import type { MaterialTemps, SliceResult, SliceSettings, SlicerPresetId } from "@/lib/slicer";

export type SliceInput = { stl: ArrayBuffer; materialType: string; materialName: string; mixed: string[] };

type Props = {
  printerLabel: string;
  bed: { width: number; depth: number; height: number };
  buildInput: () => Promise<SliceInput>;
  /** Exports the sliced plate as a Bambu Studio project 3MF carrying these settings. */
  onExport3mf: (settings: SliceSettings) => Promise<void>;
  onClose: () => void;
};

const PRESETS: Record<SlicerPresetId, { label: string; layerHeight: number; walls: number; infill: number }> = {
  draft: { label: "Draft 0.28 mm", layerHeight: 0.28, walls: 2, infill: 10 },
  standard: { label: "Standard 0.20 mm", layerHeight: 0.2, walls: 2, infill: 15 },
  fine: { label: "Fine 0.12 mm", layerHeight: 0.12, walls: 3, infill: 15 },
};

export function SlicerPanel({ printerLabel, bed, buildInput, onExport3mf, onClose }: Props) {
  const [preset, setPreset] = useState<SlicerPresetId>("standard");
  const [settings, setSettings] = useState<SliceSettings>({ layerHeight: 0.2, infill: 15, walls: 2, supports: false, adhesion: "skirt" });
  const [status, setStatus] = useState<string | null>(null);
  const [progress, setProgress] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<SliceResult | null>(null);
  const [material, setMaterial] = useState<MaterialTemps | null>(null);
  const [warning, setWarning] = useState<string | null>(null);
  const [layer, setLayer] = useState(0);
  const canvasHost = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<{ lines: THREE.LineSegments; render: () => void } | null>(null);

  const choosePreset = (id: SlicerPresetId) => {
    setPreset(id);
    const p = PRESETS[id];
    setSettings((s) => ({ ...s, layerHeight: p.layerHeight, walls: p.walls, infill: p.infill }));
  };

  const slice = async () => {
    setError(null);
    setResult(null);
    setProgress(0);
    try {
      setStatus("Preparing model…");
      const input = await buildInput();
      const lib = await import("@/lib/slicer");
      const mat = lib.materialTemps(input.materialType);
      setMaterial(mat);
      setWarning(input.mixed.length > 1 ? `Several materials (${input.mixed.join(", ")}): this single-extruder slice uses ${input.materialName} settings for everything.` : null);
      const { size } = lib.centerStl(input.stl);
      if (size[0] > bed.width || size[1] > bed.depth || size[2] > bed.height) {
        throw new Error(`The model (${size.map((v) => v.toFixed(0)).join(" × ")} mm) does not fit the ${bed.width} × ${bed.depth} × ${bed.height} mm bed.`);
      }
      setStatus("Loading slicer engine…");
      const basePath = (process.env.NEXT_PUBLIC_BASE_PATH ?? "");
      const sliced = await lib.sliceStl(input.stl, bed, settings, mat, (p) => { setStatus("Slicing…"); setProgress(Math.round(p)); }, basePath);
      if (sliced.parsed.layerEnds.length === 0) throw new Error("The slicer produced no layers. Is the model empty or too thin?");
      setResult(sliced);
      setLayer(sliced.parsed.layerEnds.length - 1);
      setStatus(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      setStatus(null);
    } finally {
      setProgress(null);
    }
  };

  // three.js preview of the toolpaths.
  useEffect(() => {
    const host = canvasHost.current;
    if (!result || !host) return;
    const width = host.clientWidth || 300;
    const height = host.clientHeight || 260;
    const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    host.appendChild(renderer.domElement);
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x1d1f24);
    const camera = new THREE.PerspectiveCamera(40, width / height, 1, 5000);
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.BufferAttribute(result.parsed.positions, 3));
    geometry.setAttribute("color", new THREE.BufferAttribute(result.parsed.colors, 3));
    const lines = new THREE.LineSegments(geometry, new THREE.LineBasicMaterial({ vertexColors: true }));
    scene.add(lines);
    const bedMesh = new THREE.Mesh(new THREE.PlaneGeometry(bed.width, bed.depth), new THREE.MeshBasicMaterial({ color: 0x33373f }));
    bedMesh.rotation.x = -Math.PI / 2;
    bedMesh.position.y = -0.05;
    scene.add(bedMesh);
    const grid = new THREE.GridHelper(Math.max(bed.width, bed.depth), Math.round(Math.max(bed.width, bed.depth) / 10), 0x4a505a, 0x3b4048);
    scene.add(grid);
    geometry.computeBoundingSphere();
    const sphere = geometry.boundingSphere ?? new THREE.Sphere(new THREE.Vector3(), 50);
    const r = Math.max(sphere.radius, 10);
    camera.position.set(sphere.center.x + r * 1.6, sphere.center.y + r * 1.4, sphere.center.z + r * 1.9);
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.copy(sphere.center);
    const render = () => renderer.render(scene, camera);
    controls.addEventListener("change", render);
    controls.update();
    sceneRef.current = { lines, render };
    render();
    return () => {
      sceneRef.current = null;
      controls.dispose();
      geometry.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, [result, bed.width, bed.depth]);

  useEffect(() => {
    const ref = sceneRef.current;
    if (!ref || !result) return;
    ref.lines.geometry.setDrawRange(0, result.parsed.layerEnds[layer] ?? 0);
    ref.render();
  }, [layer, result]);

  const [exporting, setExporting] = useState(false);
  const export3mf = async () => {
    setExporting(true);
    setError(null);
    try { await onExport3mf(settings); } catch (e) { setError(e instanceof Error ? e.message : String(e)); } finally { setExporting(false); }
  };

  const busy = progress !== null;
  const layers = result?.parsed.layerEnds.length ?? 0;
  return (
    <section className="top-action-panel slicer-panel" aria-label="Slice" data-testid="slicer-panel">
      <header>
        <strong>Slice</strong>
        <button aria-label="Close" onClick={onClose}><X size={18} /></button>
      </header>
      <div className="slicer-body">
        <div className="slicer-printer">{printerLabel} · {bed.width} × {bed.depth} × {bed.height} mm · 0.4 mm nozzle</div>
        <label className="slicer-row">Quality
          <select value={preset} onChange={(e) => choosePreset(e.target.value as SlicerPresetId)} disabled={busy} data-testid="slicer-preset">
            {Object.entries(PRESETS).map(([id, p]) => <option key={id} value={id}>{p.label}</option>)}
          </select>
        </label>
        <label className="slicer-row">Layer height
          <select value={settings.layerHeight} onChange={(e) => setSettings({ ...settings, layerHeight: Number(e.target.value) })} disabled={busy}>
            {[0.08, 0.12, 0.16, 0.2, 0.24, 0.28].map((v) => <option key={v} value={v}>{v.toFixed(2)} mm</option>)}
          </select>
        </label>
        <label className="slicer-row">Infill
          <span className="slicer-inline"><input type="range" min={0} max={100} step={5} value={settings.infill} onChange={(e) => setSettings({ ...settings, infill: Number(e.target.value) })} disabled={busy} /><b>{settings.infill}%</b></span>
        </label>
        <label className="slicer-row">Walls
          <input type="number" min={1} max={8} value={settings.walls} onChange={(e) => setSettings({ ...settings, walls: Math.max(1, Math.min(8, Number(e.target.value) || 1)) })} disabled={busy} />
        </label>
        <label className="slicer-row">Supports
          <input type="checkbox" checked={settings.supports} onChange={(e) => setSettings({ ...settings, supports: e.target.checked })} disabled={busy} data-testid="slicer-supports" />
        </label>
        <label className="slicer-row">Bed adhesion
          <select value={settings.adhesion} onChange={(e) => setSettings({ ...settings, adhesion: e.target.value as SliceSettings["adhesion"] })} disabled={busy}>
            <option value="skirt">Skirt</option><option value="brim">Brim</option><option value="none">None</option>
          </select>
        </label>
        <button className="slicer-go" onClick={() => void slice()} disabled={busy} data-testid="slicer-run">{busy ? `${status ?? "Slicing…"} ${progress ? `${progress}%` : ""}` : result ? "Slice again" : "Slice"}</button>
        {status && !busy ? <p className="export-setting-note">{status}</p> : null}
        {error ? <p className="slicer-error" role="alert">{error}</p> : null}
        {warning ? <p className="export-setting-note">{warning}</p> : null}
        {result ? (
          <>
            <div className="slicer-stats" data-testid="slicer-stats">
              <div><span>Time</span><b>{formatDurationLocal(result.printTimeSec)}</b></div>
              <div><span>Filament</span><b>{(result.filamentMm / 1000).toFixed(2)} m · {result.filamentG.toFixed(1)} g</b></div>
              <div><span>Material</span><b>{material ? `${material.type} ${material.nozzle}° / ${material.bed}°` : ""}</b></div>
            </div>
            <div className="slicer-preview" ref={canvasHost} data-testid="slicer-preview" />
            <label className="slicer-row">Layer <b>{layer + 1} / {layers}</b>
              <input type="range" min={0} max={Math.max(0, layers - 1)} value={layer} onChange={(e) => setLayer(Number(e.target.value))} data-testid="slicer-layer" />
            </label>
            <button className="slicer-go" onClick={() => void export3mf()} disabled={exporting} data-testid="slicer-export-3mf">{exporting ? "Exporting…" : "Export 3MF (Bambu Studio project)"}</button>
            <p className="export-setting-note">Preview and estimates come from CuraEngine and are approximate. The 3MF carries these settings (layer height, infill, walls, supports, adhesion); slice and print it in Bambu Studio or OrcaSlicer.</p>
          </>
        ) : null}
      </div>
    </section>
  );
}

function formatDurationLocal(sec: number) {
  const h = Math.floor(sec / 3600);
  const m = Math.round((sec % 3600) / 60);
  return h > 0 ? `${h} h ${m} min` : `${m} min`;
}

"use client";

// Full-screen slicer page (Bambu Studio style Prepare / Preview). Loaded lazily from the editor;
// CuraEngine itself is only fetched when Slice is pressed.
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { STLLoader } from "three/examples/jsm/loaders/STLLoader.js";
import { ArrowLeft, ChevronDown, FileUp, PanelLeftClose, PanelLeftOpen } from "lucide-react";
import type { MaterialTemps, SliceResult, SliceSettings, SlicerPresetId } from "@/lib/slicer";
import { BAMBU_MAPPINGS, EMPTY_IMPORT, applyBambu, importBambuFile, type BambuImported, type BambuValue } from "@/lib/bambuSettingsImport";
import { bambuMaterial, bambuMaterialGroups } from "@/lib/bambuFilaments";

export type SliceSlot = { materialId: string; materialName: string; type: string; color: string; colorName?: string; count: number };
export type SliceInput = { stl: ArrayBuffer; materialType: string; materialName: string; mixed: string[]; slots: SliceSlot[] };

type Props = {
  printerLabel: string;
  bed: { width: number; depth: number; height: number };
  plateCount: number;
  plate: number;
  onPlateChange: (plate: number) => void;
  buildInput: () => Promise<SliceInput>;
  /** Exports the plate as a Bambu Studio project 3MF; the overrides are Bambu keys written into its settings. */
  onExport3mf: (overrides: Record<string, string | string[]>) => Promise<void>;
  /** Builds the same Bambu 3MF and hands it to Bambu Studio (share sheet or download); resolves to a toast text. */
  onSendToBambu: (overrides: Record<string, string | string[]>) => Promise<string>;
  onClose: () => void;
};

const PRESETS: Record<SlicerPresetId, { label: string; layerHeight: number; walls: number; infill: number }> = {
  draft: { label: "0.28mm Extra Draft", layerHeight: 0.28, walls: 2, infill: 10 },
  standard: { label: "0.20mm Standard", layerHeight: 0.2, walls: 2, infill: 15 },
  fine: { label: "0.12mm Fine", layerHeight: 0.12, walls: 3, infill: 15 },
};
const DEFAULTS: SliceSettings = {
  layerHeight: 0.2, infill: 15, walls: 2, supports: false, adhesion: "skirt", firstLayerHeight: 0.2, topLayers: 5, bottomLayers: 3,
  infillPattern: "grid", seam: "sharpest_corner", speedOuterWall: 200, speedInnerWall: 300, speedInfill: 270, speedFirstLayer: 50, speedTravel: 500,
  supportStyle: "tree", supportAngle: 60, supportBuildplateOnly: false, brimWidth: 5, ironing: false, nozzle: 0.4, retractLength: 0.8, retractSpeed: 30,
};
type ProcessTab = "quality" | "strength" | "speed" | "support" | "others";

export function SlicerPanel({ printerLabel, bed, plateCount, plate, onPlateChange, buildInput, onExport3mf, onSendToBambu, onClose }: Props) {
  const [preset, setPreset] = useState<SlicerPresetId>("standard");
  const [settings, setSettings] = useState<SliceSettings>(DEFAULTS);
  const [imported, setImported] = useState<BambuImported>(EMPTY_IMPORT);
  const [applied, setApplied] = useState<Set<string>>(new Set());
  const [importOpen, setImportOpen] = useState(false);
  const [tab, setTab] = useState<ProcessTab>("quality");
  const [view, setView] = useState<"prepare" | "preview">("prepare");
  const [sidebarOpen, setSidebarOpen] = useState(() => typeof window === "undefined" || window.innerWidth > 700);
  const [input, setInput] = useState<SliceInput | null>(null);
  const [modelGeo, setModelGeo] = useState<THREE.BufferGeometry | null>(null);
  const [slots, setSlots] = useState<SliceSlot[]>([]);
  const [status, setStatus] = useState<string | null>(null);
  const [progress, setProgress] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<SliceResult | null>(null);
  const [material, setMaterial] = useState<MaterialTemps | null>(null);
  const [layer, setLayer] = useState(0);
  const [exporting, setExporting] = useState(false);
  const canvasHost = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<{ lines: THREE.LineSegments | null; render: () => void } | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const set = (patch: Partial<SliceSettings>) => { setSettings((s) => ({ ...s, ...patch })); setResult(null); };

  // Prepare: build the plate's mesh once (and again when the plate changes).
  useEffect(() => {
    let cancelled = false;
    setStatus("Preparing plate…");
    setError(null);
    setResult(null);
    setView("prepare");
    buildInput().then(async (inp) => {
      if (cancelled) return;
      const lib = await import("@/lib/slicer");
      lib.centerStl(inp.stl);
      const geo = new STLLoader().parse(inp.stl.slice(0));
      geo.rotateX(-Math.PI / 2);
      geo.computeVertexNormals();
      setInput(inp);
      setSlots(inp.slots);
      setModelGeo(geo);
      setStatus(null);
    }).catch((e) => { if (!cancelled) { setError(e instanceof Error ? e.message : String(e)); setStatus(null); } });
    return () => { cancelled = true; };
  }, [buildInput, plate]);

  const choosePreset = (id: SlicerPresetId) => {
    setPreset(id);
    const p = PRESETS[id];
    set({ layerHeight: p.layerHeight, walls: p.walls, infill: p.infill, topLayers: Math.ceil(0.8 / p.layerHeight), bottomLayers: Math.ceil(0.6 / p.layerHeight) });
  };

  const importFiles = async (files: FileList | null) => {
    if (!files?.length) return;
    setError(null);
    let next = imported;
    for (const file of Array.from(files)) {
      try { next = await importBambuFile(file, next); } catch (e) { next = { ...next, warnings: [...next.warnings, e instanceof Error ? e.message : String(e)] }; }
    }
    const { settings: s, applied: a } = applyBambu(next, settings);
    setImported(next);
    setApplied(a);
    setSettings(s);
    setResult(null);
    setImportOpen(true);
  };

  const slice = async () => {
    if (!input) return;
    setError(null);
    setResult(null);
    setProgress(0);
    try {
      const lib = await import("@/lib/slicer");
      const mat = lib.materialTemps(slots[0]?.type ?? input.materialType);
      setMaterial(mat);
      const { size } = lib.centerStl(input.stl);
      if (size[0] > bed.width || size[1] > bed.depth || size[2] > bed.height) {
        throw new Error(`The model (${size.map((v) => v.toFixed(0)).join(" × ")} mm) does not fit the ${bed.width} × ${bed.depth} × ${bed.height} mm bed.`);
      }
      setStatus("Loading slicer engine…");
      const basePath = process.env.NEXT_PUBLIC_BASE_PATH ?? "";
      const sliced = await lib.sliceStl(input.stl.slice(0), bed, settings, mat, (p) => { setStatus("Slicing…"); setProgress(Math.round(p)); }, basePath);
      if (sliced.parsed.layerEnds.length === 0) throw new Error("The slicer produced no layers. Is the model empty or too thin?");
      setResult(sliced);
      setLayer(sliced.parsed.layerEnds.length - 1);
      setView("preview");
      setStatus(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      setStatus(null);
    } finally {
      setProgress(null);
    }
  };

  // One three.js view: the model (Prepare) or the toolpaths (Preview).
  useEffect(() => {
    const host = canvasHost.current;
    if (!host) return;
    const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    const size = () => { renderer.setSize(host.clientWidth || 300, host.clientHeight || 300); camera.aspect = (host.clientWidth || 300) / (host.clientHeight || 300); camera.updateProjectionMatrix(); };
    host.appendChild(renderer.domElement);
    const dark = document.documentElement.dataset.theme === "dark";
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(dark ? 0x1d1f24 : 0xe9ecef);
    const camera = new THREE.PerspectiveCamera(40, 1, 1, 5000);
    scene.add(new THREE.HemisphereLight(0xffffff, 0x666666, 1.6));
    const sun = new THREE.DirectionalLight(0xffffff, 1.4);
    sun.position.set(1, 2, 1.5);
    scene.add(sun);
    const bedMesh = new THREE.Mesh(new THREE.PlaneGeometry(bed.width, bed.depth), new THREE.MeshBasicMaterial({ color: dark ? 0x33373f : 0xc9ced4 }));
    bedMesh.rotation.x = -Math.PI / 2;
    bedMesh.position.y = -0.05;
    scene.add(bedMesh);
    scene.add(new THREE.GridHelper(Math.max(bed.width, bed.depth), Math.round(Math.max(bed.width, bed.depth) / 10), dark ? 0x4a505a : 0xa8aeb5, dark ? 0x3b4048 : 0xb8bec4));
    let lines: THREE.LineSegments | null = null;
    let focus = new THREE.Sphere(new THREE.Vector3(0, 10, 0), Math.max(bed.width, bed.depth) / 3);
    if (view === "preview" && result) {
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.BufferAttribute(result.parsed.positions, 3));
      g.setAttribute("color", new THREE.BufferAttribute(result.parsed.colors, 3));
      lines = new THREE.LineSegments(g, new THREE.LineBasicMaterial({ vertexColors: true }));
      g.setDrawRange(0, result.parsed.layerEnds[layerRef.current] ?? 0);
      scene.add(lines);
      g.computeBoundingSphere();
      if (g.boundingSphere) focus = g.boundingSphere;
    } else if (modelGeo) {
      const color = new THREE.Color(slots[0]?.color ?? "#8A98A6");
      scene.add(new THREE.Mesh(modelGeo, new THREE.MeshStandardMaterial({ color, roughness: 0.6 })));
      modelGeo.computeBoundingSphere();
      if (modelGeo.boundingSphere) focus = modelGeo.boundingSphere;
    }
    const r = Math.max(focus.radius * 1.5, 45);
    camera.position.set(focus.center.x + r * 1.6, focus.center.y + r * 1.5, focus.center.z + r * 2.1);
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.copy(focus.center);
    const render = () => renderer.render(scene, camera);
    controls.addEventListener("change", render);
    size();
    controls.update();
    sceneRef.current = { lines, render };
    render();
    const ro = new ResizeObserver(() => { size(); render(); });
    ro.observe(host);
    return () => {
      ro.disconnect();
      sceneRef.current = null;
      controls.dispose();
      lines?.geometry.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view, result, modelGeo, bed.width, bed.depth, slots[0]?.color]);

  const layerRef = useRef(0);
  layerRef.current = layer;
  useEffect(() => {
    const ref = sceneRef.current;
    if (!ref?.lines || !result) return;
    ref.lines.geometry.setDrawRange(0, result.parsed.layerEnds[layer] ?? 0);
    ref.render();
  }, [layer, result]);

  /** What goes into the exported 3MF: imported raw keys, then the page's own values on top. */
  const exportOverrides = async () => {
    const { bambuProcessOverrides } = await import("@/lib/slicer");
    const out: Record<string, BambuValue> = { ...imported.raw, ...bambuProcessOverrides(settings) };
    const n = (k: string, v: number | undefined) => { if (v !== undefined) out[k] = [String(v)]; };
    n("nozzle_temperature", settings.nozzleTemp); n("nozzle_temperature_initial_layer", settings.nozzleTempFirst);
    n("textured_plate_temp", settings.bedTemp); n("fan_max_speed", settings.fanSpeed);
    if (settings.retractLength !== undefined && (imported.raw.retraction_length || settings.retractLength !== DEFAULTS.retractLength)) out.retraction_length = [String(settings.retractLength)];
    return out;
  };
  const export3mf = async () => {
    setExporting(true);
    setError(null);
    try { await onExport3mf(await exportOverrides()); } catch (e) { setError(e instanceof Error ? e.message : String(e)); } finally { setExporting(false); }
  };

  const [sending, setSending] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  useEffect(() => { if (!toast) return; const t = window.setTimeout(() => setToast(null), 7000); return () => window.clearTimeout(t); }, [toast]);
  const sendToBambu = async () => {
    setSending(true); setError(null);
    try { setToast(await onSendToBambu(await exportOverrides())); } catch (e) { setError(e instanceof Error ? e.message : String(e)); } finally { setSending(false); }
  };
  const busy = progress !== null;
  const layers = result?.parsed.layerEnds.length ?? 0;
  const importedKeys = Object.keys(imported.raw).sort();
  const carriedCount = importedKeys.length - applied.size;
  const groups = useMemo(() => bambuMaterialGroups(), []);
  const temps = material ?? null;

  const numField = (label: string, key: keyof SliceSettings, unit: string, min: number, max: number, step = 1, bambuKey?: string) => (
    <Field label={label} bambuKey={bambuKey} applied={bambuKey ? applied.has(bambuKey) : false}>
      <span className="slicer-num"><input type="number" min={min} max={max} step={step} value={(settings[key] as number | undefined) ?? ""} placeholder="auto"
        onChange={(e) => set({ [key]: e.target.value === "" ? undefined : Math.max(min, Math.min(max, Number(e.target.value))) } as Partial<SliceSettings>)} disabled={busy} /><i>{unit}</i></span>
    </Field>
  );

  return (
    <div className={`slicer-page ${sidebarOpen ? "" : "sidebar-closed"}`} role="dialog" aria-label="Slicer" data-testid="slicer-panel">
      <header className="slicer-topbar">
        <button className="slicer-back" onClick={onClose} data-testid="slicer-back"><ArrowLeft size={18} /> <span>Back to editor</span></button>
        <button className="slicer-icon-btn" onClick={() => setSidebarOpen((v) => !v)} aria-label={sidebarOpen ? "Hide settings" : "Show settings"}>
          {sidebarOpen ? <PanelLeftClose size={18} /> : <PanelLeftOpen size={18} />}
        </button>
        <nav className="slicer-tabs" aria-label="View">
          <button className={view === "prepare" ? "active" : ""} onClick={() => setView("prepare")}>Prepare</button>
          <button className={view === "preview" ? "active" : ""} onClick={() => setView("preview")} disabled={!result}>Preview</button>
        </nav>
        <span className="slicer-spacer" />
        <button className="slicer-go" onClick={() => void slice()} disabled={busy || !input} data-testid="slicer-run">
          {busy ? `${status ?? "Slicing…"} ${progress ? `${progress}%` : ""}` : result ? "Slice plate again" : "Slice plate"}
        </button>
        <button className="slicer-secondary" onClick={() => void export3mf()} disabled={exporting || !input} data-testid="slicer-export-3mf">{exporting ? "Exporting…" : "Export 3MF"}</button>
        {result ? <button className="slicer-go" onClick={() => void sendToBambu()} disabled={sending || busy || !input} data-testid="slicer-send-bambu" title="Builds the Bambu Studio project with these settings and opens the share sheet (iPad) or downloads it (computer)">{sending ? "Preparing…" : "Send to Bambu Studio"}</button> : null}
      </header>

      <aside className="slicer-sidebar" aria-label="Slicer settings">
        <section className="slicer-import">
          <button className="slicer-secondary wide" onClick={() => fileRef.current?.click()} data-testid="slicer-import"><FileUp size={16} /> Import Bambu Studio settings</button>
          <input ref={fileRef} type="file" hidden multiple accept=".3mf,.json,.bbscfg,.bbsflmt,.zip" data-testid="slicer-import-input"
            onChange={(e) => { void importFiles(e.currentTarget.files); e.currentTarget.value = ""; }} />
          <small>Project .3mf, printer / filament / process preset .json (system or user), .bbscfg / .bbsflmt bundles.</small>
          {imported.sources.length ? (
            <div className="slicer-import-summary" data-testid="slicer-import-summary">
              <ul>{imported.sources.map((s, i) => <li key={i}><b className={`kind kind-${s.kind}`}>{s.kind}</b> {s.name} <i>({s.keys} keys)</i></li>)}</ul>
              <button className="slicer-link" onClick={() => setImportOpen((v) => !v)}>
                <b className="badge applied">{applied.size} applied</b> <b className="badge carried">{carriedCount} carried to 3MF</b> <ChevronDown size={14} />
              </button>
              {imported.warnings.map((w, i) => <p key={i} className="export-setting-note">{w}</p>)}
              {importOpen ? (
                <table className="slicer-import-table">
                  <tbody>
                    {importedKeys.map((k) => {
                      const v = imported.raw[k];
                      const text = Array.isArray(v) ? v.join(", ") : v;
                      return (
                        <tr key={k} className={applied.has(k) ? "is-applied" : ""}>
                          <td title={k}>{BAMBU_MAPPINGS[k]?.label ?? k}</td>
                          <td title={text}>{text.length > 28 ? `${text.slice(0, 28)}…` : text}</td>
                          <td>{applied.has(k) ? <b className="badge applied" title={`Sliced as ${BAMBU_MAPPINGS[k].cura}`}>applied</b> : <b className="badge carried">carried</b>}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              ) : null}
              <button className="slicer-link" onClick={() => { setImported(EMPTY_IMPORT); setApplied(new Set()); setSettings(DEFAULTS); }}>Clear imported settings</button>
            </div>
          ) : null}
        </section>

        <Group title="Printer">
          <div className="slicer-printer">{printerLabel}<small>{bed.width} × {bed.depth} × {bed.height} mm</small></div>
          {plateCount > 1 ? (
            <Field label="Plate"><select value={plate} onChange={(e) => onPlateChange(Number(e.target.value))} disabled={busy}>
              {Array.from({ length: plateCount }, (_, i) => <option key={i} value={i + 1}>Plate {i + 1}</option>)}
            </select></Field>
          ) : null}
          <Field label="Nozzle diameter" bambuKey="nozzle_diameter" applied={applied.has("nozzle_diameter")}>
            <select value={settings.nozzle ?? 0.4} onChange={(e) => set({ nozzle: Number(e.target.value) })} disabled={busy}>
              {[0.2, 0.4, 0.6, 0.8].map((v) => <option key={v} value={v}>{v} mm</option>)}
            </select>
          </Field>
          {numField("Retraction length", "retractLength", "mm", 0, 15, 0.1, "retraction_length")}
          {numField("Retraction speed", "retractSpeed", "mm/s", 5, 150, 1, "retraction_speed")}
        </Group>

        <Group title={`Filament${slots.length > 1 ? `s (${slots.length})` : ""}`}>
          {slots.map((slot, i) => (
            <div className="slicer-slot" key={i}>
              <span className="slicer-slot-num" style={{ background: slot.color }}>{i + 1}</span>
              <select value={slot.materialId} onChange={(e) => { const m = bambuMaterial(e.target.value); setSlots((cur) => cur.map((s, j) => (j === i ? { ...s, materialId: m.id, materialName: m.name, type: m.type } : s))); setResult(null); }} disabled={busy} aria-label={`Slot ${i + 1} material`}>
                {groups.map((g) => <optgroup key={g.label} label={g.label}>{g.items.map((m) => <option key={m.id} value={m.id}>Bambu {m.name}</option>)}</optgroup>)}
              </select>
              <small>{slot.colorName ?? slot.color}</small>
            </div>
          ))}
          {slots.length > 1 ? <p className="export-setting-note">CuraEngine slices with one extruder: slot 1 sets the temperatures here. The 3MF keeps every slot for an AMS.</p> : null}
          {numField("Nozzle temperature", "nozzleTemp", "°C", 150, 350, 1, "nozzle_temperature")}
          {numField("Nozzle temp · initial layer", "nozzleTempFirst", "°C", 150, 350, 1, "nozzle_temperature_initial_layer")}
          {numField("Textured PEI Plate temp", "bedTemp", "°C", 0, 130, 1, "textured_plate_temp")}
          {numField("Fan max speed", "fanSpeed", "%", 0, 100, 5, "fan_max_speed")}
        </Group>

        <Group title="Process">
          <Field label="Preset"><select value={preset} onChange={(e) => choosePreset(e.target.value as SlicerPresetId)} disabled={busy} data-testid="slicer-preset">
            {Object.entries(PRESETS).map(([id, p]) => <option key={id} value={id}>{p.label}</option>)}
          </select></Field>
          <nav className="slicer-process-tabs">
            {(["quality", "strength", "speed", "support", "others"] as ProcessTab[]).map((id) => <button key={id} className={tab === id ? "active" : ""} onClick={() => setTab(id)}>{id[0].toUpperCase() + id.slice(1)}</button>)}
          </nav>
          {tab === "quality" ? (<>
            <Field label="Layer height" bambuKey="layer_height" applied={applied.has("layer_height")}>
              <select value={settings.layerHeight} onChange={(e) => set({ layerHeight: Number(e.target.value) })} disabled={busy}>
                {[...new Set([0.08, 0.12, 0.16, 0.2, 0.24, 0.28, settings.layerHeight])].sort().map((v) => <option key={v} value={v}>{v.toFixed(2)} mm</option>)}
              </select>
            </Field>
            {numField("Initial layer height", "firstLayerHeight", "mm", 0.08, 0.6, 0.02, "initial_layer_print_height")}
            <Field label="Seam position" bambuKey="seam_position" applied={applied.has("seam_position")}>
              <select value={settings.seam} onChange={(e) => set({ seam: e.target.value as SliceSettings["seam"] })} disabled={busy}>
                <option value="sharpest_corner">Aligned</option><option value="shortest">Nearest</option><option value="back">Back</option><option value="random">Random</option>
              </select>
            </Field>
            <Field label="Ironing type" bambuKey="ironing_type" applied={applied.has("ironing_type")}>
              <select value={settings.ironing ? "top" : "no"} onChange={(e) => set({ ironing: e.target.value === "top" })} disabled={busy}>
                <option value="no">No ironing</option><option value="top">Top surfaces</option>
              </select>
            </Field>
          </>) : null}
          {tab === "strength" ? (<>
            {numField("Wall loops", "walls", "", 1, 20, 1, "wall_loops")}
            {numField("Top shell layers", "topLayers", "", 0, 50, 1, "top_shell_layers")}
            {numField("Bottom shell layers", "bottomLayers", "", 0, 50, 1, "bottom_shell_layers")}
            <Field label="Sparse infill density" bambuKey="sparse_infill_density" applied={applied.has("sparse_infill_density")}>
              <span className="slicer-inline"><input type="range" min={0} max={100} step={5} value={settings.infill} onChange={(e) => set({ infill: Number(e.target.value) })} disabled={busy} /><b>{settings.infill}%</b></span>
            </Field>
            <Field label="Sparse infill pattern" bambuKey="sparse_infill_pattern" applied={applied.has("sparse_infill_pattern")}>
              <select value={settings.infillPattern} onChange={(e) => set({ infillPattern: e.target.value as SliceSettings["infillPattern"] })} disabled={busy}>
                {[["grid", "Grid"], ["lines", "Line"], ["zigzag", "Zig Zag"], ["triangles", "Triangles"], ["trihexagon", "Tri-hexagon"], ["cubic", "Cubic"], ["quarter_cubic", "Quarter Cubic"], ["gyroid", "Gyroid"], ["concentric", "Concentric"], ["lightning", "Lightning (sliced as Line)"]].map(([v, l]) => <option key={v} value={v}>{l}</option>)}
              </select>
            </Field>
          </>) : null}
          {tab === "speed" ? (<>
            {numField("Initial layer", "speedFirstLayer", "mm/s", 5, 500, 5, "initial_layer_speed")}
            {numField("Outer wall", "speedOuterWall", "mm/s", 5, 1000, 5, "outer_wall_speed")}
            {numField("Inner wall", "speedInnerWall", "mm/s", 5, 1000, 5, "inner_wall_speed")}
            {numField("Sparse infill", "speedInfill", "mm/s", 5, 1000, 5, "sparse_infill_speed")}
            {numField("Travel", "speedTravel", "mm/s", 20, 1500, 10, "travel_speed")}
          </>) : null}
          {tab === "support" ? (<>
            <Field label="Enable support" bambuKey="enable_support" applied={applied.has("enable_support")}>
              <input type="checkbox" checked={settings.supports} onChange={(e) => set({ supports: e.target.checked })} disabled={busy} data-testid="slicer-supports" />
            </Field>
            <Field label="Type" bambuKey="support_type" applied={applied.has("support_type")}>
              <select value={settings.supportStyle} onChange={(e) => set({ supportStyle: e.target.value as "normal" | "tree" })} disabled={busy}>
                <option value="normal">normal(auto)</option><option value="tree">tree(auto)</option>
              </select>
            </Field>
            <Field label="Threshold angle" bambuKey="support_threshold_angle" applied={applied.has("support_threshold_angle")}>
              <span className="slicer-num"><input type="number" min={1} max={89} value={90 - (settings.supportAngle ?? 60)} onChange={(e) => set({ supportAngle: 90 - Math.max(1, Math.min(89, Number(e.target.value) || 30)) })} disabled={busy} /><i>°</i></span>
            </Field>
            <Field label="On build plate only" bambuKey="support_on_build_plate_only" applied={applied.has("support_on_build_plate_only")}>
              <input type="checkbox" checked={settings.supportBuildplateOnly ?? false} onChange={(e) => set({ supportBuildplateOnly: e.target.checked })} disabled={busy} />
            </Field>
          </>) : null}
          {tab === "others" ? (<>
            <Field label="Bed adhesion" bambuKey="brim_type" applied={applied.has("brim_type") || applied.has("skirt_loops")}>
              <select value={settings.adhesion} onChange={(e) => set({ adhesion: e.target.value as SliceSettings["adhesion"] })} disabled={busy}>
                <option value="skirt">Skirt (1 loop)</option><option value="brim">Brim (outer only)</option><option value="none">None</option>
              </select>
            </Field>
            {settings.adhesion === "brim" ? numField("Brim width", "brimWidth", "mm", 0, 30, 0.5, "brim_width") : null}
          </>) : null}
        </Group>
      </aside>

      <main className="slicer-main">
        <div className="slicer-canvas" ref={canvasHost} data-testid="slicer-preview" />
        {status && !busy ? <div className="slicer-status">{status}</div> : null}
        {busy ? <div className="slicer-status">{status ?? "Slicing…"} {progress ? `${progress}%` : ""}</div> : null}
        {error ? <p className="slicer-error slicer-floating-error" role="alert">{error}</p> : null}
        {view === "preview" && result ? (
          <>
            <div className="slicer-stats" data-testid="slicer-stats">
              <div><span>Total time</span><b>{formatDurationLocal(result.printTimeSec)}</b></div>
              <div><span>Filament</span><b>{(result.filamentMm / 1000).toFixed(2)} m · {result.filamentG.toFixed(1)} g</b></div>
              <div><span>Material</span><b>{temps ? `${slots[0]?.materialName ?? temps.type} ${settings.nozzleTemp ?? temps.nozzle}° / ${settings.bedTemp ?? temps.bed}°` : ""}</b></div>
              <div><span>Layers</span><b>{layers} · {result.parsed.layerZ[layer]?.toFixed(2)} mm</b></div>
            </div>
            <label className="slicer-layer-bar">Layer <b>{layer + 1} / {layers}</b>
              <input type="range" min={0} max={Math.max(0, layers - 1)} value={layer} onChange={(e) => setLayer(Number(e.target.value))} data-testid="slicer-layer" />
            </label>
          </>
        ) : null}
        {view === "prepare" && input ? <div className="slicer-plate-tag">Plate {plate}{plateCount > 1 ? ` of ${plateCount}` : ""} · {(() => { const n = slots.reduce((t, s) => t + s.count, 0); return `${n} ${n === 1 ? "body" : "bodies"}`; })()}</div> : null}
        {toast ? <div className="slicer-toast" role="status" data-testid="slicer-toast">{toast}</div> : null}
        <p className="slicer-footnote">Preview only: sliced in your browser with CuraEngine (AGPL-3.0). Send the Export 3MF to Bambu Studio to print.</p>
      </main>
    </div>
  );
}

function Group({ title, children }: { title: string; children: ReactNode }) {
  return (
    <details className="slicer-group" open>
      <summary>{title}</summary>
      <div className="slicer-group-body">{children}</div>
    </details>
  );
}

function Field({ label, bambuKey, applied, children }: { label: string; bambuKey?: string; applied?: boolean; children: ReactNode }) {
  return (
    <label className="slicer-row" title={bambuKey ? `Bambu Studio key: ${bambuKey}` : undefined}>
      <span>{label}{applied ? <b className="badge applied" title="Set by imported settings">imported</b> : null}</span>
      {children}
    </label>
  );
}

function formatDurationLocal(sec: number) {
  const h = Math.floor(sec / 3600);
  const m = Math.round((sec % 3600) / 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

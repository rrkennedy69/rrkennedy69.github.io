"use client";

import { useMemo, type CSSProperties } from "react";
import { BAMBU_MATERIALS, bambuMaterial, bambuMaterialGroups, DEFAULT_BAMBU_MATERIAL } from "@/lib/bambuFilaments";
import { useLoadedFilaments } from "@/lib/loadedFilaments";
import type { ShapeFilament } from "@/types/layerling";

/** Material dropdown plus Bambu Lab's own colours for it, with their names. */
export function BambuFilamentPicker({ filament, color, disabled, onMaterial, onColor }: {
  filament: ShapeFilament | undefined | null;
  color: string | null;
  disabled?: boolean;
  onMaterial: (material: string) => void;
  onColor: (patch: { color: string; filament: ShapeFilament }) => void;
}) {
  const materialId = filament?.material ?? DEFAULT_BAMBU_MATERIAL;
  const material = bambuMaterial(materialId);
  const groups = useMemo(() => bambuMaterialGroups(), []);
  const loaded = useLoadedFilaments();
  const current = color?.toLowerCase();
  const named = filament?.name && material.colors.find((c) => c.n === filament.name && c.h.toLowerCase() === current);
  return (
    <div className="bambu-filament" data-testid="bambu-filament">
      {loaded?.filaments.length ? (
        <div className="loaded-filaments" data-testid="currently-loaded">
          <div className="bambu-color-caption"><span>Currently Loaded</span><span className="bambu-color-name">{loaded.filaments.length} from Bambu Studio</span></div>
          <div className="loaded-filaments-picks" role="list">
            {loaded.filaments.map((f) => {
              const selected = current === f.color && (filament?.material ?? "") === (f.materialId ?? filament?.material ?? "");
              return (
                <button key={f.slot} type="button" role="listitem" className={`loaded-pick${selected ? " selected" : ""}`} disabled={disabled}
                  title={`Slot ${f.slot} · ${f.colorName ?? f.color} · ${f.name} (${f.type})`} aria-label={`Loaded slot ${f.slot} ${f.colorName ?? f.color} ${f.name}`}
                  onClick={() => onColor({ color: f.color, filament: { ...(f.materialId ? { material: f.materialId } : filament?.material ? { material: filament.material } : {}), ...(f.colorName ? { name: f.colorName } : {}), ...(f.code ? { code: f.code } : {}) } })}>
                  <span className="loaded-swatch" style={{ "--shape-swatch": f.color } as CSSProperties} />
                  <span className="loaded-pick-text"><b>{f.colorName ?? f.color}</b><small>{f.name.toUpperCase().includes(f.type.toUpperCase()) ? f.name : `${f.type} ${f.name}`} · slot {f.slot}</small></span>
                </button>
              );
            })}
          </div>
        </div>
      ) : null}
      <label className="bambu-material-row">
        <span>Material</span>
        <select value={material.id} disabled={disabled} onChange={(e) => onMaterial(e.target.value)} aria-label="Material type">
          {groups.map((g) => (
            <optgroup key={g.label} label={g.label}>
              {g.items.map((m) => <option key={m.id} value={m.id}>Bambu {m.name}</option>)}
            </optgroup>
          ))}
        </select>
      </label>
      {material.colors.length ? (
        <>
          <div className="bambu-color-caption">
            <span>Bambu {material.name} colours</span>
            <span className="bambu-color-name">{named ? `${named.n} ${named.h}` : filament?.name === undefined ? "Custom" : ""}</span>
          </div>
          <div className="bambu-color-grid" role="list">
            {material.colors.map((c) => (
              <button
                key={`${c.n}-${c.c}`}
                type="button"
                role="listitem"
                className={named === c ? "selected" : ""}
                style={{ "--shape-swatch": c.g ? `linear-gradient(135deg, ${c.g.join(", ")})` : c.h } as CSSProperties}
                title={`${c.n} · ${c.h}${c.c ? ` · ${c.c}` : ""}`}
                aria-label={`Bambu ${material.name} ${c.n} ${c.h}`}
                disabled={disabled}
                onClick={() => onColor({ color: c.h.toLowerCase(), filament: { material: material.id, name: c.n, code: c.c || undefined } })}
              />
            ))}
          </div>
        </>
      ) : <p className="bambu-color-caption">No Bambu colour list for this material; pick a custom colour.</p>}
    </div>
  );
}

export const BAMBU_MATERIAL_COUNT = BAMBU_MATERIALS.length;

"use client";

import { useEffect, useState } from "react";
import { AI_PRESETS, AI_SETTINGS_EVENT, LOCAL_MODELS, maskKey, readAiSettings, writeAiSettings, type AiSettings } from "@/lib/aiSettings";
import { webGpuAvailable } from "@/lib/aiActions";

/** Settings › AI: on-device model or the user's own API key (kept only in this browser). */
export function AiSettingsSection() {
  const [s, setS] = useState<AiSettings>(() => readAiSettings());
  const [editingKey, setEditingKey] = useState(false);
  const [draftKey, setDraftKey] = useState("");
  useEffect(() => {
    const read = () => setS(readAiSettings());
    window.addEventListener(AI_SETTINGS_EVENT, read);
    return () => window.removeEventListener(AI_SETTINGS_EVENT, read);
  }, []);
  const patch = (p: Partial<AiSettings>) => { const next = { ...s, ...p }; setS(next); writeAiSettings(next); };
  const preset = AI_PRESETS.find((p) => p.baseUrl === s.baseUrl && p.provider === s.provider)?.id ?? "custom";
  const gpu = webGpuAvailable();
  return (
    <div className="ai-settings" data-testid="settings-ai">
      <div className="ai-settings-group">
        <label className="ai-settings-radio">
          <input type="radio" name="ai-backend" checked={s.provider === "local"} onChange={() => patch({ provider: "local" })} />
          <span><b>Free, on this device</b><small>Runs a small AI model in the browser with WebGPU{gpu ? "" : " - not available in this browser, so only simple commands work"}. Downloaded once when first used, after you agree.</small></span>
        </label>
        {s.provider === "local" ? (
          <div className="ai-settings-row">
            <span>Model</span>
            <select value={s.localModel} onChange={(e) => patch({ localModel: e.target.value })}>
              {LOCAL_MODELS.map((m) => <option key={m.id} value={m.id}>{m.label} · ~{m.downloadMb >= 1000 ? `${(m.downloadMb / 1000).toFixed(1)} GB` : `${m.downloadMb} MB`}</option>)}
            </select>
          </div>
        ) : null}
        <label className="ai-settings-radio">
          <input type="radio" name="ai-backend" checked={s.provider !== "local"} onChange={() => patch({ provider: AI_PRESETS.find((p) => p.id === preset)?.provider ?? "openai-compatible" })} />
          <span><b>My own API key</b><small>xAI, OpenAI, Anthropic or any OpenAI-compatible service. Smarter, and it can look at the area you select.</small></span>
        </label>
      </div>
      {s.provider !== "local" ? (
        <div className="ai-settings-group">
          <div className="ai-settings-row">
            <span>Service</span>
            <select data-testid="ai-preset" value={preset} onChange={(e) => { const p = AI_PRESETS.find((x) => x.id === e.target.value)!; patch({ provider: p.provider, baseUrl: p.baseUrl, model: p.model }); }}>
              {AI_PRESETS.map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}
            </select>
          </div>
          <div className="ai-settings-row"><span>Base URL</span><input data-testid="ai-base-url" value={s.baseUrl} spellCheck={false} onChange={(e) => patch({ baseUrl: e.target.value.trim() })} /></div>
          <div className="ai-settings-row"><span>Model</span><input data-testid="ai-model" value={s.model} spellCheck={false} onChange={(e) => patch({ model: e.target.value.trim() })} /></div>
          <div className="ai-settings-row">
            <span>API key</span>
            {editingKey ? (
              <>
                <input data-testid="ai-key-input" type="password" autoComplete="off" value={draftKey} placeholder="Paste your key" onChange={(e) => setDraftKey(e.target.value)} />
                <button type="button" data-testid="ai-key-save" onClick={() => { patch({ apiKey: draftKey.trim() }); setDraftKey(""); setEditingKey(false); }}>Save</button>
              </>
            ) : (
              <>
                <code data-testid="ai-key-masked">{s.apiKey ? maskKey(s.apiKey) : "not set"}</code>
                <button type="button" data-testid="ai-key-edit" onClick={() => setEditingKey(true)}>{s.apiKey ? "Change" : "Add key"}</button>
                {s.apiKey ? <button type="button" onClick={() => patch({ apiKey: "" })}>Remove</button> : null}
              </>
            )}
          </div>
          <label className="ai-settings-check"><input type="checkbox" checked={s.vision} onChange={(e) => patch({ vision: e.target.checked })} /> Send a picture of the selected area (for models that can see)</label>
          <p className="ai-settings-note">🔒 Your key is stored only on this device (in this browser&apos;s local storage) and is sent directly from your browser to {(() => { try { return new URL(s.baseUrl).host; } catch { return "the service"; } })()}. PrintCaddy&apos;s servers never see it. The service bills you for what you use.</p>
        </div>
      ) : null}
      <p className="ai-settings-note">The AI can only use PrintCaddy&apos;s own tools (add, move, rotate, scale, colour, fillet, hole, group, pattern, align, arrange, delete). It never runs code, and every change is shown first and undoes in one step.</p>
    </div>
  );
}

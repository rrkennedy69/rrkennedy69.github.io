"use client";

import { useEffect, useState } from "react";

/** The iPad app's own updater (set by its wrapper script, ios-shim.js); absent on the website. */
type PrintCaddyAppBridge = {
  info: () => { webBuild: string; nativeVersion: string };
  check: () => Promise<{ available: boolean; build?: string; error?: string }>;
  install: () => Promise<void>;
  nativeUpdateUrl: string;
  altStoreSourceUrl: string;
};

function bridge(): PrintCaddyAppBridge | undefined {
  return typeof window === "undefined" ? undefined : (window as unknown as { PrintCaddyApp?: PrintCaddyAppBridge }).PrintCaddyApp;
}

/** Settings > Mobile & touch, in the iPad app only: version line, Check for updates, native app link. */
export function IpadAppUpdates() {
  const [app, setApp] = useState<PrintCaddyAppBridge | undefined>(undefined);
  const [status, setStatus] = useState("");
  const [newBuild, setNewBuild] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => setApp(bridge()), []);
  if (!app) return null;
  const info = app.info();
  const check = async () => {
    setBusy(true); setStatus("Checking…");
    try {
      const result = await app.check();
      if (result.error) setStatus(`Could not check: ${result.error}`);
      else if (result.available && result.build) { setNewBuild(result.build); setStatus(`Update available: ${result.build}`); }
      else { setNewBuild(null); setStatus("You have the latest version."); }
    } finally { setBusy(false); }
  };
  const install = async () => {
    setBusy(true); setStatus("Downloading update… the app restarts when it is ready.");
    try { await app.install(); } catch (error) { setStatus(`Update failed: ${error instanceof Error ? error.message : String(error)}`); setBusy(false); }
  };
  return (
    <div className="workspace-section-heading" data-testid="ipad-app-updates" style={{ display: "grid", gap: 8 }}>
      <strong>PrintCaddy app updates</strong>
      <span>App build {info.webBuild || "unknown"} · app shell {info.nativeVersion || "?"}</span>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        <button type="button" disabled={busy} onClick={check}>Check for updates</button>
        {newBuild ? <button type="button" disabled={busy} onClick={install}>Install update</button> : null}
        <a href={app.nativeUpdateUrl} target="_blank" rel="noreferrer">Native app update (.ipa)</a>
      </div>
      {status ? <span>{status}</span> : null}
    </div>
  );
}

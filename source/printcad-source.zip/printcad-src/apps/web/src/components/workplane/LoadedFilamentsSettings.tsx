"use client";

import { useRef, useState, type CSSProperties } from "react";
import { FileUp, Trash2 } from "lucide-react";
import { EMPTY_IMPORT, importBambuFile, type BambuImported } from "@/lib/bambuSettingsImport";
import { extractLoadedFilaments, useLoadedFilaments, writeLoadedFilaments } from "@/lib/loadedFilaments";

/** Settings: "Import from Bambu Studio" fills the "Currently Loaded" filaments shown at the top of the colour picker. */
export function LoadedFilamentsSettings() {
  const state = useLoadedFilaments();
  const fileRef = useRef<HTMLInputElement>(null);
  const [message, setMessage] = useState<string | null>(null);
  const run = async (files: FileList | null) => {
    if (!files?.length) return;
    let imported: BambuImported = EMPTY_IMPORT;
    try {
      for (const f of Array.from(files)) imported = await importBambuFile(f, imported);
      const filaments = extractLoadedFilaments(imported);
      if (!filaments.length) { setMessage("No filaments found in that file. Use a Bambu Studio project (.3mf), a .bbscfg / .bbsflmt bundle or a filament preset .json."); return; }
      writeLoadedFilaments({ filaments, source: Array.from(files).map((f) => f.name).join(", "), importedAt: new Date().toISOString() });
      setMessage(`${filaments.length} filament${filaments.length === 1 ? "" : "s"} loaded.`);
    } catch (e) { setMessage(e instanceof Error ? e.message : String(e)); }
  };
  return (
    <div className="loaded-filaments-settings" data-testid="loaded-filaments-settings">
      <div className="ai-row" style={{ justifyContent: "flex-start" }}>
        <button type="button" className="primary" data-testid="import-bambu-filaments" onClick={() => fileRef.current?.click()}><FileUp size={15} /> {state ? "Re-import from Bambu Studio" : "Import from Bambu Studio"}</button>
        {state ? <button type="button" data-testid="clear-loaded-filaments" onClick={() => { writeLoadedFilaments(null); setMessage("Currently Loaded cleared."); }}><Trash2 size={15} /> Clear</button> : null}
      </div>
      <input ref={fileRef} type="file" hidden multiple accept=".3mf,.json,.bbscfg,.bbsflmt,.zip" data-testid="import-bambu-filaments-input" onChange={(e) => { void run(e.currentTarget.files); e.currentTarget.value = ""; }} />
      <small className="ai-settings-note">Bambu Studio project (.3mf), .bbscfg / .bbsflmt bundle, or filament preset .json. Kept only in this browser.</small>
      {message ? <p className="loaded-filaments-msg" role="status" data-testid="loaded-filaments-msg">{message}</p> : null}
      {state ? (
        <ul className="loaded-filaments-list">
          {state.filaments.map((f) => (
            <li key={f.slot}>
              <span className="loaded-swatch" style={{ "--shape-swatch": f.color } as CSSProperties} />
              <b>{f.slot}</b>
              <span>{f.colorName ?? f.color} · {f.name}</span>
              <small>{f.type}</small>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

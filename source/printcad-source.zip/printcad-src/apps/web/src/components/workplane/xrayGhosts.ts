import * as THREE from "three";

/**
 * X-Ray easter egg: now and then a faint ghost drifts across the 3D background (behind the plate and
 * every body), then fades out. Screen-pass only: never picked, never exported, never saved, X-Ray only.
 * Test hook: window.__xrayGhost(variant?) forces one, part-way across, for a screenshot.
 */
type Ghost = { variant: number; start: number; dur: number; y: number; dir: 1 | -1; size: number };
let ghost: Ghost | null = null;
let nextAt = 0;
let pass: { scene: THREE.Scene; camera: THREE.OrthographicCamera; mesh: THREE.Mesh; material: THREE.MeshBasicMaterial; textures: THREE.Texture[] } | null = null;

function drawGhost(variant: number) {
  const c = document.createElement("canvas"); c.width = 128; c.height = 160;
  const g = c.getContext("2d")!;
  g.translate(64, 0);
  g.beginPath();
  const w = variant === 1 ? 40 : 46, top = variant === 2 ? 26 : 18;
  g.moveTo(-w, 92); g.bezierCurveTo(-w, top - 10, w, top - 10, w, 92);
  // wavy tail: 3 or 4 scallops
  const n = variant === 1 ? 3 : 4, base = variant === 2 ? 140 : 132;
  g.lineTo(w, base);
  for (let i = 0; i < n; i++) { const x0 = w - (2 * w / n) * i, x1 = x0 - 2 * w / n; g.quadraticCurveTo((x0 + x1) / 2, base - 18 + (i % 2) * 6, x1, base); }
  g.closePath();
  if (variant === 1) { g.moveTo(w - 4, 70); g.quadraticCurveTo(w + 18, 60, w + 14, 44); g.quadraticCurveTo(w + 8, 66, w - 4, 80); } // little waving arm
  const fill = g.createRadialGradient(0, 70, 4, 0, 80, 70);
  fill.addColorStop(0, "rgba(230,224,255,0.10)"); fill.addColorStop(1, "rgba(200,190,255,0.35)");
  g.fillStyle = fill; g.shadowColor = "rgba(190,180,255,0.9)"; g.shadowBlur = 12; g.fill();
  g.shadowBlur = 0; g.lineWidth = 3; g.strokeStyle = "rgba(240,236,255,0.85)"; g.stroke();
  // eyes (and a small "o" mouth on variant 2)
  g.fillStyle = "rgba(20,14,60,0.9)";
  const ey = variant === 2 ? 66 : 60;
  g.beginPath(); g.ellipse(-14, ey, 6, 9, 0, 0, Math.PI * 2); g.ellipse(14, ey, 6, 9, 0, 0, Math.PI * 2); g.fill();
  if (variant === 2) { g.beginPath(); g.ellipse(0, ey + 22, 5, 6, 0, 0, Math.PI * 2); g.fill(); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

function getPass() {
  if (!pass) {
    const textures = [0, 1, 2].map(drawGhost);
    const material = new THREE.MeshBasicMaterial({ map: textures[0], transparent: true, blending: THREE.AdditiveBlending, depthTest: false, depthWrite: false, opacity: 0 });
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(1, 1.25), material);
    const scene = new THREE.Scene(); scene.add(mesh);
    pass = { scene, camera: new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1), mesh, material, textures };
  }
  return pass;
}

function spawn(now: number, progress = 0, variant = Math.floor(Math.random() * 3)) {
  const dur = 12000 + Math.random() * 6000;
  ghost = { variant, dur, start: now - progress * dur, y: 0.25 + Math.random() * 0.45, dir: Math.random() < 0.5 ? 1 : -1, size: 0.24 + Math.random() * 0.08 };
}

/** Called every animation frame; true while a ghost is on screen so the idle view keeps redrawing. */
export function xrayGhostTick(now: number, xray: boolean) {
  if (!xray) { ghost = null; nextAt = 0; return false; }
  if (!nextAt) nextAt = now + 20000 + Math.random() * 40000;
  if (!ghost && now >= nextAt) spawn(now);
  if (ghost && now - ghost.start > ghost.dur) { ghost = null; nextAt = now + 20000 + Math.random() * 40000; return true; }
  return !!ghost;
}

/** Draws the ghost into the current target before the scene; aspect = width / height. */
export function drawXrayGhost(renderer: THREE.WebGLRenderer, aspect: number, now = performance.now()) {
  if (!ghost) return;
  const p = getPass();
  const t = (now - ghost.start) / ghost.dur;
  if (t < 0 || t > 1) return;
  const fadeIn = Math.min(1, t / 0.12), fadeOut = t > 0.45 ? 1 - (t - 0.45) / 0.55 : 1; // ~7s fade at the end
  p.material.map = p.textures[ghost.variant]; p.material.opacity = 0.55 * fadeIn * Math.max(0, fadeOut);
  const x = ghost.dir * (-1.25 + 2.5 * t);
  p.mesh.position.set(x, ghost.y + Math.sin(now / 900) * 0.03, 0);
  p.mesh.scale.set(ghost.size / aspect * (ghost.dir < 0 ? -1 : 1), ghost.size, 1);
  p.mesh.rotation.z = Math.sin(now / 1300) * 0.08;
  renderer.render(p.scene, p.camera);
}

if (typeof window !== "undefined") {
  (window as unknown as Record<string, unknown>).__xrayGhost = (variant?: number) => { spawn(performance.now(), 0.3, variant ?? Math.floor(Math.random() * 3)); if (ghost) ghost.y = 0.55; nextAt = Infinity; };
}

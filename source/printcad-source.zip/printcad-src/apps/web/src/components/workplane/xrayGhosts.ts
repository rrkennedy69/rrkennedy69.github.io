import * as THREE from "three";

/**
 * X-Ray easter egg: now and then a spirit drifts through the 3D scene in world space, then fades.
 * Two original kinds, mixed at random:
 *  - Sheet ghosts (variants 0, 1): a glowing draped sheet with hollow eyes and outstretched arms whose
 *    long fibrous cloth streams behind it (vertex-animated ribbons, additive, soft edged).
 *  - Stranded figures (variants 2, 3): tall, thin, dark faceless silhouettes with an oily iridescent
 *    sheen, floating upright with thin tethers dangling toward the floor and faint dark handprints
 *    fading where they pass.
 * Rendered as a separate pass: never picked, never exported, never saved, X-Ray only.
 * Test hook: window.__xrayGhost(variant?, progress?, freeze?) forces one at a point along its path.
 */
type Ghost = { variant: number; start: number; dur: number; seed: number; dir: 1 | -1; frozen?: number; radius: number; angle0: number; sweep: number; y: number; faceAt: number; size: number };
let ghost: Ghost | null = null;
let nextAt = 0;
let lastView: number[] = [];
const isBT = (v: number) => v >= 2;

type Pass = {
  scene: THREE.Scene; sheet: THREE.Group; bt: THREE.Group; prints: THREE.Mesh[];
  sheetMat: THREE.ShaderMaterial; trailMat: THREE.ShaderMaterial; btMat: THREE.ShaderMaterial; tetherMat: THREE.ShaderMaterial; printMats: THREE.ShaderMaterial[];
  sheetTex: THREE.Texture[]; btTex: THREE.Texture[];
};
let pass: Pass | null = null;
const PRINTS = 10;

function tex(c: HTMLCanvasElement) { const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; }

/** Head, sheet body and arms of a sheet ghost (the streaming cloth is separate geometry). */
function drawSheet(variant: number) {
  const W = 256, H = 256, c = document.createElement("canvas"); c.width = W; c.height = H;
  const g = c.getContext("2d")!; g.translate(W / 2, 0);
  const hy = 70, hr = 40, arm = variant === 1 ? 104 : 96, armY = variant === 1 ? 118 : 128;
  g.beginPath();
  g.moveTo(-hr, hy);
  g.arc(0, hy, hr, Math.PI, 0);
  // Right shoulder flowing out into a draped arm, then the sheet narrowing into the hem.
  g.bezierCurveTo(hr + 6, hy + 30, arm - 30, armY - 26, arm, armY - 10);
  g.bezierCurveTo(arm + 12, armY, arm - 8, armY + 18, arm - 30, armY + 12);
  g.bezierCurveTo(56, armY + 14, 50, 200, 34, 250);
  g.lineTo(-34, 250);
  g.bezierCurveTo(-50, 200, -56, armY + 14, -arm + 30, armY + 12);
  g.bezierCurveTo(-arm + 8, armY + 18, -arm - 12, armY, -arm, armY - 10);
  g.bezierCurveTo(-arm + 30, armY - 26, -hr - 6, hy + 30, -hr, hy);
  g.closePath();
  const fill = g.createRadialGradient(0, hy, 10, 0, hy + 60, 190);
  fill.addColorStop(0, "rgba(246,244,255,0.85)"); fill.addColorStop(0.45, "rgba(205,196,255,0.45)"); fill.addColorStop(1, "rgba(170,160,255,0.0)");
  g.fillStyle = fill; g.shadowColor = "rgba(210,200,255,1)"; g.shadowBlur = 22; g.fill();
  g.shadowBlur = 0; g.save(); g.clip();
  // Fine fibre lines in the cloth, flowing down from the head.
  g.strokeStyle = "rgba(255,255,255,0.22)"; g.lineWidth = 0.8;
  for (let i = -14; i <= 14; i++) { g.beginPath(); g.moveTo(i * 3, hy - 20); g.bezierCurveTo(i * 5, 150, i * 7 + 8 * Math.sin(i), 200, i * 4, 256); g.stroke(); }
  g.restore();
  g.lineWidth = 1.4; g.strokeStyle = "rgba(240,236,255,0.55)"; g.stroke();
  // Big dark hollow eyes and a small mouth (cut out so the background shows through).
  g.globalCompositeOperation = "destination-out";
  const eyeH = variant === 1 ? 17 : 15;
  for (const s of [-1, 1]) { g.beginPath(); g.ellipse(s * 15, hy + 2, 10, eyeH, s * -0.12, 0, Math.PI * 2); g.fill(); }
  g.beginPath(); g.ellipse(0, hy + 28, 4.5, variant === 1 ? 6 : 4, 0, 0, Math.PI * 2); g.fill();
  g.globalCompositeOperation = "source-over";
  // Soft glowing rims on the sockets.
  g.strokeStyle = "rgba(225,215,255,0.5)"; g.lineWidth = 1.5;
  for (const s of [-1, 1]) { g.beginPath(); g.ellipse(s * 15, hy + 2, 11, eyeH + 1, s * -0.12, 0, Math.PI * 2); g.stroke(); }
  return tex(c);
}

/** Tall, thin, faceless silhouette: alpha mask; colour comes from the shader. */
function drawBT(variant: number) {
  const W = 128, H = 384, c = document.createElement("canvas"); c.width = W; c.height = H;
  const g = c.getContext("2d")!; g.translate(W / 2, 0);
  g.filter = "blur(2.5px)"; g.fillStyle = "#fff";
  const hy = 34, sh = variant === 3 ? 22 : 19;
  g.beginPath(); g.ellipse(0, hy, 11, 15, 0, 0, Math.PI * 2); g.fill();
  g.beginPath();
  g.moveTo(-5, hy + 12); g.lineTo(5, hy + 12);
  g.bezierCurveTo(sh, hy + 26, sh + 2, hy + 40, sh - 3, 150);
  g.bezierCurveTo(sh - 6, 220, 10, 280, 6, 360);
  g.lineTo(-6, 360);
  g.bezierCurveTo(-10, 280, -sh + 6, 220, -sh + 3, 150);
  g.bezierCurveTo(-sh - 2, hy + 40, -sh, hy + 26, -5, hy + 12);
  g.fill();
  // Long, thin arms hanging almost to the knees, fingers trailing off.
  g.lineCap = "round"; g.strokeStyle = "#fff";
  for (const s of [-1, 1]) {
    g.lineWidth = 6; g.beginPath(); g.moveTo(s * (sh - 2), hy + 30);
    g.bezierCurveTo(s * (sh + 10), 120, s * (sh + 12), 180, s * (sh + 8 + (variant === 3 ? 6 : 0)), 238); g.stroke();
    g.lineWidth = 2; for (let f = -1; f <= 1; f++) { g.beginPath(); g.moveTo(s * (sh + 8), 236); g.lineTo(s * (sh + 8 + f * 3), 262 + Math.abs(f) * -4); g.stroke(); }
  }
  return tex(c);
}

function drawHand() {
  const c = document.createElement("canvas"); c.width = c.height = 64;
  const g = c.getContext("2d")!; g.filter = "blur(1.6px)"; g.fillStyle = "#fff";
  g.beginPath(); g.ellipse(32, 40, 11, 13, 0, 0, Math.PI * 2); g.fill();
  const fingers: [number, number, number, number][] = [[18, 32, -0.9, 9], [23, 20, -0.25, 12], [31, 16, 0, 14], [39, 18, 0.2, 13], [45, 24, 0.45, 10]];
  for (const [x, y, a, l] of fingers) { g.save(); g.translate(x, y); g.rotate(a); g.beginPath(); g.ellipse(0, 0, 3, l / 1.4, 0, 0, Math.PI * 2); g.fill(); g.restore(); }
  return tex(c);
}

const sheetVS = `uniform float time; varying vec2 vUv;
  void main(){ vUv = uv; vec3 p = position; float low = clamp(0.6 - uv.y, 0.0, 1.0);
    p.x += sin(uv.y * 8.0 + time * 2.1) * 0.03 * low; p.z += sin(uv.x * 5.0 + time * 1.6) * 0.05 * low;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0); }`;
const sheetFS = `uniform sampler2D map; uniform float opacity; uniform vec3 tint; varying vec2 vUv;
  void main(){ vec4 c = texture2D(map, vUv); vec3 col = c.rgb * tint;
    gl_FragColor = vec4(col * c.a * opacity, c.a * opacity); }`;
// Ribbons: uv.x runs from the hem (0) to the tip (1); trailDir is the local direction behind the motion.
const trailVS = `uniform float time; uniform vec2 trailDir; attribute float phase; attribute vec3 root; attribute float len; varying vec2 vUv; varying float vPhase;
  void main(){ vUv = uv; vPhase = phase; float u = uv.x;
    vec2 d = normalize(trailDir + vec2(0.0, -0.55)); vec2 n = vec2(-d.y, d.x);
    float w = (uv.y - 0.5) * mix(0.16, 0.03, u);
    float wave = sin(u * 7.0 - time * 3.2 + phase * 6.0) * 0.10 * u + sin(u * 13.0 - time * 5.0 + phase) * 0.03 * u;
    vec2 q = root.xy + d * u * len + n * (wave + w);
    float z = root.z + sin(u * 5.0 - time * 2.4 + phase * 3.0) * 0.12 * u;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(q, z, 1.0); }`;
const trailFS = `uniform float opacity; uniform vec3 tint; uniform float time; varying vec2 vUv; varying float vPhase;
  void main(){ float u = vUv.x, v = vUv.y;
    float edge = smoothstep(0.0, 0.35, v) * smoothstep(1.0, 0.65, v);
    float fib = 0.35 + 0.65 * pow(abs(sin(v * 38.0 + u * 9.0 + vPhase * 11.0)), 8.0);
    float a = edge * fib * pow(1.0 - u, 1.4) * smoothstep(0.0, 0.06, u + 0.06) * (0.8 + 0.2 * sin(u * 20.0 - time * 4.0));
    a *= opacity * 0.9; gl_FragColor = vec4(tint * a, a); }`;
const btVS = `uniform float time; varying vec2 vUv;
  void main(){ vUv = uv; vec3 p = position; float low = 1.0 - uv.y;
    p.x += sin(uv.y * 5.0 + time * 0.9) * 0.015 * low;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0); }`;
const btFS = `uniform sampler2D map; uniform float opacity; uniform float time; varying vec2 vUv;
  vec3 iri(float h){ return 0.5 + 0.5 * cos(6.2832 * (h + vec3(0.0, 0.33, 0.67))); }
  void main(){ float m = texture2D(map, vUv).a; float fade = smoothstep(0.0, 0.25, vUv.y);
    float n = min(min(texture2D(map, vUv + vec2(0.012, 0.0)).a, texture2D(map, vUv - vec2(0.012, 0.0)).a), min(texture2D(map, vUv + vec2(0.0, 0.005)).a, texture2D(map, vUv - vec2(0.0, 0.005)).a));
    float rim = clamp(m - n, 0.0, 1.0);
    float mx = max(max(texture2D(map, vUv + vec2(0.05, 0.0)).a, texture2D(map, vUv - vec2(0.05, 0.0)).a), max(texture2D(map, vUv + vec2(0.0, 0.02)).a, texture2D(map, vUv - vec2(0.0, 0.02)).a));
    float halo = clamp(mx - m, 0.0, 1.0);
    float sheen = pow(0.5 + 0.5 * sin(vUv.y * 22.0 + vUv.x * 9.0 - time * 1.3), 6.0);
    vec3 col = vec3(0.015, 0.012, 0.03) + iri(vUv.y * 2.5 + vUv.x * 1.5 + time * 0.12) * (0.06 + 0.22 * sheen);
    col += rim * (vec3(0.16, 0.15, 0.26) + iri(vUv.y * 4.0 - time * 0.2) * 0.14);
    vec3 haloCol = vec3(0.5, 0.46, 0.85) + iri(vUv.y * 3.0 + time * 0.15) * 0.25;
    float a = (m * 0.85 + rim * 0.15) * 0.8 + halo * 0.14;
    col = mix(haloCol, col, clamp(m * 1.5, 0.0, 1.0));
    gl_FragColor = vec4(col, a * fade * opacity); }`;
const tetherVS = `uniform float time; uniform float floorY; uniform float drift; attribute float phase; attribute vec3 root; varying float vU; varying float vSide;
  void main(){ float u = uv.x; vU = u; vSide = uv.y;
    float drop = max(0.7, root.y - floorY) * (0.75 + 0.25 * fract(phase * 7.3));
    vec3 q = root + vec3(sin(u * 4.0 - time * 1.1 + phase * 6.0) * 0.05 * u - drift * u * u * 0.35, -u * drop, sin(u * 3.0 + time * 0.8 + phase) * 0.06 * u);
    q.x += (uv.y - 0.5) * 0.008;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(q, 1.0); }`;
const tetherFS = `uniform float opacity; uniform float time; varying float vU; varying float vSide;
  void main(){ float a = opacity * 0.7 * (1.0 - vU * 0.85) * smoothstep(0.0, 0.5, vSide) * smoothstep(1.0, 0.5, vSide);
    vec3 col = vec3(0.10, 0.09, 0.16) + 0.18 * (0.5 + 0.5 * cos(6.2832 * (vU * 3.0 + time * 0.2 + vec3(0.0, 0.33, 0.67))));
    gl_FragColor = vec4(col, a); }`;
const printFS = `uniform sampler2D map; uniform float opacity; varying vec2 vUv;
  void main(){ float m = texture2D(map, vUv).a; gl_FragColor = vec4(0.0, 0.0, 0.01, m * opacity); }`;
const plainVS = `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`;

/** A bundle of strips sharing one material, each with its own root, length and phase. */
function strips(n: number, segs: number, rootOf: (i: number) => [number, number, number], lenOf: (i: number) => number) {
  const base = new THREE.PlaneGeometry(1, 1, segs, 1);
  const geos: THREE.BufferGeometry[] = [];
  for (let i = 0; i < n; i++) {
    const g = base.clone(); const cnt = g.attributes.position.count;
    const r = rootOf(i), L = lenOf(i), ph = (i * 0.618) % 1;
    g.setAttribute("root", new THREE.BufferAttribute(new Float32Array(Array.from({ length: cnt * 3 }, (_, k) => r[k % 3])), 3));
    g.setAttribute("len", new THREE.BufferAttribute(new Float32Array(cnt).fill(L), 1));
    g.setAttribute("phase", new THREE.BufferAttribute(new Float32Array(cnt).fill(ph), 1));
    geos.push(g);
  }
  const merged = new THREE.BufferGeometry();
  const attrs = ["position", "uv", "root", "len", "phase"];
  for (const a of attrs) {
    const size = geos[0].attributes[a].itemSize, arr: number[] = [];
    for (const g of geos) arr.push(...(g.attributes[a].array as Float32Array));
    merged.setAttribute(a, new THREE.BufferAttribute(new Float32Array(arr), size));
  }
  const idx: number[] = []; let off = 0;
  for (const g of geos) { for (const k of g.index!.array) idx.push(k + off); off += g.attributes.position.count; }
  merged.setIndex(idx);
  merged.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e6);
  return merged;
}

function noPick(m: THREE.Object3D) { m.traverse((o) => { o.raycast = () => {}; o.frustumCulled = false; o.userData.excludeFromExport = true; }); }

function getPass(): Pass {
  if (pass) return pass;
  const sheetTex = [0, 1].map(drawSheet), btTex = [2, 3].map(drawBT), hand = drawHand();
  const common = { transparent: true, depthTest: true, depthWrite: false, side: THREE.DoubleSide } as const;
  const sheetMat = new THREE.ShaderMaterial({ ...common, blending: THREE.AdditiveBlending, uniforms: { map: { value: sheetTex[0] }, opacity: { value: 0 }, time: { value: 0 }, tint: { value: new THREE.Color(0.86, 0.9, 1.0) } }, vertexShader: sheetVS, fragmentShader: sheetFS });
  const trailMat = new THREE.ShaderMaterial({ ...common, blending: THREE.AdditiveBlending, uniforms: { opacity: { value: 0 }, time: { value: 0 }, trailDir: { value: new THREE.Vector2(-1, 0) }, tint: { value: new THREE.Color(0.78, 0.8, 1.0) } }, vertexShader: trailVS, fragmentShader: trailFS });
  const btMat = new THREE.ShaderMaterial({ ...common, blending: THREE.NormalBlending, uniforms: { map: { value: btTex[0] }, opacity: { value: 0 }, time: { value: 0 } }, vertexShader: btVS, fragmentShader: btFS });
  const tetherMat = new THREE.ShaderMaterial({ ...common, blending: THREE.NormalBlending, uniforms: { opacity: { value: 0 }, time: { value: 0 }, floorY: { value: -2 }, drift: { value: 0 } }, vertexShader: tetherVS, fragmentShader: tetherFS });

  const sheet = new THREE.Group();
  const body = new THREE.Mesh(new THREE.PlaneGeometry(1, 1, 8, 16), sheetMat); body.renderOrder = 2; sheet.add(body);
  // Cloth streams from the hem and the sleeves.
  const roots: [number, number, number][] = [[-0.1, -0.42, 0], [-0.04, -0.45, 0.02], [0.03, -0.46, -0.02], [0.1, -0.42, 0.01], [0.0, -0.35, 0.03], [-0.36, -0.02, 0], [0.36, -0.02, 0], [-0.18, -0.3, -0.03], [0.18, -0.3, 0.02]];
  const trail = new THREE.Mesh(strips(roots.length, 32, (i) => roots[i], (i) => (i >= 5 && i <= 6 ? 0.9 : 1.5 + 0.35 * ((i * 0.37) % 1))), trailMat);
  sheet.add(trail);

  const bt = new THREE.Group();
  const btBody = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 1, 4, 16), btMat); bt.add(btBody);
  const tRoots: [number, number, number][] = [[-0.05, -0.2, 0], [0.05, -0.25, 0.01], [0.0, -0.45, 0], [-0.12, -0.2, -0.01], [0.13, -0.22, 0], [-0.02, -0.05, 0.01], [0.03, -0.48, -0.01]];
  const tethers = new THREE.Mesh(strips(tRoots.length, 24, (i) => tRoots[i], () => 1), tetherMat); bt.add(tethers);

  const scene = new THREE.Scene(); scene.add(sheet, bt);
  const printGeo = new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2);
  const printMats: THREE.ShaderMaterial[] = [], prints: THREE.Mesh[] = [];
  for (let i = 0; i < PRINTS; i++) {
    const m = new THREE.ShaderMaterial({ ...common, blending: THREE.NormalBlending, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2, uniforms: { map: { value: hand }, opacity: { value: 0 } }, vertexShader: plainVS, fragmentShader: printFS });
    const pm = new THREE.Mesh(printGeo, m); printMats.push(m); prints.push(pm); scene.add(pm);
  }
  noPick(scene);
  pass = { scene, sheet, bt, prints, sheetMat, trailMat, btMat, tetherMat, printMats, sheetTex, btTex };
  return pass;
}

function spawn(now: number, progress = 0, variant = Math.floor(Math.random() * 4)) {
  const bt = isBT(variant);
  const dur = bt ? 20000 + Math.random() * 8000 : 14000 + Math.random() * 6000;
  ghost = { variant, dur, start: now - progress * dur, seed: Math.random() * 100, dir: Math.random() < 0.5 ? 1 : -1,
    radius: 320 + Math.random() * 600, angle0: Math.random() * Math.PI * 2, sweep: bt ? 0.5 + Math.random() * 0.4 : 0.9 + Math.random() * 0.9,
    y: bt ? 0 : -60 + Math.random() * 420, faceAt: Math.random() < 0.6 ? 0.35 + Math.random() * 0.3 : -1, size: bt ? 75 + Math.random() * 25 : 110 + Math.random() * 70 };
}

/** Called every animation frame; true while a ghost is on screen so the idle view keeps redrawing. */
export function xrayGhostTick(now: number, xray: boolean) {
  if (!xray) { ghost = null; nextAt = 0; return false; }
  if (!nextAt) nextAt = now + 20000 + Math.random() * 40000;
  if (!ghost && now >= nextAt) spawn(now);
  if (ghost && ghost.frozen === undefined && now - ghost.start > ghost.dur) { ghost = null; nextAt = now + 20000 + Math.random() * 40000; return true; }
  return !!ghost;
}

const _q = new THREE.Quaternion(), _q2 = new THREE.Quaternion(), _e = new THREE.Euler(), _m = new THREE.Matrix4(), _up = new THREE.Vector3(0, 1, 0);
const _a = new THREE.Vector3(), _b = new THREE.Vector3();

/** World position along the ghost's curved path at progress t (wall time s for the bob). */
function pathAt(g: Ghost, t: number, s: number, center: THREE.Vector3, out: THREE.Vector3) {
  const k = g.seed, ang = g.angle0 + g.dir * g.sweep * t;
  const r = g.radius * (1 + 0.25 * Math.sin(t * Math.PI * 1.5 + k));
  const bt = isBT(g.variant);
  // Stranded figures hover just off the floor; sheets rise and sink.
  const y = bt ? g.size * 0.56 + Math.sin(s * 0.5 + k) * 6 : g.y + Math.sin(t * Math.PI * 2 + k) * 80 + Math.sin(s * 1.1 + k) * 12;
  return out.set(center.x + Math.cos(ang) * r, center.y + y, center.z + Math.sin(ang) * r);
}

/** Draws the ghost in world space with the view's own camera, depth-tested against what is already drawn. */
export function drawXrayGhost(renderer: THREE.WebGLRenderer, camera: THREE.Camera, center: THREE.Vector3, now = performance.now()) {
  if (!ghost) return;
  if (ghost.frozen !== undefined) now = ghost.frozen;
  const p = getPass();
  const t = (now - ghost.start) / ghost.dur;
  if (t < 0 || t > 1) return;
  const s = now / 1000, k = ghost.seed, bt = isBT(ghost.variant);
  const fadeIn = Math.min(1, t / 0.12), fadeOut = t > 0.55 ? 1 - (t - 0.55) / 0.45 : 1;
  const flicker = bt ? 0.9 + 0.1 * Math.sin(s * 2.1 + k) : 0.88 + 0.12 * Math.sin(s * 7 + k) * Math.sin(s * 2.3 + k * 2);
  const op = fadeIn * Math.max(0, fadeOut) * flicker;
  const g = bt ? p.bt : p.sheet;
  p.sheet.visible = !bt; p.bt.visible = bt;
  pathAt(ghost, t, s, center, g.position);
  // Face the camera (upright), with a yaw/roll that turns it as it travels.
  _m.lookAt(camera.position, g.position, _up); _q.setFromRotationMatrix(_m);
  let yaw: number, roll: number, pitch: number;
  if (bt) { yaw = 0.35 * Math.sin(s * 0.25 + k) + ghost.dir * 0.25 * (t - 0.5); roll = 0; pitch = 0; }
  else {
    yaw = ghost.dir * (0.5 * Math.sin(s * 0.45 + k) + (t - 0.3) * 1.2); roll = 0.22 * Math.sin(s * 0.6 + k * 3) - ghost.dir * 0.18; pitch = 0.1 * Math.sin(s * 0.7 + k);
    if (ghost.faceAt >= 0) { const f = Math.max(0, 1 - Math.abs(t - ghost.faceAt) / 0.1); const e = f * f * (3 - 2 * f); yaw *= 1 - e; roll *= 1 - e; }
  }
  g.quaternion.copy(_q).multiply(_q2.setFromEuler(_e.set(pitch, yaw, roll)));
  g.scale.setScalar(ghost.size);
  // Direction of travel in the ghost's own frame, so cloth and cords stream behind it.
  pathAt(ghost, Math.min(1, t + 0.01), s, center, _b); _a.subVectors(_b, g.position);
  _a.applyQuaternion(_q2.copy(g.quaternion).invert());
  const vx = _a.x, vy = _a.y, vl = Math.hypot(vx, vy) || 1;
  if (bt) {
    p.btMat.uniforms.map.value = p.btTex[ghost.variant - 2];
    p.btMat.uniforms.opacity.value = op; p.btMat.uniforms.time.value = s;
    p.tetherMat.uniforms.opacity.value = op; p.tetherMat.uniforms.time.value = s;
    p.tetherMat.uniforms.floorY.value = (center.y - g.position.y) / ghost.size;
    p.tetherMat.uniforms.drift.value = Math.sign(vx) * 0.6;
    // Handprints left at points it has passed, fading over a while.
    for (let i = 0; i < PRINTS; i++) {
      const tk = (i + 0.5) / PRINTS * 0.9, age = t - tk, m = p.prints[i];
      const a = age < 0 ? 0 : Math.min(1, age / 0.02) * Math.max(0, 1 - age / 0.28);
      m.visible = a > 0.001;
      if (!m.visible) continue;
      pathAt(ghost, tk, s, center, m.position);
      const side = i % 2 ? 1 : -1;
      m.position.x += side * ghost.size * 0.12 * Math.cos(k + i); m.position.z += side * ghost.size * 0.12 * Math.sin(k + i);
      m.position.y = center.y + 0.3;
      m.rotation.set(0, k + i * 1.7, 0); m.scale.setScalar(ghost.size * 0.14);
      p.printMats[i].uniforms.opacity.value = a * 0.45 * Math.min(1, fadeIn * 3) * Math.max(0, Math.min(1, (1 - t) / 0.15));
    }
  } else {
    for (const m of p.prints) m.visible = false;
    p.sheetMat.uniforms.map.value = p.sheetTex[ghost.variant];
    p.sheetMat.uniforms.opacity.value = 0.75 * op; p.sheetMat.uniforms.time.value = s;
    p.trailMat.uniforms.opacity.value = op; p.trailMat.uniforms.time.value = s;
    (p.trailMat.uniforms.trailDir.value as THREE.Vector2).set(-vx / vl, -vy / vl * 0.5);
  }
  lastView = [camera.position.x - center.x, camera.position.z - center.z, center.y];
  p.scene.traverse((o) => { o.layers.mask = camera.layers.mask; });
  const autoClear = renderer.autoClear; renderer.autoClear = false;
  renderer.render(p.scene, camera);
  renderer.autoClear = autoClear;
}

/** Where the test hook and screenshots can find the forced ghost. */
export function xrayGhostState() { return ghost; }

if (typeof window !== "undefined") {
  (window as unknown as Record<string, unknown>).__xrayGhost = (variant?: number, progress = 0.3, freeze = false, radius?: number, angle?: number) => {
    spawn(performance.now(), progress, variant ?? Math.floor(Math.random() * 4));
    if (ghost) { if (!isBT(ghost.variant)) ghost.y = 0; ghost.radius = isBT(ghost.variant) ? 260 : 380; ghost.angle0 = (isBT(ghost.variant) ? -2.2 : -2.72) - 1.2 * (progress - 0.3); ghost.dir = 1; ghost.sweep = 1.2; ghost.faceAt = -1; if (radius !== undefined) ghost.radius = radius; if (angle !== undefined) ghost.angle0 = angle - ghost.sweep * progress; if (freeze) ghost.frozen = performance.now(); }
    nextAt = Infinity;
  };
  (window as unknown as Record<string, unknown>).__xrayGhostView = () => lastView;
}

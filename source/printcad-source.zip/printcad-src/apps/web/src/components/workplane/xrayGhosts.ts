import * as THREE from "three";

/**
 * X-Ray easter egg: now and then a gaunt wraith drifts through the 3D background on a curved path at
 * some depth, slowly yawing and rolling (sometimes turning its face to the camera), its tattered tail
 * waving, flickering, then fading out. Drawn before the scene, so it sits behind the plate and every
 * body. Screen-pass only: never picked, never exported, never saved, X-Ray only.
 * Test hook: window.__xrayGhost(variant?, progress?) forces one at a point along its path.
 */
type Ghost = { variant: number; start: number; dur: number; seed: number; dir: 1 | -1; frozen?: number; radius: number; angle0: number; sweep: number; y: number; faceAt: number; size: number };
let ghost: Ghost | null = null;
let nextAt = 0;
let pass: { scene: THREE.Scene; mesh: THREE.Mesh; material: THREE.ShaderMaterial; textures: THREE.Texture[] } | null = null;

function drawWraith(variant: number) {
  const W = 192, H = 320;
  const c = document.createElement("canvas"); c.width = W; c.height = H;
  const g = c.getContext("2d")!;
  g.translate(W / 2, 0);
  const headW = variant === 1 ? 26 : 30, headY = variant === 2 ? 64 : 58;
  const shoulder = variant === 0 ? 54 : variant === 1 ? 44 : 60;
  // Gaunt hooded body, long and narrow, ending in ragged strands.
  g.beginPath();
  g.moveTo(0, headY - 50);
  g.bezierCurveTo(headW + 14, headY - 50, headW + 10, headY + 18, shoulder, headY + 60);
  g.bezierCurveTo(shoulder + 8, 170, shoulder - 6, 230, shoulder - 10, 250);
  const strands = variant === 1 ? 7 : 6;
  for (let i = 0; i < strands; i++) {
    const x0 = shoulder - 10 - ((2 * shoulder - 20) / strands) * i, x1 = x0 - (2 * shoulder - 20) / strands;
    const tip = 285 + ((i * 37 + variant * 13) % 30);
    g.quadraticCurveTo(x0 - 2, tip - 20, (x0 + x1) / 2, tip);
    g.quadraticCurveTo(x1 + 2, tip - 40, x1, 245 + ((i * 17) % 14));
  }
  g.bezierCurveTo(-shoulder + 6, 230, -shoulder - 8, 170, -shoulder, headY + 60);
  g.bezierCurveTo(-headW - 10, headY + 18, -headW - 14, headY - 50, 0, headY - 50);
  g.closePath();
  const fill = g.createLinearGradient(0, 0, 0, H);
  fill.addColorStop(0, "rgba(210,200,255,0.42)"); fill.addColorStop(0.55, "rgba(170,160,255,0.22)"); fill.addColorStop(1, "rgba(150,140,255,0.0)");
  g.fillStyle = fill; g.shadowColor = "rgba(190,180,255,0.95)"; g.shadowBlur = 16; g.fill();
  g.shadowBlur = 0; g.lineWidth = 2.2; g.strokeStyle = "rgba(236,232,255,0.7)"; g.stroke();

  // Skeletal arms and long-fingered hands reaching out (variants 0 and 2).
  const bone = (x0: number, y0: number, x1: number, y1: number, w = 2) => { g.lineWidth = w; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x1, y1); g.stroke(); };
  g.strokeStyle = "rgba(240,236,255,0.75)"; g.lineCap = "round";
  if (variant !== 1) {
    for (const s of [-1, 1]) {
      const ex = s * (shoulder + 18), ey = headY + 100, hx = s * (shoulder + (variant === 2 ? 44 : 30)), hy = headY + (variant === 2 ? 70 : 140);
      bone(s * shoulder * 0.8, headY + 64, ex, ey, 2.6); bone(ex, ey, hx, hy, 2.2);
      for (let f = -2; f <= 2; f++) bone(hx, hy, hx + s * 14 + f * 3, hy + f * 6 + (variant === 2 ? -10 : 14), 1.3);
    }
  }
  // Faint ribcage and spine showing through.
  g.strokeStyle = "rgba(225,220,255,0.38)";
  bone(0, headY + 34, 0, 210, 2.4);
  for (let r = 0; r < 6; r++) {
    const y = headY + 56 + r * 15, rw = 30 - r * 3;
    g.lineWidth = 1.6; g.beginPath(); g.moveTo(0, y); g.quadraticCurveTo(rw, y - 2, rw - 4, y + 12); g.moveTo(0, y); g.quadraticCurveTo(-rw, y - 2, -rw + 4, y + 12); g.stroke();
  }
  // Skull: pale cranium, hollow eye sockets, nose hole, gaping mouth.
  g.fillStyle = "rgba(235,230,255,0.38)";
  g.beginPath(); g.ellipse(0, headY, headW * 0.78, headW * 0.98, 0, 0, Math.PI * 2); g.fill();
  g.fillStyle = "rgba(8,5,28,0.95)";
  const eyeTilt = variant === 1 ? 0.5 : 0.3;
  g.beginPath(); g.ellipse(-9, headY - 4, 6.5, 9, eyeTilt, 0, Math.PI * 2); g.ellipse(9, headY - 4, 6.5, 9, -eyeTilt, 0, Math.PI * 2); g.fill();
  g.beginPath(); g.moveTo(0, headY + 6); g.lineTo(-3, headY + 12); g.lineTo(3, headY + 12); g.closePath(); g.fill();
  const mouthH = variant === 2 ? 22 : 16;
  g.beginPath(); g.ellipse(0, headY + 26, 7, mouthH / 2, 0, 0, Math.PI * 2); g.fill();
  g.strokeStyle = "rgba(225,220,255,0.45)"; g.lineWidth = 1;
  for (let k = -2; k <= 2; k++) { g.beginPath(); g.moveTo(k * 3, headY + 18); g.lineTo(k * 3, headY + 22); g.stroke(); }
  // Tiny glints deep in the sockets.
  g.fillStyle = "rgba(255,255,255,0.8)";
  g.beginPath(); g.arc(-8, headY - 2, 1.2, 0, Math.PI * 2); g.arc(10, headY - 2, 1.2, 0, Math.PI * 2); g.fill();
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

function getPass() {
  if (!pass) {
    const textures = [0, 1, 2].map(drawWraith);
    const material = new THREE.ShaderMaterial({
      uniforms: { map: { value: textures[0] }, opacity: { value: 0 }, time: { value: 0 } },
      transparent: true, blending: THREE.AdditiveBlending, depthTest: true, depthWrite: false, side: THREE.DoubleSide,
      vertexShader: `uniform float time; varying vec2 vUv;
        void main(){ vUv = uv; vec3 p = position; float tail = 1.0 - uv.y;
          // The lower, tattered part ripples like cloth in a draught.
          p.x += sin(uv.y * 9.0 + time * 2.3) * 0.06 * tail * tail;
          p.z += sin(uv.y * 6.0 + uv.x * 4.0 + time * 1.7) * 0.10 * tail;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0); }`,
      fragmentShader: `uniform sampler2D map; uniform float opacity; uniform float time; varying vec2 vUv;
        void main(){ vec2 uv = vUv; float tail = 1.0 - uv.y;
          uv.x += sin(uv.y * 30.0 - time * 3.0) * 0.012 * tail;
          vec4 c = texture2D(map, uv);
          gl_FragColor = vec4(c.rgb * c.a * opacity, c.a * opacity); }`,
    });
    // Subdivided so the vertex ripple has something to bend.
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(0.6, 1, 6, 20), material);
    mesh.raycast = () => {}; mesh.frustumCulled = false; mesh.userData.excludeFromExport = true;
    const scene = new THREE.Scene(); scene.add(mesh);
    pass = { scene, mesh, material, textures };
  }
  return pass;
}

function spawn(now: number, progress = 0, variant = Math.floor(Math.random() * 3)) {
  const dur = 14000 + Math.random() * 6000;
  // A world-space shell around the plate: some close behind it, some far out, some low, some high.
  ghost = { variant, dur, start: now - progress * dur, seed: Math.random() * 100, dir: Math.random() < 0.5 ? 1 : -1,
    radius: 320 + Math.random() * 600, angle0: Math.random() * Math.PI * 2, sweep: 0.9 + Math.random() * 0.9,
    y: -120 + Math.random() * 480, faceAt: Math.random() < 0.6 ? 0.35 + Math.random() * 0.3 : -1, size: 110 + Math.random() * 70 };
}

/** Called every animation frame; true while a ghost is on screen so the idle view keeps redrawing. */
export function xrayGhostTick(now: number, xray: boolean) {
  if (!xray) { ghost = null; nextAt = 0; return false; }
  if (!nextAt) nextAt = now + 20000 + Math.random() * 40000;
  if (!ghost && now >= nextAt) spawn(now);
  if (ghost && ghost.frozen === undefined && now - ghost.start > ghost.dur) { ghost = null; nextAt = now + 20000 + Math.random() * 40000; return true; }
  return !!ghost;
}

const _q = new THREE.Quaternion(), _q2 = new THREE.Quaternion(), _e = new THREE.Euler(), _m = new THREE.Matrix4(), _up = new THREE.Vector3(0, 1, 0);

/** Draws the ghost in world space with the view's own camera, depth-tested against what is already drawn. */
export function drawXrayGhost(renderer: THREE.WebGLRenderer, camera: THREE.Camera, center: THREE.Vector3, now = performance.now()) {
  if (!ghost) return;
  if (ghost.frozen !== undefined) now = ghost.frozen;
  const p = getPass();
  const t = (now - ghost.start) / ghost.dur;
  if (t < 0 || t > 1) return;
  const s = now / 1000, k = ghost.seed;
  const fadeIn = Math.min(1, t / 0.12), fadeOut = t > 0.5 ? 1 - (t - 0.5) / 0.5 : 1;
  const flicker = 0.82 + 0.18 * Math.sin(s * 17 + k) * Math.sin(s * 5.3 + k * 2) + (Math.sin(s * 41 + k) > 0.985 ? -0.5 : 0);
  p.material.uniforms.map.value = p.textures[ghost.variant];
  p.material.uniforms.opacity.value = 0.8 * fadeIn * Math.max(0, fadeOut) * Math.max(0.2, flicker);
  p.material.uniforms.time.value = s;
  // Curved path: an arc round the plate whose radius breathes in and out, rising and sinking, with a bob.
  const ang = ghost.angle0 + ghost.dir * ghost.sweep * t;
  const r = ghost.radius * (1 + 0.25 * Math.sin(t * Math.PI * 1.5 + k));
  const y = ghost.y + Math.sin(t * Math.PI * 2 + k) * 80 + Math.sin(s * 1.1 + k) * 12;
  p.mesh.position.set(center.x + Math.cos(ang) * r, center.y + y, center.z + Math.sin(ang) * r);
  // Face the camera (upright), then add a slow yaw tumble and roll; now and then it turns square on to stare.
  _m.lookAt(camera.position, p.mesh.position, _up); _q.setFromRotationMatrix(_m);
  let yaw = ghost.dir * (0.9 * Math.sin(s * 0.45 + k) + t * 2.2);
  let roll = 0.35 * Math.sin(s * 0.6 + k * 3) + ghost.dir * 0.15;
  if (ghost.faceAt >= 0) { const f = Math.max(0, 1 - Math.abs(t - ghost.faceAt) / 0.1); const e = f * f * (3 - 2 * f); yaw *= 1 - e; roll *= 1 - e; }
  _q2.setFromEuler(_e.set(0.12 * Math.sin(s * 0.7 + k), yaw, roll));
  p.mesh.quaternion.copy(_q).multiply(_q2);
  p.mesh.scale.setScalar(ghost.size);
  p.mesh.layers.mask = camera.layers.mask;
  const autoClear = renderer.autoClear; renderer.autoClear = false;
  renderer.render(p.scene, camera);
  renderer.autoClear = autoClear;
}

/** Where the test hook and screenshots can find the forced ghost. */
export function xrayGhostState() { return ghost; }

if (typeof window !== "undefined") {
  (window as unknown as Record<string, unknown>).__xrayGhost = (variant?: number, progress = 0.3, freeze = false) => {
    spawn(performance.now(), progress, variant ?? Math.floor(Math.random() * 3));
    if (ghost) { ghost.y = 0; ghost.radius = 380; ghost.angle0 = -2.72 - 1.2 * (progress - 0.3); ghost.dir = 1; ghost.sweep = 1.2; ghost.faceAt = progress === 0.3 ? 0.3 : -1; if (freeze) ghost.frozen = performance.now(); }
    nextAt = Infinity;
  };
}

"use client";
import { longPressMs } from "@/lib/touchSettings";

import * as THREE from "three";
import { createPortal } from "react-dom";
import { useCallback, useEffect, useRef, useState, type MutableRefObject } from "react";
import type { ThreeState } from "@/components/workplane/ViewportOverlays";
import { RENDER_LAYER_WORKPLANE, plateRulersOn } from "@/components/workplane/viewportScene";
import { axisColor } from "@/lib/axisColors";
import { lengthDisplayUnit } from "@/lib/measurementUnits";
import { readPlateGuides, writePlateGuides, type PlateGuide } from "@/lib/plateGuideStore";
import type { WorkplaneWorkspaceSettings } from "@/types/layerling";

type Menu = { x: number; y: number; axis: "x" | "y"; position: number; index: number | null; value: string };
type Hit = { kind: "ruler" | "guide"; axis: "x" | "y"; position: number; index: number | null };

const LONG_PRESS_MS = 480;
/** Hold on a guide this long (any pointer) to grab it: then drag to move, or lift to delete or edit. */
const GUIDE_HOLD_MS = 400;

/**
 * Ruler guides: right-click (long-press on touch) the X or Y plate ruler to add a laser line across the plate,
 * right-click a guide to type its position or remove it, drag a guide to move it.
 */
export function PlateGuides({ threeRef, workspace, projectId, axisColors, snapStepMm = 0 }: {
  snapStepMm?: number;
  threeRef: MutableRefObject<ThreeState | null>;
  workspace: Pick<WorkplaneWorkspaceSettings, "width" | "depth" | "units" | "scale">;
  projectId: string | null | undefined;
  axisColors: string;
}) {
  const [guides, setGuides] = useState<PlateGuide[]>(() => readPlateGuides(projectId));
  const guidesRef = useRef(guides);
  guidesRef.current = guides;
  const [menu, setMenu] = useState<Menu | null>(null);
  const [drag, setDrag] = useState<{ x: number; y: number; text: string } | null>(null);
  const [confirm, setConfirm] = useState<{ x: number; y: number; index: number; axis: "x" | "y"; position: number } | null>(null);
  const [held, setHeld] = useState<number | null>(null);
  const heldRef = useRef<number | null>(null); heldRef.current = held;
  const snapRef = useRef(snapStepMm); snapRef.current = snapStepMm;
  const groupRef = useRef<THREE.Group | null>(null);
  const wsRef = useRef(workspace);
  wsRef.current = workspace;
  const unit = lengthDisplayUnit(workspace);
  const unitRef = useRef(unit);
  unitRef.current = unit;

  useEffect(() => { setGuides(readPlateGuides(projectId)); }, [projectId]);
  const commit = useCallback((next: PlateGuide[]) => { setGuides(next); writePlateGuides(projectId, next); }, [projectId]);

  const fmt = (mm: number) => {
    const u = unitRef.current;
    const v = mm / (u.millimetersPerUnit || 1);
    return `${Number(v.toFixed(u.label === "in" ? 3 : 2))}`;
  };

  // Build the laser lines.
  const sync = useCallback(() => {
    const state = threeRef.current;
    if (!state) return;
    let group = groupRef.current;
    if (!group) { group = new THREE.Group(); group.name = "PlateGuides"; groupRef.current = group; }
    if (group.parent !== state.scene) state.scene.add(group);
    group.children.slice().forEach((child) => {
      group!.remove(child);
      child.traverse((o) => { const m = o as THREE.Mesh; m.geometry?.dispose(); (m.material as THREE.Material | undefined)?.dispose?.(); });
    });
    const { width, depth } = wsRef.current;
    const halfW = width / 2, halfD = depth / 2;
    const base = Math.max(1.2, Math.min(width, depth) / 120);
    guidesRef.current.forEach((guide, gi) => {
      const hot = heldRef.current === gi;
      const color = new THREE.Color(axisColor(guide.axis));
      if (hot) color.lerp(new THREE.Color("#ffffff"), 0.35);
      const len = guide.axis === "x" ? depth : width;
      const make = (w: number, opacity: number, white: boolean, order: number) => {
        const mat = new THREE.MeshBasicMaterial({ color: white ? color.clone().lerp(new THREE.Color("#ffffff"), 0.25) : color, transparent: true, opacity, depthWrite: false, side: THREE.FrontSide, toneMapped: false });
        // Plane faces up: seen from below, it is not drawn, like the plate.
        const mesh = new THREE.Mesh(guide.axis === "x" ? new THREE.PlaneGeometry(w, len) : new THREE.PlaneGeometry(len, w), mat);
        mesh.rotation.x = -Math.PI / 2;
        mesh.position.set(guide.axis === "x" ? -halfW + guide.position : 0, 0.06 + order * 0.01, guide.axis === "x" ? 0 : halfD - guide.position);
        mesh.renderOrder = 4 + order;
        return mesh;
      };
      const k = hot ? 2.2 : 1;
      group!.add(make(base * 1.6 * k, hot ? 0.4 : 0.22, false, 0), make(base * 0.55 * k, hot ? 0.8 : 0.55, false, 1), make(base * 0.18 * k, 1, true, 2));
    });
    group.traverse((o) => { o.layers.set(RENDER_LAYER_WORKPLANE); o.raycast = () => undefined; o.userData.nonSelectable = true; });
    state.needsRender = true;
  }, [threeRef]);

  useEffect(() => { sync(); }, [sync, guides, held, workspace.width, workspace.depth, axisColors]);
  // The scene is built again after a sketch; put the lines back when it is.
  useEffect(() => {
    const id = window.setInterval(() => { const s = threeRef.current; if (s && groupRef.current?.parent !== s.scene) sync(); }, 800);
    return () => { window.clearInterval(id); groupRef.current?.parent?.remove(groupRef.current); };
  }, [sync, threeRef]);

  // Test hook: plate millimetres (from the ruler zero) to screen pixels.
  useEffect(() => {
    (window as unknown as Record<string, unknown>).__plateGuideScreen = (axisX: number, axisY: number) => {
      const state = threeRef.current;
      if (!state) return null;
      const rect = state.renderer.domElement.getBoundingClientRect();
      const v = new THREE.Vector3(-wsRef.current.width / 2 + axisX, 0, wsRef.current.depth / 2 - axisY).project(state.camera);
      return { x: rect.left + (v.x + 1) / 2 * rect.width, y: rect.top + (1 - v.y) / 2 * rect.height };
    };
  }, [threeRef]);

  // Where a pointer lands on the plate and what it hits there.
  const plateAt = (clientX: number, clientY: number) => {
    const state = threeRef.current;
    if (!state) return null;
    const rect = state.renderer.domElement.getBoundingClientRect();
    const ndc = new THREE.Vector2(((clientX - rect.left) / rect.width) * 2 - 1, -((clientY - rect.top) / rect.height) * 2 + 1);
    const ray = new THREE.Raycaster();
    ray.setFromCamera(ndc, state.camera);
    const point = new THREE.Vector3();
    if (!ray.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0, 1, 0), 0), point)) return null;
    // Millimetres per screen pixel there, for a pixel-sized catch zone.
    const p2 = point.clone().add(new THREE.Vector3(1, 0, 0)).project(state.camera);
    const p1 = point.clone().project(state.camera);
    const px = Math.hypot((p2.x - p1.x) * rect.width / 2, (p2.y - p1.y) * rect.height / 2) || 1;
    return { point, mmPerPx: 1 / px };
  };
  const hitTest = (clientX: number, clientY: number, allowRuler: boolean, touch = allowRuler): Hit | null => {
    const at = plateAt(clientX, clientY);
    if (!at) return null;
    const { width, depth } = wsRef.current;
    const halfW = width / 2, halfD = depth / 2;
    const { x, z } = at.point;
    const tol = Math.max(at.mmPerPx * (touch ? 16 : 8), 0.5);
    let best: Hit | null = null, bestD = tol;
    guidesRef.current.forEach((g, index) => {
      const d = g.axis === "x" ? Math.abs(x - (-halfW + g.position)) : Math.abs(z - (halfD - g.position));
      const inside = g.axis === "x" ? Math.abs(z) <= halfD + tol : Math.abs(x) <= halfW + tol;
      if (inside && d < bestD) { bestD = d; best = { kind: "guide", axis: g.axis, position: g.position, index }; }
    });
    if (best || !allowRuler || !plateRulersOn()) return best;
    const base = Math.max(1.2, Math.min(width, depth) / 120);
    const text = base * 2.4;
    const pad = at.mmPerPx * 6;
    if (x >= -halfW - pad && x <= halfW + pad && z <= halfD + text * 1.6 + pad && z >= halfD - base * 2.8 - pad)
      return { kind: "ruler", axis: "x", position: THREE.MathUtils.clamp(x + halfW, 0, width), index: null };
    if (z >= -halfD - pad && z <= halfD + pad && x >= -halfW - text * 2.2 - pad && x <= -halfW + base * 2.8 + pad)
      return { kind: "ruler", axis: "y", position: THREE.MathUtils.clamp(halfD - z, 0, depth), index: null };
    return null;
  };
  const openMenu = (hit: Hit, clientX: number, clientY: number) => {
    setMenu({ x: clientX, y: clientY, axis: hit.axis, position: hit.position, index: hit.index, value: fmt(hit.position) });
  };

  useEffect(() => {
    let press: { id: number; x: number; y: number; timer: number; hit: Hit; dragging: boolean; touch: boolean; held: boolean } | null = null;
    const isCanvas = (e: Event) => threeRef.current && e.target === threeRef.current.renderer.domElement;
    const onContext = (e: MouseEvent) => {
      if (!isCanvas(e)) return;
      const hit = hitTest(e.clientX, e.clientY, true);
      if (!hit) return;
      // The menu itself opens on the right button's release (onUp); here the browser menu is kept away.
      e.preventDefault(); e.stopImmediatePropagation();
    };
    let right: { x: number; y: number; hit: Hit } | null = null;
    const onDown = (e: PointerEvent) => {
      if (isCanvas(e) && e.pointerType !== "touch" && e.button === 2) {
        const hit = hitTest(e.clientX, e.clientY, true);
        right = hit ? { x: e.clientX, y: e.clientY, hit } : null;
        return;
      }
      if (!isCanvas(e) || (e.pointerType === "mouse" && e.button !== 0) || !e.isPrimary) return;
      const hit = hitTest(e.clientX, e.clientY, e.pointerType !== "mouse");
      if (!hit) return;
      const touch = e.pointerType !== "mouse";
      const p = { id: e.pointerId, x: e.clientX, y: e.clientY, timer: 0, hit, dragging: false, touch, held: false };
      if (hit.kind === "guide") {
        // Hold registers: the guide brightens and thickens, and the position bubble shows.
        p.timer = window.setTimeout(() => {
          if (press !== p || p.dragging || hit.index === null) return;
          p.held = true; setHeld(hit.index);
          setDrag({ x: p.x, y: p.y, text: `${hit.axis.toUpperCase()} ${fmt(hit.position)} ${unitRef.current.label}` });
          try { navigator.vibrate?.(12); } catch { /* no haptics */ }
        }, GUIDE_HOLD_MS);
      } else if (touch) p.timer = window.setTimeout(() => { if (press === p && !p.dragging) { press = null; setDrag(null); openMenu(hit, p.x, p.y); } }, longPressMs(LONG_PRESS_MS));
      press = p;
      // A guide is grabbed: the camera and selection leave this press alone. A ruler press only waits for a long-press.
      if (hit.kind === "guide") { e.preventDefault(); e.stopImmediatePropagation(); }
    };
    const onMove = (e: PointerEvent) => {
      if (!press || e.pointerId !== press.id) return;
      const moved = Math.hypot(e.clientX - press.x, e.clientY - press.y) > 6;
      if (press.hit.kind === "ruler") { if (moved) { window.clearTimeout(press.timer); press = null; } return; }
      e.preventDefault(); e.stopImmediatePropagation();
      if (!press.dragging && !moved) return;
      // A finger or Pencil must hold first; a wiggle before that just lets go.
      if (!press.dragging && press.touch && !press.held) { window.clearTimeout(press.timer); press = null; return; }
      press.dragging = true; window.clearTimeout(press.timer);
      if (press.hit.index !== null) setHeld(press.hit.index);
      const at = plateAt(e.clientX, e.clientY);
      if (!at || press.hit.index === null) return;
      const { width, depth } = wsRef.current;
      let pos = press.hit.axis === "x" ? at.point.x + width / 2 : depth / 2 - at.point.z;
      const step = snapRef.current;
      if (step > 0) pos = Math.round(pos / step) * step;
      pos = THREE.MathUtils.clamp(pos, 0, press.hit.axis === "x" ? width : depth);
      const next = guidesRef.current.slice();
      next[press.hit.index] = { axis: press.hit.axis, position: pos };
      guidesRef.current = next;
      setGuides(next);
      setDrag({ x: e.clientX, y: e.clientY, text: `${press.hit.axis.toUpperCase()} ${fmt(pos)} ${unitRef.current.label}` });
    };
    const onUp = (e: PointerEvent) => {
      if (e.button === 2 && right) {
        const r = right; right = null;
        if (Math.hypot(e.clientX - r.x, e.clientY - r.y) < 5) { e.preventDefault(); e.stopImmediatePropagation(); openMenu(r.hit, e.clientX, e.clientY); }
        return;
      }
      if (!press || e.pointerId !== press.id) return;
      window.clearTimeout(press.timer);
      if (press.hit.kind === "guide") {
        e.preventDefault(); e.stopImmediatePropagation();
        if (press.dragging) writePlateGuides(projectId, guidesRef.current);
        else if (press.held && press.hit.index !== null && e.type === "pointerup") {
          const g = guidesRef.current[press.hit.index];
          if (g) setConfirm({ x: e.clientX, y: e.clientY, index: press.hit.index, axis: g.axis, position: g.position });
        }
      }
      if (!(press.held && !press.dragging && e.type === "pointerup")) setHeld(null);
      press = null; setDrag(null);
    };
    window.addEventListener("contextmenu", onContext, true);
    window.addEventListener("pointerdown", onDown, true);
    window.addEventListener("pointermove", onMove, true);
    window.addEventListener("pointerup", onUp, true);
    window.addEventListener("pointercancel", onUp, true);
    return () => {
      window.removeEventListener("contextmenu", onContext, true);
      window.removeEventListener("pointerdown", onDown, true);
      window.removeEventListener("pointermove", onMove, true);
      window.removeEventListener("pointerup", onUp, true);
      window.removeEventListener("pointercancel", onUp, true);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId, threeRef]);

  const apply = () => {
    if (!menu) return;
    const typed = Number.parseFloat(menu.value.replace(",", "."));
    const limit = menu.axis === "x" ? workspace.width : workspace.depth;
    const position = Number.isFinite(typed) ? THREE.MathUtils.clamp(typed * (unit.millimetersPerUnit || 1), 0, limit) : menu.position;
    const next = guides.slice();
    if (menu.index === null) next.push({ axis: menu.axis, position });
    else next[menu.index] = { axis: menu.axis, position };
    commit(next);
    setMenu(null);
  };
  const remove = () => {
    if (!menu || menu.index === null) return;
    commit(guides.filter((_, i) => i !== menu.index));
    setMenu(null);
  };
  const color = menu ? axisColor(menu.axis) : "#fff";

  if (typeof document === "undefined") return null;
  return createPortal(
    <>
      {menu ? (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 9998 }} onPointerDown={() => setMenu(null)} onContextMenu={(e) => { e.preventDefault(); setMenu(null); }} />
          <div
            role="menu"
            data-testid="plate-guide-menu"
            aria-label={menu.index === null ? "Ruler guide" : "Edit guide"}
            style={{ position: "fixed", left: Math.min(menu.x, window.innerWidth - 230), top: Math.min(menu.y, window.innerHeight - 160), zIndex: 9999, background: "#15181c", color: "#f2f4f6", border: `1px solid ${color}`, borderRadius: 10, padding: 10, minWidth: 210, boxShadow: `0 6px 24px rgba(0,0,0,.35), 0 0 10px ${color}55`, font: "500 13px system-ui, sans-serif" }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
              <span style={{ width: 10, height: 10, borderRadius: 5, background: color, boxShadow: `0 0 6px ${color}` }} />
              <strong>{menu.axis.toUpperCase()} guide</strong>
            </div>
            <label style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
              <span>{menu.axis.toUpperCase()}</span>
              <input
                data-testid="plate-guide-position"
                aria-label={`Guide position (${unit.label})`}
                type="number"
                step={unit.label === "in" ? 0.0625 : 0.5}
                autoFocus
                value={menu.value}
                onChange={(e) => setMenu({ ...menu, value: e.target.value })}
                onKeyDown={(e) => { if (e.key === "Enter") apply(); if (e.key === "Escape") setMenu(null); }}
                style={{ width: 90, padding: "4px 6px", borderRadius: 6, border: "1px solid #888", background: "transparent", color: "inherit" }}
              />
              <span>{unit.label}</span>
            </label>
            <div style={{ display: "flex", gap: 6 }}>
              <button type="button" role="menuitem" onClick={apply} style={{ flex: 1, padding: "5px 8px", borderRadius: 6, border: "none", background: color, color: "#111", fontWeight: 600, cursor: "pointer" }}>
                {menu.index === null ? "Add guide" : "Set"}
              </button>
              {menu.index !== null ? (
                <button type="button" role="menuitem" onClick={remove} style={{ flex: 1, padding: "5px 8px", borderRadius: 6, border: "1px solid #888", background: "transparent", color: "inherit", cursor: "pointer" }}>Remove</button>
              ) : null}
            </div>
          </div>
        </>
      ) : null}
      {confirm ? (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 9998 }} onPointerDown={() => { setConfirm(null); setHeld(null); }} />
          <div role="alertdialog" aria-label="Delete this guide?" data-testid="plate-guide-delete-confirm"
            style={{ position: "fixed", left: Math.max(8, Math.min(confirm.x - 110, window.innerWidth - 236)), top: Math.max(8, Math.min(confirm.y + 16, window.innerHeight - 130)), zIndex: 9999, background: "#15181c", color: "#f2f4f6", border: `1px solid ${axisColor(confirm.axis)}`, borderRadius: 12, padding: 12, width: 220, boxShadow: "0 6px 24px rgba(0,0,0,.35)", font: "500 14px system-ui, sans-serif" }}>
            <div style={{ fontWeight: 600, marginBottom: 4 }}>Delete this guide?</div>
            <div style={{ opacity: 0.75, fontSize: 12, marginBottom: 10 }}>{confirm.axis.toUpperCase()} {fmt(confirm.position)} {unit.label}</div>
            <div style={{ display: "flex", gap: 6 }}>
              <button type="button" data-testid="plate-guide-cancel" onClick={() => { setConfirm(null); setHeld(null); }} style={{ flex: 1, minHeight: 36, borderRadius: 8, border: "1px solid #888", background: "transparent", color: "inherit" }}>Cancel</button>
              <button type="button" data-testid="plate-guide-delete" onClick={() => { commit(guides.filter((_, i) => i !== confirm.index)); setConfirm(null); setHeld(null); }} style={{ flex: 1, minHeight: 36, borderRadius: 8, border: "none", background: "#e5484d", color: "#fff", fontWeight: 600 }}>Delete</button>
            </div>
            <button type="button" data-testid="plate-guide-edit" onClick={() => { const c = confirm; setConfirm(null); setHeld(null); openMenu({ kind: "guide", axis: c.axis, position: c.position, index: c.index }, c.x, c.y); }} style={{ marginTop: 8, width: "100%", minHeight: 32, borderRadius: 8, border: "none", background: "transparent", color: axisColor(confirm.axis), textDecoration: "underline" }}>Edit position…</button>
          </div>
        </>
      ) : null}
      {drag ? (
        <div data-testid="plate-guide-drag" style={{ position: "fixed", left: drag.x + 14, top: drag.y - 30, zIndex: 9999, pointerEvents: "none", background: "rgba(0,0,0,.8)", color: "#fff", padding: "3px 8px", borderRadius: 6, font: "600 12px system-ui, sans-serif" }}>{drag.text}</div>
      ) : null}
    </>,
    document.body,
  );
}

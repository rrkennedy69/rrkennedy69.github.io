"use client";

import * as THREE from "three";
import { createPortal } from "react-dom";
import { useCallback, useEffect, useRef, useState, type MutableRefObject } from "react";
import type { ThreeState } from "@/components/workplane/ViewportOverlays";
import { RENDER_LAYER_WORKPLANE } from "@/components/workplane/viewportScene";
import { ADD_PLATE_EVENT, BUILD_PLATES_EVENT, PLATE_GAP_MM, allPlates, readBuildPlates, readLockedPlates, writeBuildPlates, writeLockedPlates } from "@/lib/buildPlateStore";
import type { WorkplaneShape, WorkplaneWorkspaceSettings } from "@/types/layerling";


function labelSprite(text: string, color: string, size: number) {
  const canvas = document.createElement("canvas");
  canvas.width = 512; canvas.height = 128;
  const ctx = canvas.getContext("2d")!;
  ctx.font = "700 72px system-ui, sans-serif";
  ctx.textAlign = "center"; ctx.textBaseline = "middle";
  ctx.fillStyle = color;
  ctx.fillText(text, 256, 64);
  const tex = new THREE.CanvasTexture(canvas);
  tex.anisotropy = 4;
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(size * 4, size), new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, side: THREE.FrontSide }));
  mesh.rotation.x = -Math.PI / 2;
  mesh.raycast = () => {};
  mesh.userData.ownGeometry = true;
  return mesh;
}

/** Names in Plate 1's group that belong only to Plate 1 (design name, rulers, axes, workplane marker). */
const PLATE1_ONLY = /^(WorkplaneLabel|WorkplanePrinterLabel|WorkplaneRulers|WorkplaneAxisArrows|WorkplaneNormal)$/;

/**
 * An exact copy of Plate 1: its group (the printer's shaped plate model, outline, tab, texture/colour and
 * grid, all built by the same plate-building code) cloned and moved over. Geometry and materials are
 * shared with Plate 1, so a printer or plate-colour change rebuilds Plate 1 and the copies follow.
 */
function plateCopy(source: THREE.Object3D, offsetX: number) {
  const outer = new THREE.Group();
  outer.name = "BuildPlateCopy";
  outer.position.x = offsetX;
  const copy = source.clone(true);
  copy.name = "BuildPlateCopyInner";
  copy.traverse((o) => { o.raycast = () => {}; });
  copy.children.slice().forEach((c) => { if (PLATE1_ONLY.test(c.name)) copy.remove(c); });
  outer.add(copy);
  outer.traverse((o) => { o.layers.mask = source.layers.mask | o.layers.mask; });
  outer.updateMatrixWorld(true);
  return outer;
}

/**
 * Extra build plates (Manage → Add plate): copies of the main plate set in a row with a gap, labelled
 * Plate 1, Plate 2 ... Each plate has Bambu-style buttons off its back-right corner: X deletes it (after asking;
 * its objects move to the floor beside the plates) and a padlock locks every object on it.
 * The plates lie at height 0 like the main plate, so gravity and collision use each one as a floor.
 */
export function BuildPlates({ threeRef, workspace, projectId, shapes = [], onUpdateShapes }: {
  threeRef: MutableRefObject<ThreeState | null>;
  shapes?: readonly WorkplaneShape[];
  onUpdateShapes?: (changes: readonly { id: string; patch: Partial<WorkplaneShape> }[], message?: string) => void;
  workspace: Pick<WorkplaneWorkspaceSettings, "width" | "depth">;
  projectId: string | null | undefined;
}) {
  const [slots, setSlots] = useState<number[]>(() => readBuildPlates(projectId));
  const slotsRef = useRef(slots); slotsRef.current = slots;
  const wsRef = useRef(workspace); wsRef.current = workspace;
  const groupRef = useRef<THREE.Group | null>(null);
  const sourceRef = useRef<string>("");
  const paletteRef = useRef("");
  const [locked, setLocked] = useState<number[]>(() => readLockedPlates(projectId));
  const [confirm, setConfirm] = useState<{ slot: number; number: number } | null>(null);
  const shapesRef = useRef(shapes); shapesRef.current = shapes;

  useEffect(() => { setSlots(readBuildPlates(projectId)); setLocked(readLockedPlates(projectId)); }, [projectId]);
  useEffect(() => {
    const onChange = () => { setSlots(readBuildPlates(projectId)); setLocked(readLockedPlates(projectId)); };
    window.addEventListener(BUILD_PLATES_EVENT, onChange);
    return () => window.removeEventListener(BUILD_PLATES_EVENT, onChange);
  }, [projectId]);
  const commit = useCallback((next: number[]) => { setSlots(next); writeBuildPlates(projectId, next); }, [projectId]);

  useEffect(() => {
    const onAdd = () => {
      const cur = slotsRef.current;
      const next = (cur.length ? Math.max(...cur) : 0) + 1;
      commit([...cur, next]);
    };
    window.addEventListener(ADD_PLATE_EVENT, onAdd);
    return () => window.removeEventListener(ADD_PLATE_EVENT, onAdd);
  }, [commit]);

  const sync = useCallback(() => {
    const state = threeRef.current;
    if (!state) return;
    let group = groupRef.current;
    if (!group) { group = new THREE.Group(); group.name = "BuildPlates"; group.layers.set(RENDER_LAYER_WORKPLANE); groupRef.current = group; }
    if (group.parent !== state.scene) state.scene.add(group);
    group.children.slice().forEach((child) => {
      group!.remove(child);
      child.traverse((o) => { if (!o.userData.ownGeometry) return; const m = o as THREE.Mesh; m.geometry?.dispose(); const mat = m.material as THREE.MeshBasicMaterial | undefined; mat?.map?.dispose(); mat?.dispose?.(); });
    });
    const source = state.workplaneLayer.children.find((c) => c.name === "ActiveWorkplane") ?? state.workplaneLayer.children[0];
    sourceRef.current = source?.uuid ?? "";
    const list = slotsRef.current;
    if (!list.length) { state.needsRender = true; return; }
    const { width, depth } = wsRef.current;
    const size = Math.max(6, Math.min(width, depth) / 14);
    const night = document.documentElement.dataset.palette === "night";
    paletteRef.current = night ? "night" : "day";
    const color = night ? "#ff2a2a" : "#6b7480";
    allPlates(list, width).forEach((p) => {
      if (p.slot !== 0 && source) group!.add(plateCopy(source, p.offsetX));
      const label = labelSprite(p.label, color, size);
      label.position.set(p.offsetX, 0.05, depth / 2 + size * 1.9);
      group!.add(label);
    });
    state.needsRender = true;
  }, [threeRef]);

  useEffect(() => { sync(); }, [sync, slots, workspace.width, workspace.depth]);
  useEffect(() => {
    const id = window.setInterval(() => {
      const s = threeRef.current;
      if (!s) return;
      const source = s.workplaneLayer.children.find((c) => c.name === "ActiveWorkplane") ?? s.workplaneLayer.children[0];
      if (groupRef.current?.parent !== s.scene || (source?.uuid ?? "") !== sourceRef.current || (document.documentElement.dataset.palette === "night" ? "night" : "day") !== paletteRef.current) sync();
    }, 400);
    return () => window.clearInterval(id);
  }, [sync, threeRef]);

  // Test hook: plate-local millimetres (centre origin) on plate n (1-based) to screen pixels.
  useEffect(() => {
    (window as unknown as Record<string, unknown>).__buildPlateScreen = (n: number, x: number, z: number) => {
      const state = threeRef.current;
      if (!state) return null;
      const p = allPlates(slotsRef.current, wsRef.current.width)[n - 1];
      if (!p) return null;
      const rect = state.renderer.domElement.getBoundingClientRect();
      const v = new THREE.Vector3(p.offsetX + x, 0, z).project(state.camera);
      return { x: rect.left + (v.x + 1) / 2 * rect.width, y: rect.top + (1 - v.y) / 2 * rect.height };
    };
  }, [threeRef]);

  // ---- Bambu-style plate buttons -------------------------------------------------------------
  const plates = allPlates(slots, workspace.width);
  const onPlate = (shape: WorkplaneShape, offsetX: number) =>
    Math.abs(shape.x - offsetX) <= wsRef.current.width / 2 && Math.abs(shape.z) <= wsRef.current.depth / 2;

  const toggleLock = (slot: number, offsetX: number) => {
    const now = !locked.includes(slot);
    const next = now ? [...locked, slot] : locked.filter((s) => s !== slot);
    setLocked(next); writeLockedPlates(projectId, next);
    const changes = shapesRef.current.filter((sh) => onPlate(sh, offsetX) && Boolean(sh.locked) !== now).map((sh) => ({ id: sh.id, patch: { locked: now } }));
    if (changes.length) onUpdateShapes?.(changes, now ? "Lock plate" : "Unlock plate");
  };

  // Objects that arrive on a locked plate (dropped, pasted, imported) are locked too, so nothing there can be edited.
  useEffect(() => {
    if (!locked.length || !onUpdateShapes) return;
    const all = allPlates(slots, workspace.width);
    const changes = shapes.filter((sh) => !sh.locked && all.some((p) => locked.includes(p.slot) && onPlate(sh, p.offsetX))).map((sh) => ({ id: sh.id, patch: { locked: true } }));
    if (changes.length) onUpdateShapes(changes, "Lock plate");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shapes, locked, slots, workspace.width, workspace.depth]);

  // Delete any plate (Plate 1 too, unless it is the only one): its objects go to the floor beside the plates,
  // the plates after it slide over to close the gap (their objects with them) and everything is renumbered.
  const deletePlate = (slot: number) => {
    const { width } = wsRef.current;
    const pitch = width + PLATE_GAP_MM;
    const all = allPlates(slotsRef.current, width);
    const plate = all.find((p) => p.slot === slot);
    if (!plate || all.length < 2) return;
    const remaining = all.filter((p) => p.slot !== slot);
    const moveBy = new Map<number, number>(); // old slot -> new slot (compacted)
    remaining.forEach((p, i) => moveBy.set(p.slot, i));
    const floorX = remaining.length * pitch; // just past the new last plate
    const changes: { id: string; patch: Partial<WorkplaneShape> }[] = [];
    shapesRef.current.forEach((sh) => {
      if (onPlate(sh, plate.offsetX)) { changes.push({ id: sh.id, patch: { x: sh.x - plate.offsetX + floorX, ...(locked.includes(slot) ? { locked: false } : {}) } }); return; }
      const from = remaining.find((p) => onPlate(sh, p.offsetX));
      if (!from) return;
      const dx = (moveBy.get(from.slot)! - from.slot) * pitch;
      if (dx) changes.push({ id: sh.id, patch: { x: sh.x + dx } });
    });
    if (changes.length) onUpdateShapes?.(changes, `Delete ${plate.label}`);
    const nextLocked = locked.filter((s) => s !== slot && moveBy.has(s)).map((s) => moveBy.get(s)!);
    setLocked(nextLocked); writeLockedPlates(projectId, nextLocked);
    commit(remaining.slice(1).map((_, i) => i + 1));
  };

  // Screen-space buttons, kept on the plate's back-right corner every frame at a constant size.
  const hostRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    let raf = 0;
    const tick = () => {
      raf = requestAnimationFrame(tick);
      const state = threeRef.current, host = hostRef.current;
      if (!state || !host) return;
      const rect = state.renderer.domElement.getBoundingClientRect();
      const { width, depth } = wsRef.current;
      const project = (x: number, z: number) => { const v = new THREE.Vector3(x, 0, z).project(state.camera); return { x: rect.left + (v.x + 1) / 2 * rect.width, y: rect.top + (1 - v.y) / 2 * rect.height, ok: v.z < 1 && v.z > -1 }; };
      allPlates(slotsRef.current, width).forEach((p) => {
        const place = (el: HTMLElement | null, pt: { x: number; y: number; ok: boolean }) => {
          if (!el) return;
          const inside = pt.ok && pt.x > rect.left && pt.x < rect.right && pt.y > rect.top && pt.y < rect.bottom;
          el.style.display = inside ? "" : "none";
          el.style.transform = `translate(${Math.round(pt.x)}px, ${Math.round(pt.y)}px)`;
        };
        place(host.querySelector<HTMLElement>(`[data-plate-tools="${p.slot}"]`), project(p.offsetX + width / 2 + Math.max(2, width * 0.012), -depth / 2 + depth * 0.03));
        place(host.querySelector<HTMLElement>(`[data-plate-number="${p.slot}"]`), project(p.offsetX + width / 2, depth / 2));
      });
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [threeRef]);

  if (typeof document === "undefined") return null;
  const onlyPlate = plates.length === 1;
  return createPortal(
    <div ref={hostRef} className="pc-plate-tools-host" data-testid="plate-tools">
      {plates.map((p) => {
        const isLocked = locked.includes(p.slot);
        return (
          <div key={p.slot}>
            <div className="pc-plate-tools" data-plate-tools={p.slot} data-testid={`plate-tools-${p.number}`}>
              <button type="button" className="pc-plate-tool" aria-label={`Delete ${p.label}`} title={onlyPlate ? "The only plate can't be deleted" : `Delete ${p.label}`} data-testid={`plate-delete-${p.number}`}
                disabled={onlyPlate} onClick={() => setConfirm({ slot: p.slot, number: p.number })}>
                <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8" /></svg>
              </button>
              <button type="button" className={`pc-plate-tool${isLocked ? " is-locked" : ""}`} aria-pressed={isLocked}
                aria-label={isLocked ? `Unlock ${p.label}` : `Lock ${p.label}`} title={isLocked ? `Unlock ${p.label}` : `Lock ${p.label}`} data-testid={`plate-lock-${p.number}`}
                onClick={() => toggleLock(p.slot, p.offsetX)}>
                <svg viewBox="0 0 16 16" aria-hidden="true">
                  <rect x="3.5" y="7.5" width="9" height="6.5" rx="1.2" />
                  <path d={isLocked ? "M5.5 7.5V5.2a2.5 2.5 0 0 1 5 0v2.3" : "M5.5 7.5V5.2a2.5 2.5 0 0 1 4.9-.7"} />
                </svg>
              </button>
            </div>
            <div className="pc-plate-number" data-plate-number={p.slot}>{String(p.number).padStart(2, "0")}</div>
          </div>
        );
      })}
      {confirm ? (
        <div className="pc-plate-confirm-backdrop" onPointerDown={(e) => { if (e.target === e.currentTarget) setConfirm(null); }}>
          <div className="pc-plate-confirm" role="alertdialog" aria-modal="true" aria-labelledby="pc-plate-confirm-text" data-testid="plate-delete-confirm">
            <p id="pc-plate-confirm-text">Delete Plate {confirm.number}? Objects on it will be moved to the floor beside the plates.</p>
            <div className="pc-plate-confirm-actions">
              <button type="button" onClick={() => setConfirm(null)} autoFocus>Cancel</button>
              <button type="button" className="danger" data-testid="plate-delete-ok" onClick={() => { deletePlate(confirm.slot); setConfirm(null); }}>Delete</button>
            </div>
          </div>
        </div>
      ) : null}
    </div>,
    document.body,
  );
}

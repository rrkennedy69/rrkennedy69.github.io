"use client";

import * as THREE from "three";
import { createPortal } from "react-dom";
import { useCallback, useEffect, useRef, useState, type MutableRefObject } from "react";
import type { ThreeState } from "@/components/workplane/ViewportOverlays";
import { RENDER_LAYER_WORKPLANE } from "@/components/workplane/viewportScene";
import { ADD_PLATE_EVENT, BUILD_PLATES_EVENT, PLATE_GAP_MM, LEGACY_PLATE_GAP_MM, PLATES_PER_ROW, PLATE_LAYOUT_VERSION, allPlates, legacyPlateOffsetX, plateOffset, readPlateLayout, writePlateLayout, readBuildPlates, readLockedPlates, writeBuildPlates, writeLockedPlates } from "@/lib/buildPlateStore";
import type { WorkplaneShape, WorkplaneWorkspaceSettings } from "@/types/layerling";


function labelSprite(text: string, color: string, size: number) {
  const canvas = document.createElement("canvas");
  canvas.width = 512; canvas.height = 128;
  const ctx = canvas.getContext("2d")!;
  ctx.font = "700 72px system-ui, sans-serif";
  ctx.textAlign = "center"; ctx.textBaseline = "middle";
  ctx.fillStyle = color;
  ctx.fillText(text, 256, 64);
  const tex = new THREE.CanvasTexture(canvas);
  tex.anisotropy = 4;
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(size * 4, size), new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, side: THREE.FrontSide }));
  mesh.rotation.x = -Math.PI / 2;
  mesh.raycast = () => {};
  mesh.userData.ownGeometry = true;
  return mesh;
}


type ToolKind = "delete" | "lock" | "number";
/** Theme colours for the flat floor tiles (night/thermal/X-Ray also go through their WebGL colour pass). */
function toolColors() {
  const el = document.documentElement;
  const pal = el.dataset.palette ?? "";
  const dark = el.dataset.theme === "dark" || el.classList.contains("dark") || ["night", "thermal", "xray", "graphite"].includes(pal);
  if (pal === "night") return { line: "#ff2a2a", fill: "rgba(0,0,0,0.6)", hover: "#ff7070", on: "#ff2a2a", onInk: "#000000" };
  if (pal === "thermal") return { line: "#ffd23f", fill: "rgba(20,20,74,0.7)", hover: "#00e5ff", on: "#ff8a1f", onInk: "#14144a" };
  if (pal === "xray") return { line: "#e6e0ff", fill: "rgba(11,8,32,0.6)", hover: "#9fa8ff", on: "#9fa8ff", onInk: "#0b0820" };
  return dark ? { line: "#c9d4db", fill: "rgba(32,38,43,0.85)", hover: "#00aeea", on: "#00aeea", onInk: "#ffffff" }
    : { line: "#55606a", fill: "rgba(255,255,255,0.85)", hover: "#00aeea", on: "#00aeea", onInk: "#ffffff" };
}
function toolTexture(kind: ToolKind, opts: { locked?: boolean; hover?: boolean; disabled?: boolean; text?: string }) {
  const c = document.createElement("canvas"); c.width = kind === "number" ? 256 : 128; c.height = 128;
  const g = c.getContext("2d")!; const col = toolColors();
  const ink = opts.hover ? col.hover : col.line;
  g.globalAlpha = opts.disabled ? 0.35 : 1;
  if (kind === "number") {
    g.font = "800 104px system-ui, sans-serif"; g.textAlign = "center"; g.textBaseline = "middle";
    g.fillStyle = col.line; g.fillText(opts.text ?? "", 128, 70);
  } else {
    const r = 22; g.beginPath(); g.roundRect(8, 8, 112, 112, r);
    g.fillStyle = opts.locked ? col.on : col.fill; g.fill();
    g.lineWidth = opts.hover ? 8 : 6; g.strokeStyle = opts.locked ? col.on : ink; g.stroke();
    g.strokeStyle = opts.locked ? col.onInk : ink; g.lineWidth = 9; g.lineCap = "round"; g.lineJoin = "round";
    if (kind === "delete") { g.beginPath(); g.moveTo(40, 40); g.lineTo(88, 88); g.moveTo(88, 40); g.lineTo(40, 88); g.stroke(); }
    else {
      g.lineWidth = 7; g.beginPath(); g.roundRect(34, 60, 60, 40, 6); g.stroke();
      g.beginPath();
      if (opts.locked) { g.moveTo(46, 60); g.lineTo(46, 46); g.arc(64, 46, 18, Math.PI, 0); g.lineTo(82, 60); }
      else { g.moveTo(46, 60); g.lineTo(46, 46); g.arc(64, 46, 18, Math.PI, -0.35); }
      g.stroke();
    }
  }
  const t = new THREE.CanvasTexture(c); t.anisotropy = 8; t.colorSpace = THREE.SRGBColorSpace; return t;
}

/** Names in Plate 1's group that belong only to Plate 1 (design name, rulers, axes, workplane marker). */
const PLATE1_ONLY = /^(WorkplaneLabel|WorkplanePrinterLabel|WorkplaneRulers|WorkplaneAxisArrows|WorkplaneNormal)$/;

/**
 * An exact copy of Plate 1: its group (the printer's shaped plate model, outline, tab, texture/colour and
 * grid, all built by the same plate-building code) cloned and moved over. Geometry and materials are
 * shared with Plate 1, so a printer or plate-colour change rebuilds Plate 1 and the copies follow.
 */
function plateCopy(source: THREE.Object3D, offsetX: number, offsetZ: number) {
  const outer = new THREE.Group();
  outer.name = "BuildPlateCopy";
  outer.position.x = offsetX; outer.position.z = offsetZ;
  const copy = source.clone(true);
  copy.name = "BuildPlateCopyInner";
  copy.traverse((o) => { o.raycast = () => {}; });
  copy.children.slice().forEach((c) => { if (PLATE1_ONLY.test(c.name)) copy.remove(c); });
  outer.add(copy);
  outer.traverse((o) => { o.layers.mask = source.layers.mask | o.layers.mask; });
  outer.updateMatrixWorld(true);
  return outer;
}

/**
 * Extra build plates (Manage → Add plate): copies of the main plate set in a row with a gap, labelled
 * Plate 1, Plate 2 ... Each plate has Bambu-style buttons off its back-right corner: X deletes it (after asking;
 * its objects move to the floor beside the plates) and a padlock locks every object on it.
 * The plates lie at height 0 like the main plate, so gravity and collision use each one as a floor.
 */
export function BuildPlates({ threeRef, workspace, projectId, hidden = false, shapes = [], onUpdateShapes }: {
  /** The rail's Hide plate: every plate copy, label, number and tile goes with Plate 1. */
  hidden?: boolean;
  threeRef: MutableRefObject<ThreeState | null>;
  shapes?: readonly WorkplaneShape[];
  onUpdateShapes?: (changes: readonly { id: string; patch: Partial<WorkplaneShape> }[], message?: string) => void;
  workspace: Pick<WorkplaneWorkspaceSettings, "width" | "depth">;
  projectId: string | null | undefined;
}) {
  const [slots, setSlots] = useState<number[]>(() => readBuildPlates(projectId));
  const slotsRef = useRef(slots); slotsRef.current = slots;
  const wsRef = useRef(workspace); wsRef.current = workspace;
  const groupRef = useRef<THREE.Group | null>(null);
  const sourceRef = useRef<string>("");
  const paletteRef = useRef("");
  const [locked, setLocked] = useState<number[]>(() => readLockedPlates(projectId));
  const [confirm, setConfirm] = useState<{ slot: number; number: number } | null>(null);
  const shapesRef = useRef(shapes); shapesRef.current = shapes;
  const hiddenRef = useRef(hidden); hiddenRef.current = hidden;

  useEffect(() => { setSlots(readBuildPlates(projectId)); setLocked(readLockedPlates(projectId)); }, [projectId]);
  useEffect(() => {
    const onChange = () => { setSlots(readBuildPlates(projectId)); setLocked(readLockedPlates(projectId)); };
    window.addEventListener(BUILD_PLATES_EVENT, onChange);
    return () => window.removeEventListener(BUILD_PLATES_EVENT, onChange);
  }, [projectId]);
  // Older designs kept extra plates in one row 20 mm apart: move each object on such a plate to the same spot
  // on that plate's place in the grid (once per design; the design is then marked as using the grid).
  useEffect(() => {
    if (!projectId || readPlateLayout(projectId) >= PLATE_LAYOUT_VERSION) return;
    if (!slots.length) { writePlateLayout(projectId); return; }
    if (!onUpdateShapes || !shapes.length) return;
    const { width, depth } = wsRef.current;
    const changes: { id: string; patch: Partial<WorkplaneShape> }[] = [];
    shapesRef.current.forEach((sh) => {
      if (Math.abs(sh.z) > depth / 2) return;
      const slot = slots.find((k) => Math.abs(sh.x - legacyPlateOffsetX(k, width)) <= width / 2);
      if (slot === undefined) return;
      const to = plateOffset(slot, width, depth);
      changes.push({ id: sh.id, patch: { x: sh.x - legacyPlateOffsetX(slot, width) + to.offsetX, z: sh.z + to.offsetZ } });
    });
    writePlateLayout(projectId);
    if (changes.length) onUpdateShapes(changes, "Arrange plates");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId, slots, onUpdateShapes, shapes]);
  const commit = useCallback((next: number[]) => { setSlots(next); writeBuildPlates(projectId, next); }, [projectId]);

  useEffect(() => {
    const onAdd = () => {
      const cur = slotsRef.current;
      const next = (cur.length ? Math.max(...cur) : 0) + 1;
      commit([...cur, next]);
    };
    window.addEventListener(ADD_PLATE_EVENT, onAdd);
    return () => window.removeEventListener(ADD_PLATE_EVENT, onAdd);
  }, [commit]);

  const sync = useCallback(() => {
    const state = threeRef.current;
    if (!state) return;
    let group = groupRef.current;
    if (!group) { group = new THREE.Group(); group.name = "BuildPlates"; group.layers.set(RENDER_LAYER_WORKPLANE); groupRef.current = group; }
    if (group.parent !== state.scene) state.scene.add(group);
    group.visible = !hiddenRef.current;
    group.children.slice().forEach((child) => {
      group!.remove(child);
      child.traverse((o) => { if (!o.userData.ownGeometry) return; const m = o as THREE.Mesh; m.geometry?.dispose(); const mat = m.material as THREE.MeshBasicMaterial | undefined; mat?.map?.dispose(); mat?.dispose?.(); });
    });
    const source = state.workplaneLayer.children.find((c) => c.name === "ActiveWorkplane") ?? state.workplaneLayer.children[0];
    sourceRef.current = source?.uuid ?? "";
    const list = slotsRef.current;
    if (!list.length) { state.needsRender = true; return; }
    const { width, depth } = wsRef.current;
    const size = Math.max(6, Math.min(width, depth) / 14);
    const night = document.documentElement.dataset.palette === "night";
    paletteRef.current = night ? "night" : "day";
    const color = night ? "#ff2a2a" : "#6b7480";
    allPlates(list, width, depth).forEach((p) => {
      if (p.slot !== 0 && source) group!.add(plateCopy(source, p.offsetX, p.offsetZ));
      const label = labelSprite(p.label, color, size);
      label.position.set(p.offsetX, 0.05, p.offsetZ + depth / 2 + size * 1.9);
      group!.add(label);
    });
    state.needsRender = true;
  }, [threeRef]);

  useEffect(() => { sync(); }, [sync, slots, workspace.width, workspace.depth]);
  useEffect(() => {
    const id = window.setInterval(() => {
      const s = threeRef.current;
      if (!s) return;
      const source = s.workplaneLayer.children.find((c) => c.name === "ActiveWorkplane") ?? s.workplaneLayer.children[0];
      if (groupRef.current?.parent !== s.scene || (source?.uuid ?? "") !== sourceRef.current || (document.documentElement.dataset.palette === "night" ? "night" : "day") !== paletteRef.current) sync();
    }, 400);
    return () => window.clearInterval(id);
  }, [sync, threeRef]);

  // Test hook: plate-local millimetres (centre origin) on plate n (1-based) to screen pixels.
  useEffect(() => {
    (window as unknown as Record<string, unknown>).__buildPlateScreen = (n: number, x: number, z: number) => {
      const state = threeRef.current;
      if (!state) return null;
      const p = allPlates(slotsRef.current, wsRef.current.width, wsRef.current.depth)[n - 1];
      if (!p) return null;
      const rect = state.renderer.domElement.getBoundingClientRect();
      const v = new THREE.Vector3(p.offsetX + x, 0, p.offsetZ + z).project(state.camera);
      return { x: rect.left + (v.x + 1) / 2 * rect.width, y: rect.top + (1 - v.y) / 2 * rect.height };
    };
  }, [threeRef]);

  // ---- Bambu-style plate buttons -------------------------------------------------------------
  const plates = allPlates(slots, workspace.width, workspace.depth);
  const onPlate = (shape: WorkplaneShape, p: { offsetX: number; offsetZ: number }) =>
    Math.abs(shape.x - p.offsetX) <= wsRef.current.width / 2 && Math.abs(shape.z - p.offsetZ) <= wsRef.current.depth / 2;

  const toggleLock = (slot: number, plate: { offsetX: number; offsetZ: number }) => {
    const now = !locked.includes(slot);
    const next = now ? [...locked, slot] : locked.filter((s) => s !== slot);
    setLocked(next); writeLockedPlates(projectId, next);
    const changes = shapesRef.current.filter((sh) => onPlate(sh, plate) && Boolean(sh.locked) !== now).map((sh) => ({ id: sh.id, patch: { locked: now } }));
    if (changes.length) onUpdateShapes?.(changes, now ? "Lock plate" : "Unlock plate");
  };

  // Objects that arrive on a locked plate (dropped, pasted, imported) are locked too, so nothing there can be edited.
  useEffect(() => {
    if (!locked.length || !onUpdateShapes) return;
    const all = allPlates(slots, workspace.width, workspace.depth);
    const changes = shapes.filter((sh) => !sh.locked && all.some((p) => locked.includes(p.slot) && onPlate(sh, p))).map((sh) => ({ id: sh.id, patch: { locked: true } }));
    if (changes.length) onUpdateShapes(changes, "Lock plate");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shapes, locked, slots, workspace.width, workspace.depth]);

  // Delete any plate (Plate 1 too, unless it is the only one): its objects go to the floor beside the plates,
  // the plates after it slide over to close the gap (their objects with them) and everything is renumbered.
  const deletePlate = (slot: number) => {
    const { width, depth } = wsRef.current;
    const pitch = width + PLATE_GAP_MM;
    const all = allPlates(slotsRef.current, width, depth);
    const plate = all.find((p) => p.slot === slot);
    if (!plate || all.length < 2) return;
    const remaining = all.filter((p) => p.slot !== slot);
    const moveBy = new Map<number, number>(); // old slot -> new slot (compacted)
    remaining.forEach((p, i) => moveBy.set(p.slot, i));
    const floorX = Math.min(remaining.length, PLATES_PER_ROW) * pitch; // just right of the plate grid
    const changes: { id: string; patch: Partial<WorkplaneShape> }[] = [];
    shapesRef.current.forEach((sh) => {
      if (onPlate(sh, plate)) { changes.push({ id: sh.id, patch: { x: sh.x - plate.offsetX + floorX, z: sh.z - plate.offsetZ, ...(locked.includes(slot) ? { locked: false } : {}) } }); return; }
      const from = remaining.find((p) => onPlate(sh, p));
      if (!from) return;
      const to = plateOffset(moveBy.get(from.slot)!, width, depth);
      const dx = to.offsetX - from.offsetX, dz = to.offsetZ - from.offsetZ;
      if (dx || dz) changes.push({ id: sh.id, patch: { x: sh.x + dx, z: sh.z + dz } });
    });
    if (changes.length) onUpdateShapes?.(changes, `Delete ${plate.label}`);
    const nextLocked = locked.filter((s) => s !== slot && moveBy.has(s)).map((s) => moveBy.get(s)!);
    setLocked(nextLocked); writeLockedPlates(projectId, nextLocked);
    commit(remaining.slice(1).map((_, i) => i + 1));
  };

  // Bambu-style flat tiles lying on the floor beside each plate's right edge (they foreshorten and zoom with
  // the plate), plus the plate number at the front-right. Raycast for clicks/taps and hover.
  const toolsRef = useRef<THREE.Group | null>(null);
  const [hover, setHover] = useState<string | null>(null);
  const [paletteKey, setPaletteKey] = useState("");
  useEffect(() => {
    const read = () => setPaletteKey(`${document.documentElement.dataset.palette ?? ""}|${document.documentElement.dataset.theme ?? ""}|${document.documentElement.className}`);
    read();
    const mo = new MutationObserver(read);
    mo.observe(document.documentElement, { attributes: true, attributeFilter: ["data-palette", "data-theme", "class"] });
    return () => mo.disconnect();
  }, []);
  const tileLayout = useCallback(() => {
    const { width, depth } = wsRef.current;
    // Sit in the gap right of each plate, like Bambu's tiles, with room to spare before the next plate.
    const gap = 3;
    const size = Math.min(LEGACY_PLATE_GAP_MM - 4, Math.max(10, Math.min(width, depth) * 0.07));
    return allPlates(slotsRef.current, width, depth).flatMap((p) => {
      const x = p.offsetX + width / 2 + gap + size / 2;
      return [
        { key: `delete:${p.slot}`, kind: "delete" as const, plate: p, x, z: p.offsetZ - depth / 2 + size / 2, w: size, h: size },
        { key: `lock:${p.slot}`, kind: "lock" as const, plate: p, x, z: p.offsetZ - depth / 2 + size / 2 + size + gap, w: size, h: size },
        { key: `number:${p.slot}`, kind: "number" as const, plate: p, x: p.offsetX + width / 2 + gap + size, z: p.offsetZ + depth / 2 - size * 0.45, w: size * 2, h: size },
      ];
    });
  }, []);
  useEffect(() => {
    const state = threeRef.current;
    if (!state) return;
    let group = toolsRef.current;
    if (!group) { group = new THREE.Group(); group.name = "BuildPlateTools"; toolsRef.current = group; }
    if (group.parent !== state.scene) state.scene.add(group);
    group.children.slice().forEach((c) => { group!.remove(c); const m = c as THREE.Mesh; m.geometry.dispose(); const mat = m.material as THREE.MeshBasicMaterial; mat.map?.dispose(); mat.dispose(); });
    const only = slots.length === 0;
    tileLayout().forEach((t) => {
      const tex = toolTexture(t.kind, { locked: t.kind === "lock" && locked.includes(t.plate.slot), hover: hover === t.key, disabled: t.kind === "delete" && only, text: String(t.plate.number).padStart(2, "0") });
      const mesh = new THREE.Mesh(new THREE.PlaneGeometry(t.w, t.h), new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 }));
      mesh.rotation.x = -Math.PI / 2; mesh.position.set(t.x, 0.06, t.z);
      mesh.name = "BuildPlateTool"; mesh.userData.plateTool = t.key;
      mesh.layers.set(RENDER_LAYER_WORKPLANE);
      group!.add(mesh);
    });
    group.visible = !hiddenRef.current;
    group.updateMatrixWorld(true);
    state.needsRender = true;
  }, [threeRef, slots, locked, hover, paletteKey, workspace.width, workspace.depth, tileLayout]);
  useEffect(() => {
    if (groupRef.current) groupRef.current.visible = !hidden;
    if (toolsRef.current) toolsRef.current.visible = !hidden;
    if (hidden) setHover(null);
    if (threeRef.current) threeRef.current.needsRender = true;
  }, [hidden, threeRef]);
  useEffect(() => () => { const g = toolsRef.current; g?.parent?.remove(g); }, []);

  const actRef = useRef<(key: string) => void>(() => {});
  actRef.current = (key: string) => {
    const [kind, slotText] = key.split(":"); const slot = Number(slotText);
    const p = allPlates(slotsRef.current, wsRef.current.width, wsRef.current.depth).find((q) => q.slot === slot);
    if (!p) return;
    if (kind === "lock") toggleLock(p.slot, p);
    else if (kind === "delete" && slotsRef.current.length > 0) setConfirm({ slot: p.slot, number: p.number });
  };
  useEffect(() => {
    const ray = new THREE.Raycaster(); const ndc = new THREE.Vector2();
    const hit = (e: PointerEvent | MouseEvent) => {
      const state = threeRef.current, group = toolsRef.current;
      if (!state || !group || hiddenRef.current || e.target !== state.renderer.domElement) return null;
      const rect = state.renderer.domElement.getBoundingClientRect();
      ndc.set(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1);
      ray.setFromCamera(ndc, state.camera); ray.layers.enableAll();
      const key = ray.intersectObjects(group.children, false)[0]?.object.userData.plateTool as string | undefined;
      return key && !key.startsWith("number") ? key : null;
    };
    let pressed: string | null = null;
    const down = (e: PointerEvent) => { const k = hit(e); if (!k) return; pressed = k; e.preventDefault(); e.stopImmediatePropagation(); };
    const up = (e: PointerEvent) => { if (!pressed) return; const k = hit(e); e.preventDefault(); e.stopImmediatePropagation(); if (k === pressed) actRef.current(k); pressed = null; };
    const move = (e: PointerEvent) => {
      if (e.pointerType === "touch") return;
      const k = hit(e); const el = threeRef.current?.renderer.domElement;
      setHover((h) => (h === k ? h : k));
      if (el) el.style.cursor = k ? "pointer" : "";
    };
    const swallow = (e: MouseEvent) => { if (hit(e)) { e.preventDefault(); e.stopImmediatePropagation(); } };
    window.addEventListener("pointerdown", down, true); window.addEventListener("pointerup", up, true);
    window.addEventListener("pointermove", move, true);
    window.addEventListener("click", swallow, true); window.addEventListener("dblclick", swallow, true);
    (window as unknown as Record<string, unknown>).__plateToolScreen = (n: number, kind: ToolKind) => {
      const state = threeRef.current; const t = tileLayout().find((q) => q.plate.number === n && q.kind === kind);
      if (!state || !t) return null;
      const v = new THREE.Vector3(t.x, 0.06, t.z).project(state.camera); const rect = state.renderer.domElement.getBoundingClientRect();
      return { x: rect.left + (v.x + 1) / 2 * rect.width, y: rect.top + (1 - v.y) / 2 * rect.height };
    };
    return () => { window.removeEventListener("pointerdown", down, true); window.removeEventListener("pointerup", up, true); window.removeEventListener("pointermove", move, true); window.removeEventListener("click", swallow, true); window.removeEventListener("dblclick", swallow, true); };
  }, [threeRef, tileLayout]);

  if (typeof document === "undefined") return null;
  return createPortal(
    <div className="pc-plate-tools-host" data-testid="plate-tools">
      {confirm ? (
        <div className="pc-plate-confirm-backdrop" onPointerDown={(e) => { if (e.target === e.currentTarget) setConfirm(null); }}>
          <div className="pc-plate-confirm" role="alertdialog" aria-modal="true" aria-labelledby="pc-plate-confirm-text" data-testid="plate-delete-confirm">
            <p id="pc-plate-confirm-text">Delete Plate {confirm.number}? Objects on it will be moved to the floor beside the plates.</p>
            <div className="pc-plate-confirm-actions">
              <button type="button" onClick={() => setConfirm(null)} autoFocus>Cancel</button>
              <button type="button" className="danger" data-testid="plate-delete-ok" onClick={() => { deletePlate(confirm.slot); setConfirm(null); }}>Delete</button>
            </div>
          </div>
        </div>
      ) : null}
    </div>,
    document.body,
  );
}

"use client";

import * as THREE from "three";
import { createPortal } from "react-dom";
import { useCallback, useEffect, useRef, useState, type MutableRefObject } from "react";
import type { ThreeState } from "@/components/workplane/ViewportOverlays";
import { RENDER_LAYER_WORKPLANE } from "@/components/workplane/viewportScene";
import { ADD_PLATE_EVENT, BUILD_PLATES_EVENT, allPlates, readBuildPlates, writeBuildPlates } from "@/lib/buildPlateStore";
import type { WorkplaneWorkspaceSettings } from "@/types/layerling";

const LONG_PRESS_MS = 480;

function labelSprite(text: string, color: string, size: number) {
  const canvas = document.createElement("canvas");
  canvas.width = 512; canvas.height = 128;
  const ctx = canvas.getContext("2d")!;
  ctx.font = "700 72px system-ui, sans-serif";
  ctx.textAlign = "center"; ctx.textBaseline = "middle";
  ctx.fillStyle = color;
  ctx.fillText(text, 256, 64);
  const tex = new THREE.CanvasTexture(canvas);
  tex.anisotropy = 4;
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(size * 4, size), new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, side: THREE.FrontSide }));
  mesh.rotation.x = -Math.PI / 2;
  mesh.raycast = () => {};
  mesh.userData.ownGeometry = true;
  return mesh;
}

/** A plate of the same size: surface in the main plate's colour, a 10 mm grid and an outline. */
function plateMesh(width: number, depth: number, offsetX: number, source: THREE.Object3D | undefined, night: boolean) {
  let surfaceColor = new THREE.Color(night ? "#050000" : "#c9ced3");
  let opacity = 0.94;
  source?.traverse((o) => {
    const m = (o as THREE.Mesh).material as THREE.MeshStandardMaterial | undefined;
    if ((o as THREE.Mesh).isMesh && m && "color" in m && (o as THREE.Mesh).geometry?.type === "PlaneGeometry" && surfaceColor && opacity === 0.94) { surfaceColor = m.color.clone(); opacity = m.opacity ?? 0.94; }
  });
  const g = new THREE.Group();
  g.position.x = offsetX;
  const own = (o: THREE.Object3D) => { o.userData.ownGeometry = true; o.raycast = () => {}; return o; };
  const surface = new THREE.Mesh(new THREE.PlaneGeometry(width, depth), new THREE.MeshStandardMaterial({ color: surfaceColor, transparent: opacity < 1, opacity, roughness: 0.9, side: THREE.FrontSide }));
  surface.rotation.x = -Math.PI / 2; surface.receiveShadow = true;
  g.add(own(surface));
  const lineColor = night ? "#5a0000" : "#9aa3ab";
  const majorColor = night ? "#a00000" : "#6f7880";
  const pts: number[] = [], major: number[] = [];
  for (let x = 0; x <= width + 1e-6; x += 10) (Math.round(x) % 50 === 0 ? major : pts).push(-width / 2 + x, 0.02, -depth / 2, -width / 2 + x, 0.02, depth / 2);
  for (let z = 0; z <= depth + 1e-6; z += 10) (Math.round(z) % 50 === 0 ? major : pts).push(-width / 2, 0.02, depth / 2 - z, width / 2, 0.02, depth / 2 - z);
  const lines = (arr: number[], color: string) => { const geo = new THREE.BufferGeometry(); geo.setAttribute("position", new THREE.Float32BufferAttribute(arr, 3)); return own(new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.8 }))); };
  g.add(lines(pts, lineColor), lines(major, majorColor));
  const hw = width / 2, hd = depth / 2;
  g.add(lines([-hw, 0.03, -hd, hw, 0.03, -hd, hw, 0.03, -hd, hw, 0.03, hd, hw, 0.03, hd, -hw, 0.03, hd, -hw, 0.03, hd, -hw, 0.03, -hd], night ? "#ff2a2a" : "#4d555c"));
  return g;
}

/**
 * Extra build plates (Manage → Add plate): copies of the main plate set in a row with a gap, labelled
 * Plate 1, Plate 2 ... Right-click (long-press) an empty spot on an extra plate → Remove plate; the parts on it stay.
 * The plates lie at height 0 like the main plate, so gravity and collision use each one as a floor.
 */
export function BuildPlates({ threeRef, workspace, projectId }: {
  threeRef: MutableRefObject<ThreeState | null>;
  workspace: Pick<WorkplaneWorkspaceSettings, "width" | "depth">;
  projectId: string | null | undefined;
}) {
  const [slots, setSlots] = useState<number[]>(() => readBuildPlates(projectId));
  const slotsRef = useRef(slots); slotsRef.current = slots;
  const wsRef = useRef(workspace); wsRef.current = workspace;
  const groupRef = useRef<THREE.Group | null>(null);
  const sourceRef = useRef<string>("");
  const paletteRef = useRef("");
  const [menu, setMenu] = useState<{ x: number; y: number; slot: number; label: string } | null>(null);

  useEffect(() => { setSlots(readBuildPlates(projectId)); }, [projectId]);
  useEffect(() => {
    const onChange = () => setSlots(readBuildPlates(projectId));
    window.addEventListener(BUILD_PLATES_EVENT, onChange);
    return () => window.removeEventListener(BUILD_PLATES_EVENT, onChange);
  }, [projectId]);
  const commit = useCallback((next: number[]) => { setSlots(next); writeBuildPlates(projectId, next); }, [projectId]);

  useEffect(() => {
    const onAdd = () => {
      const cur = slotsRef.current;
      const next = (cur.length ? Math.max(...cur) : 0) + 1;
      commit([...cur, next]);
    };
    window.addEventListener(ADD_PLATE_EVENT, onAdd);
    return () => window.removeEventListener(ADD_PLATE_EVENT, onAdd);
  }, [commit]);

  const sync = useCallback(() => {
    const state = threeRef.current;
    if (!state) return;
    let group = groupRef.current;
    if (!group) { group = new THREE.Group(); group.name = "BuildPlates"; group.layers.set(RENDER_LAYER_WORKPLANE); groupRef.current = group; }
    if (group.parent !== state.scene) state.scene.add(group);
    group.children.slice().forEach((child) => {
      group!.remove(child);
      child.traverse((o) => { if (!o.userData.ownGeometry) return; const m = o as THREE.Mesh; m.geometry?.dispose(); const mat = m.material as THREE.MeshBasicMaterial | undefined; mat?.map?.dispose(); mat?.dispose?.(); });
    });
    const source = state.workplaneLayer.children.find((c) => c.name === "ActiveWorkplane") ?? state.workplaneLayer.children[0];
    sourceRef.current = source?.uuid ?? "";
    const list = slotsRef.current;
    if (!list.length) { state.needsRender = true; return; }
    const { width, depth } = wsRef.current;
    const size = Math.max(6, Math.min(width, depth) / 14);
    const night = document.documentElement.dataset.palette === "night";
    paletteRef.current = night ? "night" : "day";
    const color = night ? "#ff2a2a" : "#6b7480";
    allPlates(list, width).forEach((p) => {
      if (p.slot !== 0) group!.add(plateMesh(width, depth, p.offsetX, source, night));
      const label = labelSprite(p.label, color, size);
      label.position.set(p.offsetX, 0.05, depth / 2 + size * 1.9);
      group!.add(label);
    });
    state.needsRender = true;
  }, [threeRef]);

  useEffect(() => { sync(); }, [sync, slots, workspace.width, workspace.depth]);
  useEffect(() => {
    const id = window.setInterval(() => {
      const s = threeRef.current;
      if (!s) return;
      const source = s.workplaneLayer.children.find((c) => c.name === "ActiveWorkplane") ?? s.workplaneLayer.children[0];
      if (groupRef.current?.parent !== s.scene || (source?.uuid ?? "") !== sourceRef.current || (document.documentElement.dataset.palette === "night" ? "night" : "day") !== paletteRef.current) sync();
    }, 400);
    return () => window.clearInterval(id);
  }, [sync, threeRef]);

  // Test hook: plate-local millimetres (centre origin) on plate n (1-based) to screen pixels.
  useEffect(() => {
    (window as unknown as Record<string, unknown>).__buildPlateScreen = (n: number, x: number, z: number) => {
      const state = threeRef.current;
      if (!state) return null;
      const p = allPlates(slotsRef.current, wsRef.current.width)[n - 1];
      if (!p) return null;
      const rect = state.renderer.domElement.getBoundingClientRect();
      const v = new THREE.Vector3(p.offsetX + x, 0, z).project(state.camera);
      return { x: rect.left + (v.x + 1) / 2 * rect.width, y: rect.top + (1 - v.y) / 2 * rect.height };
    };
  }, [threeRef]);

  // Which extra plate (empty spot, no part under the pointer) a press lands on.
  const extraPlateAt = (clientX: number, clientY: number) => {
    const state = threeRef.current;
    if (!state || !slotsRef.current.length) return null;
    const rect = state.renderer.domElement.getBoundingClientRect();
    if (clientX < rect.left || clientX > rect.right || clientY < rect.top || clientY > rect.bottom) return null;
    const target = document.elementFromPoint(clientX, clientY);
    if (target !== state.renderer.domElement) return null;
    const ndc = new THREE.Vector2(((clientX - rect.left) / rect.width) * 2 - 1, -((clientY - rect.top) / rect.height) * 2 + 1);
    const ray = new THREE.Raycaster();
    ray.setFromCamera(ndc, state.camera);
    const point = new THREE.Vector3();
    if (!ray.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0, 1, 0), 0), point)) return null;
    const { width, depth } = wsRef.current;
    const plates = allPlates(slotsRef.current, width);
    const hit = plates.find((p) => p.slot !== 0 && Math.abs(point.x - p.offsetX) <= width / 2 && Math.abs(point.z) <= depth / 2 + Math.min(width, depth) / 7);
    if (!hit) return null;
    const shapes = (state as unknown as { shapeLayer?: THREE.Object3D }).shapeLayer;
    if (shapes && ray.intersectObject(shapes, true).length) return null;
    return hit;
  };

  useEffect(() => {
    let press: { id: number; x: number; y: number; timer: number } | null = null;
    const open = (x: number, y: number, hit: { slot: number; label: string }) => setMenu({ x, y, slot: hit.slot, label: hit.label });
    const onDown = (e: PointerEvent) => {
      if (menu) return;
      if (e.pointerType === "touch") {
        const hit = extraPlateAt(e.clientX, e.clientY);
        if (!hit) return;
        const timer = window.setTimeout(() => { press = null; open(e.clientX, e.clientY, hit); }, LONG_PRESS_MS);
        press = { id: e.pointerId, x: e.clientX, y: e.clientY, timer };
        return;
      }
      if (e.button !== 2) return;
      const hit = extraPlateAt(e.clientX, e.clientY);
      if (!hit) return;
      e.stopImmediatePropagation(); e.preventDefault();
    };
    const onMove = (e: PointerEvent) => {
      if (press && e.pointerId === press.id && Math.hypot(e.clientX - press.x, e.clientY - press.y) > 10) { window.clearTimeout(press.timer); press = null; }
    };
    const onUp = (e: PointerEvent) => {
      if (press && e.pointerId === press.id) { window.clearTimeout(press.timer); press = null; }
      if (e.pointerType === "touch" || e.button !== 2) return;
      const hit = extraPlateAt(e.clientX, e.clientY);
      if (!hit) return;
      e.stopImmediatePropagation(); e.preventDefault();
      open(e.clientX, e.clientY, hit);
    };
    const onContext = (e: MouseEvent) => { if (extraPlateAt(e.clientX, e.clientY)) { e.preventDefault(); e.stopImmediatePropagation(); } };
    window.addEventListener("pointerdown", onDown, true);
    window.addEventListener("pointermove", onMove, true);
    window.addEventListener("pointerup", onUp, true);
    window.addEventListener("pointercancel", onUp, true);
    window.addEventListener("contextmenu", onContext, true);
    return () => {
      window.removeEventListener("pointerdown", onDown, true);
      window.removeEventListener("pointermove", onMove, true);
      window.removeEventListener("pointerup", onUp, true);
      window.removeEventListener("pointercancel", onUp, true);
      window.removeEventListener("contextmenu", onContext, true);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [menu]);

  if (typeof document === "undefined" || !menu) return null;
  return createPortal(
    <>
      <div style={{ position: "fixed", inset: 0, zIndex: 9998 }} onPointerDown={() => setMenu(null)} onContextMenu={(e) => { e.preventDefault(); setMenu(null); }} />
      <div role="menu" data-testid="build-plate-menu" aria-label={menu.label}
        style={{ position: "fixed", left: Math.min(menu.x, window.innerWidth - 200), top: Math.min(menu.y, window.innerHeight - 100), zIndex: 9999, background: "#15181c", color: "#f2f4f6", border: "1px solid #555", borderRadius: 10, padding: 8, minWidth: 170, font: "500 13px system-ui, sans-serif" }}>
        <div style={{ fontWeight: 700, margin: "2px 4px 8px" }}>{menu.label}</div>
        <button type="button" role="menuitem" onClick={() => { commit(slotsRef.current.filter((s) => s !== menu.slot)); setMenu(null); }}
          style={{ width: "100%", padding: "6px 8px", borderRadius: 6, border: "1px solid #888", background: "transparent", color: "inherit", cursor: "pointer", textAlign: "left" }}>Remove plate</button>
      </div>
    </>,
    document.body,
  );
}

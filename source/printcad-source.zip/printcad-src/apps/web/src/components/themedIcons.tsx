"use client";
import { useSyncExternalStore, type ReactNode } from "react";

/**
 * Per-theme toolbar icons for the inspired themes (Blocks, Forge, Works). Each set is
 * drawn here from scratch in the style of the modeller it nods to - no vendor artwork,
 * logos or wordmarks. All share the 48x48 box of the default set.
 */
export type InspiredPalette = "blocks" | "forge" | "works";

function readPalette(): InspiredPalette | null {
  if (typeof document === "undefined") return null;
  const p = document.documentElement.dataset.palette;
  return p === "blocks" || p === "forge" || p === "works" ? p : null;
}
let observer: MutationObserver | null = null;
const listeners = new Set<() => void>();
function subscribe(notify: () => void) {
  listeners.add(notify);
  if (!observer && typeof MutationObserver !== "undefined") {
    observer = new MutationObserver(() => listeners.forEach((l) => l()));
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ["data-palette"] });
  }
  return () => { listeners.delete(notify); };
}
export function useInspiredPalette() {
  return useSyncExternalStore(subscribe, readPalette, () => null);
}

const N = { stroke: "none" } as const;
/* ---------- Blocks: chunky, bright, shaded solids with a dark outline ---------- */
function cube(x: number, y: number, s: number, top: string, left: string, right: string): ReactNode {
  const h = s / 2;
  return (
    <g strokeWidth={2} stroke="#1f2b38" strokeLinejoin="round">
      <path d={`M${x} ${y} l${s} ${-h} l${s} ${h} l${-s} ${h}Z`} fill={top} />
      <path d={`M${x} ${y} l${s} ${h} v${s * 1.1} l${-s} ${-h}Z`} fill={left} />
      <path d={`M${x + s} ${y + h} l${s} ${-h} v${s * 1.1} l${-s} ${h}Z`} fill={right} />
    </g>
  );
}
const arrow = (d: string, color: string) => (
  <g><path d={d} stroke="#1f2b38" strokeWidth={7} fill="none" strokeLinecap="round" strokeLinejoin="round" /><path d={d} stroke={color} strokeWidth={4} fill="none" strokeLinecap="round" strokeLinejoin="round" /></g>
);
const BLOCKS: Record<string, ReactNode> = {
  Home: <g strokeWidth={2} stroke="#1f2b38" strokeLinejoin="round"><path d="M6 24 24 9l18 15z" fill="#ff6b3d" /><path d="M11 23h26v17H11z" fill="#ffd34d" /><path d="M20 40V29h8v11z" fill="#3a8ee6" /></g>,
  Copy: <>{cube(6, 18, 11, "#8fe3ff", "#38b6e0", "#1c8fb8")}{cube(20, 22, 11, "#c6f1ff", "#5fd3f3", "#2aa6cf")}</>,
  Paste: <g stroke="#1f2b38" strokeWidth={2} strokeLinejoin="round"><rect x="9" y="9" width="30" height="33" rx="4" fill="#c98a4b" /><rect x="17" y="5" width="14" height="8" rx="2" fill="#9aa6b2" /><rect x="14" y="17" width="20" height="20" rx="2" fill="#fff" /></g>,
  Duplicate: <>{cube(6, 18, 11, "#ffe58a", "#ffc93c", "#e0a000")}{cube(20, 22, 11, "#ffe58a", "#ffc93c", "#e0a000")}</>,
  Trash: <g stroke="#1f2b38" strokeWidth={2} strokeLinejoin="round"><path d="M12 15h24l-2.5 26h-19z" fill="#ff6b6b" /><rect x="9" y="10" width="30" height="5" rx="2" fill="#c92a2a" /><path d="M20 20v16M28 20v16" stroke="#fff" strokeWidth={2.5} /></g>,
  Undo: arrow("M14 20h16a9 9 0 0 1 0 18H18M14 20l7-7M14 20l7 7", "#ffb347"),
  Redo: arrow("M34 20H18a9 9 0 0 0 0 18h12M34 20l-7-7M34 20l-7 7", "#ffb347"),
  Group: <>{cube(5, 22, 9, "#ff9d9d", "#ff6b6b", "#c92a2a")}{cube(21, 14, 9, "#9be8b8", "#5ee08f", "#1f9d55")}<rect x="3" y="5" width="42" height="38" rx="5" fill="none" stroke="#3a8ee6" strokeWidth={2.5} strokeDasharray="5 3" /></>,
  Ungroup: <>{cube(3, 26, 9, "#ff9d9d", "#ff6b6b", "#c92a2a")}{cube(24, 12, 9, "#9be8b8", "#5ee08f", "#1f9d55")}</>,
  Mirror: <><path d="M24 5v38" stroke="#3a8ee6" strokeWidth={3} strokeDasharray="4 3" /><path d="M20 12 6 36h14z" fill="#b48cff" stroke="#1f2b38" strokeWidth={2} strokeLinejoin="round" /><path d="M28 12l14 24H28z" fill="#e4d6ff" stroke="#1f2b38" strokeWidth={2} strokeLinejoin="round" /></>,
  Import: <>{cube(8, 26, 16, "#c6f1ff", "#5fd3f3", "#1c8fb8")}{arrow("M24 4v16M17 13l7 7 7-7", "#5ee08f")}</>,
  Export: <>{cube(8, 26, 16, "#ffe58a", "#ffc93c", "#e0a000")}{arrow("M24 22V5M17 11l7-7 7 7", "#3a8ee6")}</>,
  Settings: <g stroke="#1f2b38" strokeWidth={2}><path d="M24 5l4 5 6-2 1 6 6 2-2 6 5 4-5 4 2 6-6 2-1 6-6-2-4 5-4-5-6 2-1-6-6-2 2-6-5-4 5-4-2-6 6-2 1-6 6 2z" fill="#9aa6b2" /><circle cx="24" cy="24" r="6" fill="#fff" /></g>,
  Fillet: <><path d="M8 40V8h14a18 18 0 0 1 18 18v14z" fill="#ff8a3d" stroke="#1f2b38" strokeWidth={2} /><path d="M22 8a18 18 0 0 1 18 18" stroke="#ffd34d" strokeWidth={4} fill="none" /></>,
  Chamfer: <><path d="M8 40V8h18l14 14v18z" fill="#ff8a3d" stroke="#1f2b38" strokeWidth={2} strokeLinejoin="round" /><path d="M26 8l14 14" stroke="#ffd34d" strokeWidth={4} /></>,
  Hollow: <>{cube(6, 18, 18, "#d0d6dd", "#9aa6b2", "#7d8b99")}<path d="M14 18l10-5 10 5-10 5z" fill="#3b4652" /></>,
  Pattern: <>{cube(4, 14, 7, "#ffe58a", "#ffc93c", "#e0a000")}{cube(26, 14, 7, "#ffe58a", "#ffc93c", "#e0a000")}{cube(4, 32, 7, "#ffe58a", "#ffc93c", "#e0a000")}{cube(26, 32, 7, "#ffe58a", "#ffc93c", "#e0a000")}</>,
  Note: <g stroke="#1f2b38" strokeWidth={2}><path d="M9 6h22l8 8v28H9z" fill="#fff59d" /><path d="M31 6v8h8" fill="#ffd34d" /><path d="M15 22h18M15 29h18M15 36h11" stroke="#a37b00" /></g>,
};
/* ---------- Forge: flat line icons, grey outline, blue faces, orange accent ---------- */
const G = "#56616b", B = "#3d8fe0", BL = "#cfe3f8", O = "#ee7b1e";
const fl = (children: ReactNode) => <g stroke={G} strokeWidth={1.6} strokeLinejoin="miter" strokeLinecap="butt" fill="none">{children}</g>;
const fCube = (x: number, y: number, s: number, fill = BL) => <><path d={`M${x} ${y} l${s} ${-s / 2} l${s} ${s / 2} v${s} l${-s} ${s / 2} l${-s} ${-s / 2}z`} fill={fill} /><path d={`M${x} ${y} l${s} ${s / 2} l${s} ${-s / 2} M${x + s} ${y + s / 2} v${s}`} /></>;
const FORGE: Record<string, ReactNode> = {
  Home: fl(<><path d="M8 23 24 10l16 13" /><path d="M12 21v18h24V21" fill={BL} /><path d="M21 39v-9h6v9" stroke={O} /></>),
  Copy: fl(<><rect x="9" y="9" width="20" height="24" fill="#fff" /><rect x="18" y="15" width="20" height="24" fill={BL} stroke={B} /></>),
  Paste: fl(<><rect x="10" y="9" width="26" height="31" /><rect x="18" y="6" width="10" height="6" fill="#fff" /><rect x="17" y="18" width="20" height="22" fill={BL} stroke={B} /></>),
  Duplicate: fl(<>{fCube(6, 18, 11)}<g stroke={O}>{fCube(22, 22, 10, "#ffe1c4")}</g></>),
  Trash: fl(<><path d="M10 13h28M19 13V9h10v4M13 13l2 27h18l2-27" /><path d="M21 19v15M27 19v15" stroke={O} /></>),
  Undo: fl(<path d="M14 18h15a9 9 0 0 1 0 18H18M14 18l6-6M14 18l6 6" stroke={B} strokeWidth={2} />),
  Redo: fl(<path d="M34 18H19a9 9 0 0 0 0 18h11M34 18l-6-6M34 18l-6 6" stroke={B} strokeWidth={2} />),
  Group: fl(<>{fCube(7, 20, 8)}{fCube(23, 14, 8)}<rect x="4" y="6" width="40" height="36" stroke={O} strokeDasharray="4 3" /></>),
  Ungroup: fl(<>{fCube(4, 26, 8)}{fCube(26, 10, 8)}<path d="M22 24l6-6" stroke={O} /></>),
  Mirror: fl(<><path d="M24 5v38" stroke={O} strokeDasharray="4 3" /><path d="M20 12 7 36h13z" fill={BL} /><path d="M28 12l13 24H28z" /></>),
  Import: fl(<><path d="M8 30v10h32V30" /><path d="M24 6v24M16 22l8 8 8-8" stroke={B} strokeWidth={2} /></>),
  Export: fl(<><path d="M8 30v10h32V30" /><path d="M24 30V6M16 14l8-8 8 8" stroke={O} strokeWidth={2} /></>),
  Settings: fl(<><circle cx="24" cy="24" r="11" fill={BL} /><circle cx="24" cy="24" r="4" stroke={O} /><path d="M24 6v6M24 36v6M6 24h6M36 24h6M11 11l4 4M33 33l4 4M37 11l-4 4M15 33l-4 4" /></>),
  Fillet: fl(<><path d="M9 39V9h12a18 18 0 0 1 18 18v12z" fill={BL} /><path d="M21 9a18 18 0 0 1 18 18" stroke={O} strokeWidth={2.4} /></>),
  Chamfer: fl(<><path d="M9 39V9h17l13 13v17z" fill={BL} /><path d="M26 9l13 13" stroke={O} strokeWidth={2.4} /></>),
  Hollow: fl(<>{fCube(6, 18, 18)}<path d="M13 18l11-5.5L35 18l-11 5.5z" fill="#fff" stroke={O} /></>),
  Pattern: fl(<>{[8, 28].flatMap((x) => [8, 28].map((y) => <rect key={`${x}${y}`} x={x} y={y} width="12" height="12" fill={x + y === 16 ? BL : "#fff"} stroke={x + y === 16 ? B : G} />))}</>),
  Note: fl(<><path d="M10 6h20l8 8v28H10z" /><path d="M30 6v8h8" /><path d="M16 22h16M16 29h16M16 36h10" stroke={B} /></>),
};
/* ---------- Works: small, detailed, gradient-shaded with navy lines and a red/green accent ---------- */
const NV = "#1d3557", R = "#d0202e", GR = "#1e9e3a";
const wd = (children: ReactNode) => (
  <g transform="translate(5 5) scale(.79)" stroke={NV} strokeWidth={1.6} strokeLinejoin="miter" fill="none">
    <defs>
      <linearGradient id="pcw-g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fff6c8" /><stop offset="1" stopColor="#d8a933" /></linearGradient>
      <linearGradient id="pcw-s" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#f4f7fa" /><stop offset="1" stopColor="#8d9bab" /></linearGradient>
      <linearGradient id="pcw-b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#bcd6f5" /><stop offset="1" stopColor="#4f7fbf" /></linearGradient>
    </defs>
    {children}
  </g>
);
const wCube = (x: number, y: number, s: number, f = "url(#pcw-g)") => <><path d={`M${x} ${y} l${s} ${-s / 2} l${s} ${s / 2} v${s} l${-s} ${s / 2} l${-s} ${-s / 2}z`} fill={f} /><path d={`M${x} ${y} l${s} ${s / 2} l${s} ${-s / 2} M${x + s} ${y + s / 2} v${s}`} /><path d={`M${x} ${y} l${s} ${-s / 2} l${s} ${s / 2} l${-s} ${s / 2}z`} fill="#fff" opacity={0.45} stroke="none" /></>;
const WORKS: Record<string, ReactNode> = {
  Home: wd(<><path d="M6 24 24 8l18 16" stroke={R} strokeWidth={2.4} /><path d="M11 22v19h26V22" fill="url(#pcw-s)" /><path d="M20 41V30h8v11" fill="url(#pcw-b)" /></>),
  Copy: wd(<><rect x="7" y="7" width="22" height="26" fill="url(#pcw-s)" /><rect x="17" y="15" width="22" height="26" fill="#fff" /><path d="M21 22h14M21 27h14M21 32h10" stroke="#7a8ea6" /></>),
  Paste: wd(<><rect x="8" y="9" width="28" height="33" fill="url(#pcw-g)" /><rect x="16" y="5" width="12" height="7" fill="url(#pcw-s)" /><rect x="18" y="18" width="22" height="24" fill="#fff" /></>),
  Duplicate: wd(<>{wCube(4, 18, 12)}{wCube(20, 24, 12, "url(#pcw-b)")}</>),
  Trash: wd(<><path d="M12 14h24l-2 28H14z" fill="url(#pcw-s)" /><rect x="9" y="9" width="30" height="5" fill="url(#pcw-s)" /><path d="M14 18l20 20M34 18 14 38" stroke={R} strokeWidth={3} /></>),
  Undo: wd(<path d="M12 18h17a10 10 0 0 1 0 20H18M12 18l7-7M12 18l7 7" stroke={GR} strokeWidth={3.6} />),
  Redo: wd(<path d="M36 18H19a10 10 0 0 0 0 20h11M36 18l-7-7M36 18l-7 7" stroke={GR} strokeWidth={3.6} />),
  Group: wd(<>{wCube(4, 22, 10)}{wCube(24, 14, 10, "url(#pcw-b)")}<path d="M3 6h42v38H3z" stroke={GR} strokeDasharray="3 2" /></>),
  Ungroup: wd(<>{wCube(2, 28, 10)}{wCube(26, 10, 10, "url(#pcw-b)")}<path d="M20 26l8-8" stroke={R} strokeWidth={2.4} /></>),
  Mirror: wd(<><path d="M24 4v40" stroke={R} strokeDasharray="5 2 1 2" /><path d="M20 10 5 38h15z" fill="url(#pcw-g)" /><path d="M28 10l15 28H28z" fill="url(#pcw-s)" opacity={0.85} /></>),
  Import: wd(<>{wCube(8, 28, 16, "url(#pcw-s)")}<path d="M24 3v18M17 14l7 7 7-7" stroke={GR} strokeWidth={3.4} /></>),
  Export: wd(<>{wCube(8, 28, 16)}<path d="M24 22V4M17 11l7-7 7 7" stroke={R} strokeWidth={3.4} /></>),
  Settings: wd(<><path d="M24 5l4 5 6-2 1 6 6 2-2 6 5 4-5 4 2 6-6 2-1 6-6-2-4 5-4-5-6 2-1-6-6-2 2-6-5-4 5-4-2-6 6-2 1-6 6 2z" fill="url(#pcw-s)" /><circle cx="24" cy="24" r="6" fill="url(#pcw-b)" /></>),
  Fillet: wd(<><path d="M8 40V8h13a19 19 0 0 1 19 19v13z" fill="url(#pcw-g)" /><path d="M21 8a19 19 0 0 1 19 19" stroke={R} strokeWidth={3} /></>),
  Chamfer: wd(<><path d="M8 40V8h18l14 14v18z" fill="url(#pcw-g)" /><path d="M26 8l14 14" stroke={R} strokeWidth={3} /></>),
  Hollow: wd(<>{wCube(6, 18, 18)}<path d="M13 18l11-5.5L35 18l-11 5.5z" fill="url(#pcw-b)" /></>),
  Pattern: wd(<>{wCube(3, 12, 8)}{wCube(27, 12, 8, "url(#pcw-s)")}{wCube(3, 32, 8, "url(#pcw-s)")}{wCube(27, 32, 8, "url(#pcw-s)")}</>),
  Note: wd(<><path d="M9 5h22l8 8v30H9z" fill="#fff" /><path d="M31 5v8h8" fill="url(#pcw-s)" /><path d="M15 21h18M15 28h18M15 35h12" stroke="#7a8ea6" /></>),
};
export const INSPIRED_ICON_SETS: Record<InspiredPalette, Record<string, ReactNode>> = { blocks: BLOCKS, forge: FORGE, works: WORKS };
void N;

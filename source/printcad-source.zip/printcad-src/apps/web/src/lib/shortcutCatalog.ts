import type { MessageKey } from "@/lib/i18n";

/**
 * One shortcut: the keys stay literal in both languages, only the sentence
 * beside them is translated. `combos` holds the alternatives - "F or Home" -
 * and a combo spells its keys with "+", the way the toolbar hints already do.
 * A slash inside one key means "any of these", as with the arrow keys.
 */
export type Shortcut = { combos: string[]; label: MessageKey };
/**
 * Sketch mode replaces the whole workspace, so its keys and the ones for solid
 * bodies never apply at the same time. Each group says where it belongs and the
 * dialog only lists what the current mode actually listens for.
 */
export type ShortcutGroup = { title: MessageKey; mode: "geometry" | "sketch"; shortcuts: Shortcut[] };

export const SHORTCUT_GROUPS: ShortcutGroup[] = [
  {
    title: "shortcuts.group.selection",
    mode: "geometry",
    shortcuts: [
      { combos: ["Esc"], label: "shortcuts.clearSelection" },
      { combos: ["Delete", "Backspace"], label: "shortcuts.delete" },
      { combos: ["Ctrl+A"], label: "shortcuts.selectAll" },
      { combos: ["Shift+Click"], label: "shortcuts.addToSelection" },
      { combos: ["RightClick"], label: "shortcuts.contextMenu" },
    ],
  },
  {
    title: "shortcuts.group.clipboard",
    mode: "geometry",
    shortcuts: [
      { combos: ["Ctrl+C"], label: "shortcuts.copy" },
      { combos: ["Ctrl+X"], label: "shortcuts.cut" },
      { combos: ["Ctrl+V"], label: "shortcuts.paste" },
      { combos: ["Ctrl+D"], label: "shortcuts.duplicate" },
    ],
  },
  {
    title: "shortcuts.group.history",
    mode: "geometry",
    shortcuts: [
      { combos: ["Ctrl+Z"], label: "shortcuts.undo" },
      { combos: ["Ctrl+Shift+Z", "Ctrl+Y"], label: "shortcuts.redo" },
      { combos: ["← / →", "Wheel"], label: "shortcuts.historyView" },
      { combos: ["PgUp / PgDn"], label: "shortcuts.historyViewPage" },
      { combos: ["Home / End"], label: "shortcuts.historyViewEnds" },
      { combos: ["Esc"], label: "shortcuts.historyViewClose" },
    ],
  },
  {
    title: "shortcuts.group.file",
    mode: "geometry",
    shortcuts: [
      { combos: ["Ctrl+I"], label: "shortcuts.import" },
      { combos: ["Ctrl+E"], label: "shortcuts.export" },
      { combos: ["Ctrl+S"], label: "shortcuts.save" },
    ],
  },
  {
    title: "shortcuts.group.organise",
    mode: "geometry",
    shortcuts: [
      { combos: ["Ctrl+G"], label: "shortcuts.group" },
      { combos: ["Ctrl+B"], label: "shortcuts.bundle" },
      { combos: ["Ctrl+Shift+G"], label: "shortcuts.ungroup" },
      { combos: ["E"], label: "shortcuts.editGroup" },
      { combos: ["Ctrl+L"], label: "shortcuts.lock" },
      { combos: ["Ctrl+H"], label: "shortcuts.hide" },
      { combos: ["Ctrl+Shift+H"], label: "shortcuts.showHidden" },
      { combos: ["Shift+N"], label: "shortcuts.toggleNotes" },
      { combos: ["Ctrl+Shift+O"], label: "shortcuts.outliner" },
    ],
  },
  {
    title: "shortcuts.group.shape",
    mode: "geometry",
    shortcuts: [
      { combos: ["H"], label: "shortcuts.hole" },
      { combos: ["S"], label: "shortcuts.solid" },
      { combos: ["T"], label: "shortcuts.transparent" },
      { combos: ["Shift+M"], label: "shortcuts.multicolor" },
      { combos: ["M"], label: "shortcuts.mirror" },
      { combos: ["B"], label: "shortcuts.fillet" },
      { combos: ["Shift+B"], label: "shortcuts.chamfer" },
      { combos: ["L"], label: "shortcuts.align" },
      { combos: ["Alt+Click"], label: "shortcuts.alignSize" },
      { combos: ["D"], label: "shortcuts.dropToWorkplane" },
      { combos: ["C"], label: "shortcuts.carryOntoFace" },
      { combos: ["N"], label: "shortcuts.note" },
    ],
  },
  {
    title: "shortcuts.group.transform",
    mode: "geometry",
    shortcuts: [
      { combos: ["← / → / ↑ / ↓"], label: "shortcuts.nudge" },
      { combos: ["Shift+← / → / ↑ / ↓"], label: "shortcuts.nudgeCoarse" },
      { combos: ["Alt+← / → / ↑ / ↓"], label: "shortcuts.nudgeFine" },
      { combos: ["Ctrl+↑ / ↓"], label: "shortcuts.raise" },
      { combos: ["R"], label: "shortcuts.rotate" },
      { combos: ["Shift+R"], label: "shortcuts.rotateFine" },
      { combos: ["Shift"], label: "shortcuts.axisLockDrag" },
      { combos: ["Alt+Drag"], label: "shortcuts.duplicateDrag" },
      { combos: ["Alt"], label: "shortcuts.pauseObjectSnap" },
      { combos: ["Alt+Enter"], label: "shortcuts.sizeAroundCenter" },
    ],
  },
  {
    title: "shortcuts.group.view",
    mode: "geometry",
    shortcuts: [
      { combos: ["1 – 6"], label: "shortcuts.views" },
      { combos: ["Shift+1 – 6"], label: "shortcuts.viewsFocus" },
      { combos: ["7 / 8 / 9 / 0"], label: "shortcuts.savedViews" },
      { combos: ["Shift+7 / 8 / 9 / 0"], label: "shortcuts.saveView" },
      { combos: ["← / → / ↑ / ↓"], label: "shortcuts.orbit" },
      { combos: ["Shift+← / → / ↑ / ↓"], label: "shortcuts.orbitCoarse" },
      { combos: ["Ctrl+← / → / ↑ / ↓"], label: "shortcuts.pan" },
      { combos: ["Ctrl+Shift+← / → / ↑ / ↓"], label: "shortcuts.panCoarse" },
      { combos: ["Home"], label: "shortcuts.resetView" },
      { combos: ["F", "Shift+F"], label: "shortcuts.focusSelection" },
      { combos: ["O"], label: "shortcuts.projection" },
      { combos: ["Q"], label: "shortcuts.toggleDimensions" },
      { combos: ["+", "−"], label: "shortcuts.zoom" },
      { combos: ["Alt+1 – 0"], label: "shortcuts.snapGridPick" },
      { combos: [",", "."], label: "shortcuts.snapGridStep" },
      { combos: ["W"], label: "shortcuts.placeWorkplane" },
      { combos: ["Shift+W"], label: "shortcuts.placeWorkplaneOnSelection" },
      { combos: ["Alt+W"], label: "shortcuts.resetWorkplane" },
      { combos: ["Shift"], label: "shortcuts.reverseWorkplane" },
      { combos: ["Esc"], label: "shortcuts.leaveMode" },
    ],
  },
  {
    title: "shortcuts.group.help",
    mode: "geometry",
    shortcuts: [
      { combos: ["Ctrl+K"], label: "shortcuts.commandSearch" },
      { combos: ["Shift+F1"], label: "shortcuts.interactiveHelp" },
    ],
  },
  {
    title: "shortcuts.group.sketch",
    mode: "sketch",
    shortcuts: [
      { combos: ["Ctrl+K"], label: "shortcuts.commandSearch" },
      { combos: ["Shift+F1"], label: "shortcuts.interactiveHelp" },
      { combos: ["Esc"], label: "shortcuts.sketchEscape" },
      { combos: ["Delete", "Backspace"], label: "shortcuts.sketchDelete" },
      { combos: ["Ctrl+C"], label: "shortcuts.copy" },
      { combos: ["Ctrl+X"], label: "shortcuts.cut" },
      { combos: ["Ctrl+V"], label: "shortcuts.paste" },
      { combos: ["Ctrl+D"], label: "shortcuts.duplicate" },
      { combos: ["Ctrl+Z"], label: "shortcuts.undo" },
      { combos: ["Ctrl+Shift+Z", "Ctrl+Y"], label: "shortcuts.redo" },
      { combos: ["Ctrl+A"], label: "shortcuts.sketchSelectAll" },
      { combos: ["Ctrl+I"], label: "sketch.addImage" },
      { combos: ["R"], label: "shortcuts.sketchRotate" },
      { combos: ["Ctrl+L"], label: "shortcuts.sketchLockImage" },
      { combos: ["N"], label: "shortcuts.note" },
      { combos: ["Shift+N"], label: "shortcuts.toggleNotes" },
      { combos: ["Ctrl+← / → / ↑ / ↓"], label: "shortcuts.pan" },
      { combos: ["Ctrl+Shift+← / → / ↑ / ↓"], label: "shortcuts.panCoarse" },
      { combos: ["Home"], label: "shortcuts.sketchResetView" },
      { combos: ["F", "Shift+F"], label: "shortcuts.sketchFocusSelection" },
      { combos: ["+", "−"], label: "shortcuts.sketchZoom" },
      { combos: ["Alt+1 – 0"], label: "shortcuts.snapGridPick" },
      { combos: [",", "."], label: "shortcuts.snapGridStep" },
      { combos: ["Alt+Enter"], label: "shortcuts.sketchDimensionSymmetric" },
      { combos: ["← / → / ↑ / ↓", "Shift+← / → / ↑ / ↓"], label: "shortcuts.sketchNudge" },
      { combos: ["← / → / ↑ / ↓", "Shift+← / → / ↑ / ↓"], label: "shortcuts.sketchHandleNudge" },
      { combos: ["1", "2", "3", "4"], label: "shortcuts.sketchTools" },
      { combos: ["Shift"], label: "shortcuts.sketchAngleSnap" },
      { combos: ["Shift"], label: "shortcuts.sketchAxisLock" },
      { combos: ["0-9", "<", "Tab", "Enter"], label: "shortcuts.sketchTypedLine" },
    ],
  },
  {
    title: "shortcuts.group.edgeModifier",
    mode: "geometry",
    shortcuts: [
      { combos: ["Enter"], label: "shortcuts.edgeApply" },
      { combos: ["Esc"], label: "shortcuts.edgeCancel" },
    ],
  },
];

/** Splits a combo into its keys - and leaves the "+" of the zoom key alone. */
export function comboKeys(combo: string) {
  const parts = combo.split("+").map((part) => part.trim()).filter(Boolean);
  return parts.length > 0 ? parts : [combo];
}

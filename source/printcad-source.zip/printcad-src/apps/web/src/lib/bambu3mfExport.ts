import { strToU8, zip, zipSync } from "fflate";
import { layerlingToZUp, type MeshPoint } from "@/lib/meshCoordinates";
import { weldMeshVertices } from "@/lib/objExport";
import { bambuFilamentPreset, bambuMaterial, DEFAULT_BAMBU_MATERIAL, type BambuPrinter } from "@/lib/bambuFilaments";
import type { ShapeFilament } from "@/types/layerling";

// ---------------------------------------------------------------------------
// Bambu Studio / OrcaSlicer project 3MF (format reference: BambuStudio
// src/libslic3r/Format/bbs_3mf.cpp and src/slic3r/GUI/PartPlate.cpp).
//
// - "Application" must start with "BambuStudio-" or both slicers ignore the
//   project settings and load only the geometry.
// - Presets are referenced by name only. Each preset in inherits_group gets a
//   non-empty different_settings_to_system entry, which makes the slicer reset
//   every key not listed there to the system preset's own value, so the file
//   need not carry the full ~450-key configuration.
// - Plates sit where Bambu Studio puts them: columns = ceil(sqrt(n)), stride
//   = bed size x 1.2, rows toward -Y.
// ---------------------------------------------------------------------------

export type BambuBody = { name: string; color?: string; filament?: ShapeFilament; vertices: readonly MeshPoint[]; faces: readonly (readonly [number, number, number])[] };
export type BambuPlate = { number: number; bodies: BambuBody[] };
export type BambuProfileValue = string | string[];
/** Fully resolved system presets for one printer (public/bambu-profiles/<printer>.json). */
export type BambuProfiles = { machine: Record<string, BambuProfileValue>; process: Record<string, BambuProfileValue>; filaments: Record<string, Record<string, BambuProfileValue>> };
export type BambuProjectOptions = { title: string; printer: BambuPrinter; bed: { width: number; depth: number; height: number }; profiles?: BambuProfiles;
  /** Print settings chosen in the slicer panel (Bambu process keys), written over the system preset and marked as changed. */
  processOverrides?: Record<string, BambuProfileValue> };

/** Loads the resolved presets so the project carries a complete config (Bambu Studio's command line refuses partial ones). */
export async function loadBambuProfiles(printerId: string | undefined, basePath = "") {
  const id = printerId && /^bambu-lab-[a-z0-9-]+$/.test(printerId) ? printerId : "bambu-lab-x1-carbon";
  for (const candidate of [id, "bambu-lab-x1-carbon"]) {
    try {
      const response = await fetch(`${basePath}/bambu-profiles/${candidate}.json`);
      if (response.ok) return (await response.json()) as BambuProfiles;
    } catch { /* try the fallback */ }
  }
  return undefined;
}

const APP = "BambuStudio-02.00.02.01";
const CORE = "http://schemas.microsoft.com/3dmanufacturing/core/2015/02";
const PROD = "http://schemas.microsoft.com/3dmanufacturing/production/2015/06";
const BBS = "http://schemas.bambulab.com/package/2021";
const REL_MODEL = "http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel";
const DEFAULT_COLOR = "#8A98A6";

const esc = (v: string) => v.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "");
const num = (v: number) => { const r = Math.round(v * 1e6) / 1e6; return Object.is(r, -0) ? "0" : String(r); };
const hex = (c?: string) => (c && /^#[0-9a-f]{6}$/i.test(c) ? c.toUpperCase() : DEFAULT_COLOR);
const uuid = (a: number, b: number) => `${a.toString(16).padStart(8, "0")}-${b.toString(16).padStart(4, "0")}-4000-8000-000000000000`;

export function bambuPlateOrigin(index: number, count: number, width: number, depth: number) {
  const value = Math.sqrt(count);
  const rounded = Math.round(value);
  const cols = value > rounded ? rounded + 1 : rounded;
  return { x: (index % cols) * width * 1.2, y: -Math.floor(index / cols) * depth * 1.2 };
}

/** Filament slots: one per unique material + colour, in order of first use. */
export function bambuFilamentSlots(plates: readonly BambuPlate[], printer: BambuPrinter) {
  const slots: { key: string; material: ReturnType<typeof bambuMaterial>; color: string; name?: string; preset: string }[] = [];
  const slotOf = (body: BambuBody) => {
    const material = bambuMaterial(body.filament?.material ?? DEFAULT_BAMBU_MATERIAL);
    const color = hex(body.color);
    const key = `${material.id}|${color}`;
    let index = slots.findIndex((s) => s.key === key);
    if (index < 0) {
      const named = body.filament?.name && material.colors.find((c) => c.n === body.filament?.name && c.h.toUpperCase() === color) ? body.filament.name : undefined;
      slots.push({ key, material, color, name: named, preset: bambuFilamentPreset(material, printer) });
      index = slots.length - 1;
    }
    return index + 1;
  };
  const assignment = plates.map((plate) => plate.bodies.map(slotOf));
  return { slots, assignment };
}

function projectSettings(slots: ReturnType<typeof bambuFilamentSlots>["slots"], options: BambuProjectOptions) {
  const { printer, bed } = options;
  const printerPreset = `${printer.model} 0.4 nozzle`;
  const printPreset = `0.20mm Standard @BBL ${printer.process}`;
  const filaments = slots.length ? slots : [{ material: bambuMaterial(DEFAULT_BAMBU_MATERIAL), color: DEFAULT_COLOR, preset: bambuFilamentPreset(bambuMaterial(DEFAULT_BAMBU_MATERIAL), printer) }];
  const config: Record<string, string | string[]> = {
    from: "project",
    name: "project_settings",
    version: APP.slice(12),
    printer_model: printer.model,
    printer_settings_id: printerPreset,
    printer_variant: "0.4",
    print_settings_id: printPreset,
    print_compatible_printers: [],
    default_print_profile: printPreset,
    nozzle_diameter: ["0.4"],
    printable_area: ["0x0", `${bed.width}x0`, `${bed.width}x${bed.depth}`, `0x${bed.depth}`],
    printable_height: String(bed.height),
    filament_settings_id: filaments.map((f) => f.preset),
    filament_type: filaments.map((f) => f.material.type),
    filament_ids: filaments.map((f) => f.material.id),
    filament_colour: filaments.map((f) => f.color),
    filament_vendor: filaments.map(() => "Bambu Lab"),
    filament_map: filaments.map(() => "1"),
    default_filament_profile: [filaments[0].preset],
    extruder_colour: [filaments[0].color],
    // Order: print, each filament, printer. A non-empty entry makes the slicer take every other key from that system preset.
    inherits_group: [printPreset, ...filaments.map((f) => f.preset), printerPreset],
    different_settings_to_system: [["print_settings_id", ...Object.keys(options.processOverrides ?? {})].join(";"), ...filaments.map(() => "filament_colour"), "printer_settings_id"],
  };
  const profiles = options.profiles;
  const changed = options.processOverrides ?? {};
  if (!profiles) return JSON.stringify({ ...config, ...changed }, null, 4);
  // Full config: machine + process values, then each slot's filament values as per-slot arrays.
  const full: Record<string, BambuProfileValue> = { ...profiles.machine, ...profiles.process };
  const resolved = filaments.map((f) => profiles.filaments[f.preset] ?? profiles.filaments[`Bambu PLA Basic @BBL ${printer.code}`] ?? profiles.filaments["Bambu PLA Basic @BBL X1C"] ?? {});
  const keys = new Set(resolved.flatMap((r) => Object.keys(r)));
  for (const key of keys) {
    if (key === "filament_id") continue;
    full[key] = resolved.flatMap((r) => { const v = r[key]; return v === undefined ? [""] : Array.isArray(v) ? v : [v]; });
  }
  // Bambu's "-1" (auto) is out of OrcaSlicer's range and aborts its import; both default sensibly without it.
  delete full.tree_support_wall_count;
  full.filament_ids = resolved.map((r, i) => (typeof r.filament_id === "string" ? r.filament_id : filaments[i].material.id));
  const { printable_area: _area, printable_height: _height, ...identity } = config;
  // Textured PEI suits every Bambu material; the cool plate rejects PETG, ABS and others.
  // Imported per-slot arrays (one filament preset) are stretched to the project's slot count.
  const merged: Record<string, BambuProfileValue> = { ...full };
  for (const [key, value] of Object.entries(changed)) {
    const base = full[key];
    merged[key] = Array.isArray(value) && Array.isArray(base) && base.length > 1 && value.length !== base.length ? base.map((_, i) => value[i] ?? value[value.length - 1]) : value;
  }
  return JSON.stringify({ ...merged, ...identity, curr_bed_type: "Textured PEI Plate" }, null, 4);
}

function packageFiles(plates: readonly BambuPlate[], options: BambuProjectOptions) {
  const { slots, assignment } = bambuFilamentSlots(plates, options.printer);
  const files: Record<string, Uint8Array> = {};
  const wrappers: string[] = [];
  const items: string[] = [];
  const rels: string[] = [];
  const objectSettings: string[] = [];
  const plateSettings: string[] = [];
  const assemble: string[] = [];
  const count = Math.max(1, plates.length);
  let objectNumber = 0;
  let identify = 100;
  const { width, depth } = options.bed;

  plates.forEach((plate, plateIndex) => {
    const origin = bambuPlateOrigin(plateIndex, count, width, depth);
    const instances: string[] = [];
    plate.bodies.forEach((body, bodyIndex) => {
      const welded = weldMeshVertices(body);
      if (welded.faces.length === 0) return;
      objectNumber += 1;
      const n = objectNumber;
      const wrapperId = 1000 + n;
      // Plate-local, Z-up, with the plate's front-left corner at 0,0 (PrintCaddy's plate centre is its origin).
      const pts = welded.vertices.map((v) => { const [x, y, z] = layerlingToZUp(v); return [x + width / 2, y + depth / 2, z] as const; });
      const minZ = pts.reduce((m, p) => Math.min(m, p[2]), Infinity);
      // Bambu centres each object on its own origin; the build transform carries the placement.
      let x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
      for (const [x, y] of pts) { x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
      const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
      const verts = pts.map(([x, y, z]) => `<vertex x="${num(x - cx)}" y="${num(y - cy)}" z="${num(z - minZ)}"/>`).join("");
      const tris = welded.faces.map(([a, b, c]) => `<triangle v1="${a}" v2="${b}" v3="${c}"/>`).join("");
      const path = `3D/Objects/object_${n}.model`;
      files[path] = strToU8(`<?xml version="1.0" encoding="UTF-8"?>
<model unit="millimeter" xml:lang="en-US" xmlns="${CORE}" xmlns:BambuStudio="${BBS}" xmlns:p="${PROD}" requiredextensions="p">
 <metadata name="BambuStudio:3mfVersion">1</metadata>
 <resources>
  <object id="1" p:UUID="${uuid(n, 1)}" type="model"><mesh><vertices>${verts}</vertices><triangles>${tris}</triangles></mesh></object>
 </resources>
 <build/>
</model>
`);
      rels.push(` <Relationship Target="/${path}" Id="rel-${n}" Type="${REL_MODEL}"/>`);
      wrappers.push(`  <object id="${wrapperId}" p:UUID="${uuid(n, 2)}" type="model">\n   <components>\n    <component p:path="/${path}" objectid="1" p:UUID="${uuid(n, 3)}" transform="1 0 0 0 1 0 0 0 1 0 0 0"/>\n   </components>\n  </object>`);
      const transform = `1 0 0 0 1 0 0 0 1 ${num(origin.x + cx)} ${num(origin.y + cy)} ${num(Math.max(0, minZ))}`;
      items.push(`  <item objectid="${wrapperId}" p:UUID="${uuid(n, 4)}" transform="${transform}" printable="1"/>`);
      const extruder = assignment[plateIndex][bodyIndex];
      const name = esc(body.name || `Body ${n}`);
      objectSettings.push(`  <object id="${wrapperId}">
    <metadata key="name" value="${name}"/>
    <metadata key="extruder" value="${extruder}"/>
    <metadata face_count="${welded.faces.length}"/>
    <part id="1" subtype="normal_part">
      <metadata key="name" value="${name}"/>
      <metadata key="matrix" value="1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1"/>
      <metadata key="extruder" value="${extruder}"/>
      <mesh_stat face_count="${welded.faces.length}" edges_fixed="0" degenerate_facets="0" facets_removed="0" facets_reversed="0" backwards_edges="0"/>
    </part>
  </object>`);
      identify += 1;
      instances.push(`    <model_instance>\n      <metadata key="object_id" value="${wrapperId}"/>\n      <metadata key="instance_id" value="0"/>\n      <metadata key="identify_id" value="${identify}"/>\n    </model_instance>`);
      assemble.push(`   <assemble_item object_id="${wrapperId}" instance_id="0" transform="${transform}" offset="0 0 0" />`);
    });
    plateSettings.push(`  <plate>
    <metadata key="plater_id" value="${plateIndex + 1}"/>
    <metadata key="plater_name" value="${esc(`PrintCaddy plate ${plate.number}`)}"/>
    <metadata key="locked" value="false"/>
${instances.join("\n")}
  </plate>`);
  });
  if (!objectNumber) throw new Error("Bambu Studio export needs at least one body with triangles");

  const today = new Date().toISOString().slice(0, 10);
  files["3D/3dmodel.model"] = strToU8(`<?xml version="1.0" encoding="UTF-8"?>
<model unit="millimeter" xml:lang="en-US" xmlns="${CORE}" xmlns:BambuStudio="${BBS}" xmlns:p="${PROD}" requiredextensions="p">
 <metadata name="Application">${APP}</metadata>
 <metadata name="BambuStudio:3mfVersion">1</metadata>
 <metadata name="CreationDate">${today}</metadata>
 <metadata name="Designer">PrintCaddy</metadata>
 <metadata name="ModificationDate">${today}</metadata>
 <metadata name="Title">${esc(options.title)}</metadata>
 <resources>
${wrappers.join("\n")}
 </resources>
 <build p:UUID="${uuid(0, 5)}">
${items.join("\n")}
 </build>
</model>
`);
  files["3D/_rels/3dmodel.model.rels"] = strToU8(`<?xml version="1.0" encoding="UTF-8"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n${rels.join("\n")}\n</Relationships>`);
  files["Metadata/model_settings.config"] = strToU8(`<?xml version="1.0" encoding="UTF-8"?>\n<config>\n${objectSettings.join("\n")}\n${plateSettings.join("\n")}\n  <assemble>\n${assemble.join("\n")}\n  </assemble>\n</config>\n`);
  files["Metadata/project_settings.config"] = strToU8(projectSettings(slots, options));
  files["Metadata/slice_info.config"] = strToU8(`<?xml version="1.0" encoding="UTF-8"?>\n<config>\n  <header>\n    <header_item key="X-BBL-Client-Type" value="slicer"/>\n    <header_item key="X-BBL-Client-Version" value="${APP.slice(12)}"/>\n  </header>\n</config>`);
  files["_rels/.rels"] = strToU8(`<?xml version="1.0" encoding="UTF-8"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n <Relationship Target="/3D/3dmodel.model" Id="rel-1" Type="${REL_MODEL}"/>\n</Relationships>`);
  files["[Content_Types].xml"] = strToU8(`<?xml version="1.0" encoding="UTF-8"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">\n <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>\n <Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/>\n <Default Extension="png" ContentType="image/png"/>\n <Default Extension="gcode" ContentType="text/x.gcode"/>\n</Types>`);
  return { files, slots };
}

export async function exportBambuProject(plates: readonly BambuPlate[], options: BambuProjectOptions) {
  const { files, slots } = packageFiles(plates, options);
  const bytes = await new Promise<Uint8Array>((resolve) => {
    try { zip(files, { level: 6 }, (error, data) => (error ? resolve(zipSync(files, { level: 6 })) : resolve(data))); } catch { resolve(zipSync(files, { level: 6 })); }
  });
  return { bytes, slots };
}
export { packageFiles as bambuProjectFiles };

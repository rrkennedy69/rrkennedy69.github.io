/** Full screen: hide every piece of UI except the 3D view, show a floating exit button, Esc exits. */
const HIDDEN_ATTR = "data-pc-fs-hidden";
let active = false;
let exitButton: HTMLButtonElement | null = null;
const listeners = new Set<(on: boolean) => void>();

export function isFullScreenMode() { return active; }
export function subscribeFullScreenMode(fn: (on: boolean) => void) { listeners.add(fn); return () => { listeners.delete(fn); }; }
function emit() { listeners.forEach((fn) => fn(active)); }

function onKey(event: KeyboardEvent) { if (event.key === "Escape" && active) { event.preventDefault(); event.stopPropagation(); exitFullScreenMode(); } }
function onNativeChange() { if (active && !document.fullscreenElement && nativeWasUsed) exitFullScreenMode(); }
let nativeWasUsed = false;

function hideAroundStage() {
  const stage = document.querySelector<HTMLElement>(".workplane-stage");
  if (!stage) return;
  let node: HTMLElement | null = stage;
  while (node && node !== document.body) {
    const parent: HTMLElement | null = node.parentElement;
    if (!parent) break;
    for (const sib of Array.from(parent.children) as HTMLElement[]) {
      if (sib !== node && !sib.classList.contains("pc-fullscreen-exit") && !["SCRIPT", "STYLE", "LINK"].includes(sib.tagName)) sib.setAttribute(HIDDEN_ATTR, "");
    }
    node = parent;
  }
}

export function enterFullScreenMode() {
  if (active || typeof document === "undefined") return;
  active = true;
  document.documentElement.classList.add("pc-fullscreen");
  hideAroundStage();
  exitButton = document.createElement("button");
  exitButton.type = "button";
  exitButton.className = "pc-fullscreen-exit";
  exitButton.setAttribute("data-testid", "exit-fullscreen");
  exitButton.textContent = "✕ Exit full screen";
  exitButton.addEventListener("click", () => exitFullScreenMode());
  document.body.appendChild(exitButton);
  window.addEventListener("keydown", onKey, true);
  document.addEventListener("fullscreenchange", onNativeChange);
  const root = document.documentElement as HTMLElement & { webkitRequestFullscreen?: () => void };
  nativeWasUsed = false;
  try {
    if (root.requestFullscreen) { root.requestFullscreen().then(() => { nativeWasUsed = true; }).catch(() => {}); }
    else if (root.webkitRequestFullscreen) { root.webkitRequestFullscreen(); nativeWasUsed = true; }
  } catch { /* iPad Safari: UI-only full screen */ }
  window.dispatchEvent(new Event("resize"));
  emit();
}

export function exitFullScreenMode() {
  if (!active) return;
  active = false;
  document.documentElement.classList.remove("pc-fullscreen");
  document.querySelectorAll(`[${HIDDEN_ATTR}]`).forEach((el) => el.removeAttribute(HIDDEN_ATTR));
  exitButton?.remove(); exitButton = null;
  window.removeEventListener("keydown", onKey, true);
  document.removeEventListener("fullscreenchange", onNativeChange);
  const doc = document as Document & { webkitExitFullscreen?: () => void; webkitFullscreenElement?: Element };
  try {
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    else if (doc.webkitFullscreenElement && doc.webkitExitFullscreen) doc.webkitExitFullscreen();
  } catch { /* ignore */ }
  window.dispatchEvent(new Event("resize"));
  emit();
}

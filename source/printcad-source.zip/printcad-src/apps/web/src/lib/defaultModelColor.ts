/** Every new body starts slate grey (#8a98a6). Bodies still carrying the old tan default are shown in it too. */
export const DEFAULT_MODEL_COLOR = "#8a98a6";
export const LEGACY_DEFAULT_MODEL_COLOR = "#f2caa0";
/** Old default tan becomes the new default; any colour the user picked stays. */
export function migrateDefaultModelColor<T extends string | undefined>(color: T): T {
  return (typeof color === "string" && color.toLowerCase() === LEGACY_DEFAULT_MODEL_COLOR ? DEFAULT_MODEL_COLOR : color) as T;
}

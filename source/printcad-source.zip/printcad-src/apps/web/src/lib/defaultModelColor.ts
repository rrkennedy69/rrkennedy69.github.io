/** Every new body starts tan (the palette's #f2caa0): light and warm, so its detail reads well. */
export const DEFAULT_MODEL_COLOR = "#f2caa0";

import { useSyncExternalStore } from "react";

/** Grid on/off (left rail): hides the grid lines, the build plate stays. On by default. */
export const GRID_TOGGLE_STORAGE_KEY = "printcad.gridOn.v1";
const listeners = new Set<() => void>();
let cached: boolean | null = null;

export function gridOn(): boolean {
  if (cached !== null) return cached;
  try { cached = typeof window === "undefined" || window.localStorage.getItem(GRID_TOGGLE_STORAGE_KEY) !== "0"; } catch { cached = true; }
  return cached;
}

export function setGridOn(on: boolean) {
  cached = on;
  try { window.localStorage.setItem(GRID_TOGGLE_STORAGE_KEY, on ? "1" : "0"); } catch { /* private mode */ }
  listeners.forEach((listener) => listener());
}

export function useGridOn() {
  return useSyncExternalStore((l) => { listeners.add(l); return () => listeners.delete(l); }, gridOn, () => true);
}

/**
 * Inside the PrintCaddy iPad app (Capacitor shell) the page is not "a browser": texts that talk about the browser,
 * Chrome/Edge, Safari or installing the site as an app are reworded or dropped there. The website is unchanged.
 */
let cached: boolean | null = null;
export function isNativeApp(): boolean {
  if (cached !== null) return cached;
  if (typeof window === "undefined") return false;
  const cap = (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
  cached = !!(cap && cap.isNativePlatform && cap.isNativePlatform());
  return cached;
}

/** English rewording for the app. Other languages keep their text except for the keys emptied below. */
const APP_TEXT: Record<string, string> = {
  "welcome.lead": "PrintCaddy is CAD for 3D printing on your iPad - as easy to use as Tinkercad, but a step towards Fusion 360. Free, no account - and what you build stays on this iPad.",
  "welcome.moreSaveBody": "export a design and choose where it goes - Files, iCloud Drive or another app.",
  "font.systemUnsupported": "Choose the font file (.ttf, .otf or .woff) from Files, or drag it here.",
  "font.systemNeedsHttps": "Choose the font file from Files, or drag it here.",
  "font.systemDenied": "Choose the font file from Files, or drag it here.",
  "storageNotice.line": "These designs are stored on this iPad. Use “{button}” above to save them all in one file, for example to iCloud Drive.",
  "tabs.closeRefused": "",
  "workspace.confirmTabCloseHint": "",
  "workspace.stlAsDownloadHint": "",
  "edge.errorWorkerFailed": "The CAD engine could not start. Usually PrintCaddy was just updated: close and reopen the app.",
};
/** Messages that only make sense in a browser; empty in the app (any language). */
const DROP = new Set(["installHint.chromium", "installHint.safariMac", "installHint.ios", "tabs.closeRefused", "workspace.confirmTabCloseHint", "workspace.stlAsDownloadHint"]);

export function appWording(language: string, key: string, text: string): string {
  if (DROP.has(key)) return "";
  if (language !== "en") return text;
  if (key in APP_TEXT) return APP_TEXT[key];
  return text
    .replace(/\s*(?:In|With|Only) Chrome (?:and|or) Edge[^.]*\.\s*(?:Other browsers[^.]*\.)?/g, " ")
    .replace(/\s*\(Chrome or Edge\)/g, "")
    .replace(/in your browser's own question/g, "a question")
    .replace(/\b(?:in|on) (?:this|your|the local) browser\b/g, "on this iPad")
    .replace(/\bof this browser\b/g, "on this iPad")
    .replace(/\binto a browser\b/g, "into PrintCaddy")
    .replace(/\bin this browser or another\b/g, "on this iPad or another device")
    .replace(/\banother browser\b/g, "another device")
    .replace(/\bthis browser\b/g, "this app")
    .replace(/\byour browser\b/g, "PrintCaddy")
    .replace(/\b[Tt]he browser\b/g, "PrintCaddy")
    .replace(/\bupdate your browser\b/gi, "update the app")
    .replace(/\breload the page\b/gi, "reopen the app")
    .replace(/\bBrowser\b/g, "This iPad")
    .replace(/\s{2,}/g, " ").trim();
}

import { meshAabb } from "./editorMeshCore";
import { collideMove } from "./collision";
import type { WorkplaneShape } from "@/types/layerling";

/**
 * Gravity with a feel (Manage → Gravity): a released part flies a short ballistic arc with the
 * speed of the drag, falls under g, bounces a little and slides to a stop. Only the final rest is
 * written to the design (one undo step); the flight is played back on the meshes alone.
 * There is no wall at the plate edge: a hard flick tosses a part off to the side, where it lands on
 * the same floor (height 0) and stays in the design, selectable.
 */
export const G = 9810; // mm/s², real gravity: at model scale a fall is already quick
export const RESTITUTION = 0.25;
export const MAX_BOUNCES = 2;
export const MIN_BOUNCE_DROP = 2; // mm
const FRICTION = 0.45; // sliding: decelerates by FRICTION * G
const AIR_KICK = 0.22; // upward speed per unit of throw speed, so a throw visibly arcs
const MIN_THROW = 40; // mm/s: slower releases just drop
const DT = 1 / 240;
const MAX_T = 4;

export type Vec = { x: number; y: number; z: number };
export type PhysicsFrame = { t: number; x: number; y: number; z: number }; // offset from the rest position
export type PhysicsResult = { shapes: WorkplaneShape[]; frames: PhysicsFrame[] };

type Box = ReturnType<typeof meshAabb>;

function supportUnder(box: Box, others: Box[]) {
  let rest = 0;
  for (const ob of others) {
    if (ob.maxY > box.minY + 1e-6) continue;
    if (box.minX < ob.maxX && box.maxX > ob.minX && box.minZ < ob.maxZ && box.maxZ > ob.minZ && ob.maxY > rest) rest = ob.maxY;
  }
  return rest;
}

/** The throw speed allowed: a gentle flick only nudges, a hard one reaches ~1.5 plate widths. */
export function capThrow(v: { x: number; z: number }, plateWidth: number) {
  const speed = Math.hypot(v.x, v.z);
  if (speed < MIN_THROW) return { x: 0, z: 0 };
  // Range on the floor ≈ air time + slide; keep the slide alone under 1.5 plate widths.
  const max = Math.sqrt(2 * FRICTION * G * 1.5 * Math.max(50, plateWidth)) * 0.8;
  const k = speed > max ? max / speed : 1;
  return { x: v.x * k, z: v.z * k };
}

export function simulateThrow(
  shapes: readonly WorkplaneShape[],
  ids: readonly string[],
  velocity: Vec,
  options: { collision: boolean; plateWidth: number },
): PhysicsResult {
  const moving = new Set(ids);
  const movers = shapes.filter((s) => moving.has(s.id) && !s.locked);
  if (!movers.length) return { shapes: shapes as WorkplaneShape[], frames: [] };
  const others = shapes.filter((s) => !moving.has(s.id) && !s.hole && !s.hidden);
  const otherBoxes = others.map((s) => meshAabb(s));
  const boxes = movers.map((s) => meshAabb(s));
  const set: Box = {
    minX: Math.min(...boxes.map((b) => b.minX)), maxX: Math.max(...boxes.map((b) => b.maxX)),
    minY: Math.min(...boxes.map((b) => b.minY)), maxY: Math.max(...boxes.map((b) => b.maxY)),
    minZ: Math.min(...boxes.map((b) => b.minZ)), maxZ: Math.max(...boxes.map((b) => b.maxZ)),
  } as Box;
  // The whole selection moves as one box: a proxy shape for the collision test.
  const lead = movers[0];
  const thrown = capThrow(velocity, options.plateWidth);
  let vx = thrown.x;
  let vz = thrown.z;
  let vy = Math.max(velocity.y, 0) + Math.hypot(vx, vz) * AIR_KICK;
  let px = 0, py = 0, pz = 0; // displacement of the set
  let bounces = 0;
  let grounded = false;
  let peak = set.minY;
  const path: Array<{ t: number; x: number; y: number; z: number }> = [{ t: 0, x: 0, y: 0, z: 0 }];
  const at = (dx: number, dy: number, dz: number): Box => ({ ...set, minX: set.minX + dx, maxX: set.maxX + dx, minY: set.minY + dy, maxY: set.maxY + dy, minZ: set.minZ + dz, maxZ: set.maxZ + dz } as Box);
  const proxy = (dx: number, dy: number, dz: number): WorkplaneShape => ({ ...lead, x: lead.x + dx, z: lead.z + dz, elevation: (lead.elevation ?? 0) + dy });
  const proxyShapes = [...others, ...movers.slice(1)];
  let t = 0;
  for (; t < MAX_T; t += DT) {
    if (grounded) {
      const speed = Math.hypot(vx, vz);
      const dec = FRICTION * G * DT;
      if (speed <= dec) { vx = 0; vz = 0; } else { vx -= (vx / speed) * dec; vz -= (vz / speed) * dec; }
    } else {
      vy -= G * DT;
    }
    let dx = vx * DT, dz = vz * DT;
    if (options.collision && (dx || dz)) {
      const before = proxy(px, py, pz);
      const after = collideMove(proxyShapes, before, proxy(px + dx, py, pz + dz), new Set(movers.slice(1).map((s) => s.id)));
      const ax = after.x - before.x, az = after.z - before.z;
      if (Math.abs(ax - dx) > 1e-9) vx = 0; // hit a side: stop that way, then drop
      if (Math.abs(az - dz) > 1e-9) vz = 0;
      dx = ax; dz = az;
    }
    px += dx; pz += dz;
    const floor = supportUnder(at(px, py, pz), otherBoxes);
    if (!grounded) {
      py += vy * DT;
      peak = Math.max(peak, set.minY + py);
      if (set.minY + py <= floor) {
        py = floor - set.minY;
        const drop = peak - floor;
        if (bounces < MAX_BOUNCES && drop >= MIN_BOUNCE_DROP && vy < 0) {
          vy = -vy * RESTITUTION;
          bounces += 1;
          peak = floor;
        } else {
          vy = 0;
          grounded = true;
        }
      }
    } else if (set.minY + py > floor + 1e-6) {
      grounded = false; // slid off an edge: fall again
      peak = set.minY + py;
    }
    path.push({ t: t + DT, x: px, y: py, z: pz });
    if (grounded && vx === 0 && vz === 0) break;
  }
  const end = path[path.length - 1];
  const next = shapes.map((s) => moving.has(s.id) && !s.locked ? { ...s, x: s.x + end.x, z: s.z + end.z, elevation: (s.elevation ?? 0) + end.y } : s);
  // Thin the path to ~60 frames a second for playback, offsets measured from the rest.
  const frames: PhysicsFrame[] = [];
  for (let i = 0; i < path.length; i += 4) frames.push({ t: path[i].t, x: path[i].x - end.x, y: path[i].y - end.y, z: path[i].z - end.z });
  frames.push({ t: end.t, x: 0, y: 0, z: 0 });
  return { shapes: next, frames };
}

/** Recent drag samples, to read the release velocity (last ~100 ms). */
export type DragSample = { t: number; x: number; y: number; z: number };
export function releaseVelocity(samples: readonly DragSample[], now = performance.now()): Vec {
  const recent = samples.filter((s) => now - s.t <= 120);
  if (recent.length < 2) return { x: 0, y: 0, z: 0 };
  const a = recent[0], b = recent[recent.length - 1];
  const dt = Math.max(16, b.t - a.t) / 1000;
  return { x: (b.x - a.x) / dt, y: (b.y - a.y) / dt, z: (b.z - a.z) / dt };
}

// --- playback: the viewport reads this every frame -------------------------------------------
type Playback = { ids: Set<string>; frames: PhysicsFrame[]; start: number };
let playback: Playback | null = null;

export function playPhysics(ids: readonly string[], frames: PhysicsFrame[]) {
  playback = frames.length > 1 ? { ids: new Set(ids), frames, start: performance.now() } : null;
}

export function prefersReducedMotion() {
  try { return window.matchMedia("(prefers-reduced-motion: reduce)").matches; } catch { return false; }
}

/** The offset of `id` from its stored position right now, or null when it is at rest. */
export function physicsOffset(now: number): { ids: Set<string>; x: number; y: number; z: number } | null {
  if (!playback) return null;
  const t = (now - playback.start) / 1000;
  const frames = playback.frames;
  if (t >= frames[frames.length - 1].t) { playback = null; return null; }
  let i = 1;
  while (i < frames.length - 1 && frames[i].t < t) i += 1;
  const a = frames[i - 1], b = frames[i];
  const k = b.t > a.t ? (t - a.t) / (b.t - a.t) : 1;
  return { ids: playback.ids, x: a.x + (b.x - a.x) * k, y: a.y + (b.y - a.y) * k, z: a.z + (b.z - a.z) * k };
}

export function physicsPlaying() { return playback !== null; }

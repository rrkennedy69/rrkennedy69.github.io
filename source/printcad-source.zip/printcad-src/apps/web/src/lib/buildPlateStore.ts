/**
 * Extra build plates of the same printer model, set in a row to the right of the main plate (Manage → Add plate).
 * Each entry is a slot: slot k sits k × (plate width + gap) to the right of plate 1. Removing a plate leaves
 * the others where they are, so the objects on them stay put. Kept per design in the browser and in the `.lyl` file.
 */
export const PLATE_GAP_MM = 20;
const PREFIX = "printcaddy.buildPlates.";
export const BUILD_PLATES_EVENT = "printcaddy-build-plates";
export const ADD_PLATE_EVENT = "printcaddy-add-plate";

export function normalizeBuildPlates(value: unknown): number[] | null {
  if (!Array.isArray(value)) return null;
  const slots = [...new Set(value.filter((v): v is number => Number.isInteger(v) && v > 0 && v < 1000))].sort((a, b) => a - b);
  return slots.length ? slots : null;
}

export function readBuildPlates(projectId: string | null | undefined): number[] {
  if (!projectId) return [];
  try {
    const s = window.localStorage.getItem(PREFIX + projectId);
    return (s ? normalizeBuildPlates(JSON.parse(s)) : null) ?? [];
  } catch { return []; }
}

export function writeBuildPlates(projectId: string | null | undefined, slots: readonly number[] | null) {
  if (!projectId) return;
  try {
    const kept = normalizeBuildPlates(slots ?? null);
    if (kept) window.localStorage.setItem(PREFIX + projectId, JSON.stringify(kept));
    else window.localStorage.removeItem(PREFIX + projectId);
  } catch { /* session only */ }
  try { window.dispatchEvent(new CustomEvent(BUILD_PLATES_EVENT, { detail: { projectId } })); } catch { /* ignore */ }
}

/** All plates, in order: plate 1 is slot 0. `offsetX` is the plate centre's X in millimetres (scene X). */
export function allPlates(slots: readonly number[], width: number) {
  return [0, ...slots].map((slot, i) => ({ slot, number: i + 1, label: `Plate ${i + 1}`, offsetX: slot * (width + PLATE_GAP_MM) }));
}

/** Which plate a point (scene X, mm) is over, nearest centre wins; plate 1 when there are no extra plates. */
export function plateIndexForX(x: number, slots: readonly number[], width: number) {
  const plates = allPlates(slots, width);
  let best = 0; let dist = Infinity;
  plates.forEach((p, i) => { const d = Math.abs(x - p.offsetX); if (d < dist) { dist = d; best = i; } });
  return best;
}

/** Locked plates (slot numbers, plate 1 is slot 0): their objects can't be selected or edited. Kept like the plates. */
const LOCK_PREFIX = "printcaddy.lockedPlates.";
export function normalizeLockedPlates(value: unknown): number[] | null {
  if (!Array.isArray(value)) return null;
  const slots = [...new Set(value.filter((v): v is number => Number.isInteger(v) && v >= 0 && v < 1000))].sort((a, b) => a - b);
  return slots.length ? slots : null;
}
export function readLockedPlates(projectId: string | null | undefined): number[] {
  if (!projectId) return [];
  try { const s = window.localStorage.getItem(LOCK_PREFIX + projectId); return (s ? normalizeLockedPlates(JSON.parse(s)) : null) ?? []; } catch { return []; }
}
export function writeLockedPlates(projectId: string | null | undefined, slots: readonly number[] | null) {
  if (!projectId) return;
  try {
    const kept = normalizeLockedPlates(slots ?? null);
    if (kept) window.localStorage.setItem(LOCK_PREFIX + projectId, JSON.stringify(kept));
    else window.localStorage.removeItem(LOCK_PREFIX + projectId);
  } catch { /* session only */ }
  try { window.dispatchEvent(new CustomEvent(BUILD_PLATES_EVENT, { detail: { projectId } })); } catch { /* ignore */ }
}

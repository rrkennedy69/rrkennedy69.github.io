/**
 * Extra build plates of the same printer model, set in a row to the right of the main plate (Manage → Add plate).
 * Each entry is a slot: slot k sits k × (plate width + gap) to the right of plate 1. Removing a plate leaves
 * the others where they are, so the objects on them stay put. Kept per design in the browser and in the `.lyl` file.
 */
/** Gap between plates: room for the X / lock tiles and the number label without touching the next plate. */
export const PLATE_GAP_MM = 64;
/** The gap of the first (single-row, 20 mm) layout, for moving objects in older saves. */
export const LEGACY_PLATE_GAP_MM = 20;
/** Plates per row: plates 1–3 in the first row, plate 4 below plate 1 (toward the viewer, +Z), and so on. */
export const PLATES_PER_ROW = 3;
const PREFIX = "printcaddy.buildPlates.";
export const BUILD_PLATES_EVENT = "printcaddy-build-plates";
export const ADD_PLATE_EVENT = "printcaddy-add-plate";

export function normalizeBuildPlates(value: unknown): number[] | null {
  if (!Array.isArray(value)) return null;
  const slots = [...new Set(value.filter((v): v is number => Number.isInteger(v) && v > 0 && v < 1000))].sort((a, b) => a - b);
  return slots.length ? slots : null;
}

export function readBuildPlates(projectId: string | null | undefined): number[] {
  if (!projectId) return [];
  try {
    const s = window.localStorage.getItem(PREFIX + projectId);
    return (s ? normalizeBuildPlates(JSON.parse(s)) : null) ?? [];
  } catch { return []; }
}

export function writeBuildPlates(projectId: string | null | undefined, slots: readonly number[] | null) {
  if (!projectId) return;
  try {
    const kept = normalizeBuildPlates(slots ?? null);
    const had = window.localStorage.getItem(PREFIX + projectId);
    if (kept) window.localStorage.setItem(PREFIX + projectId, JSON.stringify(kept));
    else window.localStorage.removeItem(PREFIX + projectId);
    if (!had || !kept) writePlateLayout(projectId);
  } catch { /* session only */ }
  try { window.dispatchEvent(new CustomEvent(BUILD_PLATES_EVENT, { detail: { projectId } })); } catch { /* ignore */ }
}

/** All plates, in order: plate 1 is slot 0. `offsetX` is the plate centre's X in millimetres (scene X). */
export function plateOffset(slot: number, width: number, depth: number = width) {
  return { offsetX: (slot % PLATES_PER_ROW) * (width + PLATE_GAP_MM), offsetZ: Math.floor(slot / PLATES_PER_ROW) * (depth + PLATE_GAP_MM) };
}
export function allPlates(slots: readonly number[], width: number, depth: number = width) {
  return [0, ...slots].map((slot, i) => ({ slot, number: i + 1, label: `Plate ${i + 1}`, ...plateOffset(slot, width, depth) }));
}
/** Where a slot sat in the old single-row 20 mm layout. */
export function legacyPlateOffsetX(slot: number, width: number) { return slot * (width + LEGACY_PLATE_GAP_MM); }

/** Per design: "2" once its objects use the grid layout (older designs get their objects moved once). */
const LAYOUT_PREFIX = "printcaddy.plateLayout.";
export const PLATE_LAYOUT_VERSION = 2;
export function readPlateLayout(projectId: string | null | undefined): number {
  if (!projectId) return PLATE_LAYOUT_VERSION;
  try { return Number(window.localStorage.getItem(LAYOUT_PREFIX + projectId)) || 1; } catch { return PLATE_LAYOUT_VERSION; }
}
export function writePlateLayout(projectId: string | null | undefined, version: number = PLATE_LAYOUT_VERSION) {
  if (!projectId) return;
  try { window.localStorage.setItem(LAYOUT_PREFIX + projectId, String(version)); } catch { /* session only */ }
}

/** Which plate a point (scene X, mm) is over, nearest centre wins; plate 1 when there are no extra plates. */
export function plateIndexForX(x: number, slots: readonly number[], width: number, z = 0, depth: number = width) {
  const plates = allPlates(slots, width, depth);
  let best = 0; let dist = Infinity;
  plates.forEach((p, i) => { const d = Math.hypot(x - p.offsetX, z - p.offsetZ); if (d < dist) { dist = d; best = i; } });
  return best;
}

/** Locked plates (slot numbers, plate 1 is slot 0): their objects can't be selected or edited. Kept like the plates. */
const LOCK_PREFIX = "printcaddy.lockedPlates.";
export function normalizeLockedPlates(value: unknown): number[] | null {
  if (!Array.isArray(value)) return null;
  const slots = [...new Set(value.filter((v): v is number => Number.isInteger(v) && v >= 0 && v < 1000))].sort((a, b) => a - b);
  return slots.length ? slots : null;
}
export function readLockedPlates(projectId: string | null | undefined): number[] {
  if (!projectId) return [];
  try { const s = window.localStorage.getItem(LOCK_PREFIX + projectId); return (s ? normalizeLockedPlates(JSON.parse(s)) : null) ?? []; } catch { return []; }
}
export function writeLockedPlates(projectId: string | null | undefined, slots: readonly number[] | null) {
  if (!projectId) return;
  try {
    const kept = normalizeLockedPlates(slots ?? null);
    if (kept) window.localStorage.setItem(LOCK_PREFIX + projectId, JSON.stringify(kept));
    else window.localStorage.removeItem(LOCK_PREFIX + projectId);
  } catch { /* session only */ }
  try { window.dispatchEvent(new CustomEvent(BUILD_PLATES_EVENT, { detail: { projectId } })); } catch { /* ignore */ }
}

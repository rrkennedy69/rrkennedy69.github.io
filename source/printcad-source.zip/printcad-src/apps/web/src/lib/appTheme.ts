export const APP_THEME_STORAGE_KEY = "layerling.theme";

export const APP_THEME_OPTIONS = [
  { value: "system", label: "System" },
  { value: "light", label: "Light" },
  { value: "dark", label: "Dark" },
  { value: "graphite", label: "Graphite" },
  { value: "night", label: "Night Vision" },
  { value: "thermal", label: "Thermal" },
  { value: "blocks", label: "Blocks (Tinkercad-inspired)" },
  { value: "forge", label: "Forge (Fusion-inspired)" },
  { value: "works", label: "Works (SolidWorks-inspired)" },
] as const;

export type AppThemePreference = (typeof APP_THEME_OPTIONS)[number]["value"];
/**
 * Graphite is the dark theme with neutral grey surfaces instead of the warm
 * brown ones. It resolves to "dark", so everything that only asks light or
 * dark keeps working; the palette on top only swaps colours.
 */
export type ResolvedAppTheme = "light" | "dark";
export type AppThemePalette = "default" | "graphite" | "ios" | "night" | "thermal" | "blocks" | "forge" | "works";
/** The three light, CAD-app-inspired themes: own colours and icon styling, no borrowed artwork. */
export const INSPIRED_PALETTES = ["blocks", "forge", "works"] as const;

export function appThemePalette(preference: AppThemePreference): AppThemePalette {
  if (preference === "graphite") return "graphite";
  if (preference === "night") return "night";
  if (preference === "thermal") return "thermal";
  if (preference === "blocks" || preference === "forge" || preference === "works") return preference;
  // Dark (chosen, or from the system) is the iOS-style true-black theme.
  if (preference === "dark") return "ios";
  if (preference === "system" && typeof window !== "undefined" && typeof window.matchMedia === "function" && window.matchMedia("(prefers-color-scheme: dark)").matches) return "ios";
  return "default";
}

export function normalizeAppThemePreference(value: unknown): AppThemePreference {
  return value === "light" || value === "dark" || value === "graphite" || value === "night" || value === "thermal" || value === "system" || value === "blocks" || value === "forge" || value === "works" ? value : "system";
}

export function resolveAppTheme(preference: AppThemePreference, prefersDark: boolean): ResolvedAppTheme {
  if (preference === "system") return prefersDark ? "dark" : "light";
  if (preference === "blocks" || preference === "forge" || preference === "works") return "light";
  return preference === "graphite" || preference === "night" || preference === "thermal" ? "dark" : preference;
}

export function readStoredAppTheme(storage: Pick<Storage, "getItem"> | null | undefined): AppThemePreference {
  if (!storage) return "system";
  try {
    return normalizeAppThemePreference(storage.getItem(APP_THEME_STORAGE_KEY));
  } catch {
    return "system";
  }
}

/** Whether this browser has a theme on record, even "system": someone chose it, or it has been applied before. */
export function hasStoredAppTheme(storage: Pick<Storage, "getItem"> | null | undefined): boolean {
  if (!storage) return false;
  try {
    return storage.getItem(APP_THEME_STORAGE_KEY) !== null;
  } catch {
    return true;
  }
}

export function storeAppTheme(
  storage: Pick<Storage, "setItem"> | null | undefined,
  preference: AppThemePreference,
) {
  if (!storage) return;
  try {
    storage.setItem(APP_THEME_STORAGE_KEY, preference);
  } catch {
    // The selected theme still applies for this session when storage is unavailable.
  }
}

export function applyAppTheme(preference: AppThemePreference, prefersDark?: boolean) {
  if (typeof document === "undefined") return;
  const systemPrefersDark = prefersDark ?? (
    typeof window !== "undefined" && typeof window.matchMedia === "function"
      ? window.matchMedia("(prefers-color-scheme: dark)").matches
      : false
  );
  const resolved = resolveAppTheme(preference, systemPrefersDark);
  document.documentElement.dataset.theme = resolved;
  let palette = appThemePalette(preference);
  if (preference === "system") palette = resolved === "dark" ? "ios" : "default";
  if (palette === "default") delete document.documentElement.dataset.palette;
  else document.documentElement.dataset.palette = palette;
  document.documentElement.style.colorScheme = resolved;
  if (palette === "blocks" || palette === "forge" || palette === "works") ensureInspiredIconDefs();
  if (palette === "graphite") ensureGraphiteStylesheet();
  if (palette === "ios" || palette === "night" || palette === "thermal") ensureStylesheet(IOS_STYLESHEET_ID, IOS_STYLESHEET_HREF);
}

export const IOS_STYLESHEET_ID = "layerling-ios-dark-theme";
export const IOS_STYLESHEET_HREF = `/assets/theme/ios-dark-theme.css${process.env.NEXT_PUBLIC_APP_VERSION ? `?v=${process.env.NEXT_PUBLIC_APP_VERSION}` : ""}`;

function ensureStylesheet(id: string, href: string) {
  if (document.getElementById(id)) return;
  const link = document.createElement("link");
  link.id = id;
  link.rel = "stylesheet";
  link.href = href;
  document.head.appendChild(link);
}

/**
 * Night Vision draws on the iOS dark sheet (black grounds) and then sends the whole page,
 * the 3D view included, through one filter: brightness becomes red and only red, with the
 * dark end pinned to black. So no white, blue or other colour can show anywhere, and
 * models look red without their saved colours changing.
 */
export const NIGHT_VISION_FILTER_ID = "pc-night-vision";
function ensureNightVisionFilter() {
  if (document.getElementById(NIGHT_VISION_FILTER_ID)) return;
  const ns = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(ns, "svg");
  svg.setAttribute("aria-hidden", "true");
  svg.setAttribute("width", "0");
  svg.setAttribute("height", "0");
  svg.style.position = "absolute";
  svg.innerHTML = `<filter id="${NIGHT_VISION_FILTER_ID}" color-interpolation-filters="sRGB"><feColorMatrix type="matrix" values="0.2126 0.7152 0.0722 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0"/><feComponentTransfer><feFuncR type="table" tableValues="0 0 0.3 0.55 0.72 0.86 1 1"/></feComponentTransfer></filter>`;
  document.body.appendChild(svg);
}

export const GRAPHITE_STYLESHEET_ID = "layerling-graphite-theme";
// Root-relative like every other asset: a relative path resolved against the
// current URL and missed on any page not at the root (the 404 page, say). The
// version query keeps a cached stylesheet from an older release out, since
// the file is regenerated from globals.css under the same name every build.
const appVersion = process.env.NEXT_PUBLIC_APP_VERSION;
export const GRAPHITE_STYLESHEET_HREF = `/assets/theme/graphite-theme.css${appVersion ? `?v=${appVersion}` : ""}`;

/**
 * Graphite's colours live in a generated stylesheet that is only fetched once
 * someone picks the theme. It goes last in <head> so it follows globals.css;
 * its rules only match while data-palette="graphite" is set, so it can stay
 * when the theme is switched away again.
 */
function ensureGraphiteStylesheet() {
  if (document.getElementById(GRAPHITE_STYLESHEET_ID)) return;
  const link = document.createElement("link");
  link.id = GRAPHITE_STYLESHEET_ID;
  link.rel = "stylesheet";
  link.href = GRAPHITE_STYLESHEET_HREF;
  document.head.appendChild(link);
}

const themeListeners = new Set<() => void>();
let currentThemePreference: AppThemePreference =
  typeof window !== "undefined" ? readStoredAppTheme(window.localStorage) : "system";

if (typeof window !== "undefined" && typeof window.matchMedia === "function") {
  const media = window.matchMedia("(prefers-color-scheme: dark)");
  const handleMediaChange = () => {
    if (currentThemePreference === "system") {
      applyAppTheme("system", media.matches);
      themeListeners.forEach((listener) => listener());
    }
  };
  if (typeof media.addEventListener === "function") {
    media.addEventListener("change", handleMediaChange);
  } else if (typeof (media as unknown as { addListener?: (cb: () => void) => void }).addListener === "function") {
    (media as unknown as { addListener: (cb: () => void) => void }).addListener(handleMediaChange);
  }
}

export function subscribeToAppTheme(listener: () => void) {
  themeListeners.add(listener);
  return () => {
    themeListeners.delete(listener);
  };
}

export function getAppThemePreference(): AppThemePreference {
  return currentThemePreference;
}

export function setAppTheme(preference: AppThemePreference, persist = true) {
  currentThemePreference = preference;
  if (persist && typeof window !== "undefined") {
    storeAppTheme(window.localStorage, preference);
  }
  applyAppTheme(preference);
  themeListeners.forEach((listener) => listener());
}


/**
 * Shared gradients for the inspired themes' icon sets (globals.css fills the
 * icons' body shapes with them). Original artwork: plain shaded gradients.
 */
function ensureInspiredIconDefs() {
  if (document.getElementById("pc-inspired-icon-defs")) return;
  const grad = (id: string, top: string, bottom: string, vertical = true) =>
    `<linearGradient id="${id}" x1="0" y1="0" x2="${vertical ? 0 : 1}" y2="1"><stop offset="0" stop-color="${top}"/><stop offset="1" stop-color="${bottom}"/></linearGradient>`;
  const blocks: Record<string, [string, string]> = {
    home: ["#ff8a3d", "#d9480f"], clipboard: ["#5fd3f3", "#1c8fb8"], shapes: ["#ffd84d", "#e0a000"], visibility: ["#b9c4cf", "#7d8b99"],
    combine: ["#b48cff", "#6c3fd1"], modify: ["#ff6b6b", "#c92a2a"], arrange: ["#5ee08f", "#1f9d55"], manage: ["#5aa9ff", "#1f6fd1"], help: ["#c7ced6", "#8a96a3"],
  };
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.id = "pc-inspired-icon-defs";
  svg.setAttribute("aria-hidden", "true");
  svg.setAttribute("width", "0");
  svg.setAttribute("height", "0");
  svg.style.position = "absolute";
  svg.innerHTML = `<defs>${Object.entries(blocks).map(([g, [a, b]]) => grad(`pc-blocks-${g}`, a, b, false)).join("")}${grad("pc-works-body", "#f6e7a6", "#c9a43a")}${grad("pc-works-steel", "#eef2f6", "#9aa8b8")}</defs>`;
  document.body.appendChild(svg);
}

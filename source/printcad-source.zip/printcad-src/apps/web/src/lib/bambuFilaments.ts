import { BAMBU_MATERIALS, type BambuColor, type BambuMaterial } from "@/lib/bambuFilaments.generated";
import type { ShapeFilament } from "@/types/layerling";

export { BAMBU_MATERIALS };
export type { BambuColor, BambuMaterial };

export const DEFAULT_BAMBU_MATERIAL = "GFA00"; // PLA Basic

export function bambuMaterial(id: string | undefined): BambuMaterial {
  return BAMBU_MATERIALS.find((m) => m.id === id) ?? BAMBU_MATERIALS[0];
}

/** The material groups for the dropdown. */
export function bambuMaterialGroups() {
  const groups: { label: string; items: BambuMaterial[] }[] = [];
  const label = (m: BambuMaterial) => (m.name.startsWith("Support") || m.name === "PVA" ? "Support" : m.name.startsWith("PLA") ? "PLA" : m.name.startsWith("PET") ? "PETG / PET" : m.name.startsWith("ABS") || m.name.startsWith("ASA") ? "ABS / ASA" : m.name.startsWith("TPU") ? "TPU" : m.name.startsWith("PC") ? "PC" : "Engineering");
  for (const m of BAMBU_MATERIALS) {
    const l = label(m);
    let g = groups.find((x) => x.label === l);
    if (!g) groups.push((g = { label: l, items: [] }));
    g.items.push(m);
  }
  return groups;
}

/** Bambu printer for a PrintCaddy printer preset id: machine model name and the profile suffix code. */
const PRINTERS: Record<string, { model: string; code: string; process: string }> = {
  "bambu-lab-a1-mini": { model: "Bambu Lab A1 mini", code: "A1M", process: "A1M" },
  "bambu-lab-a1": { model: "Bambu Lab A1", code: "A1", process: "A1" },
  "bambu-lab-a2l": { model: "Bambu Lab A2L", code: "A2L", process: "A2L" },
  "bambu-lab-p1p": { model: "Bambu Lab P1P", code: "P1P", process: "P1P" },
  "bambu-lab-p1s": { model: "Bambu Lab P1S", code: "X1C", process: "X1C" },
  "bambu-lab-p2s": { model: "Bambu Lab P2S", code: "P2S", process: "P2S" },
  "bambu-lab-x1": { model: "Bambu Lab X1", code: "X1", process: "X1C" },
  "bambu-lab-x1-carbon": { model: "Bambu Lab X1 Carbon", code: "X1C", process: "X1C" },
  "bambu-lab-x1e": { model: "Bambu Lab X1E", code: "X1E", process: "X1C" },
  "bambu-lab-x2d": { model: "Bambu Lab X2D", code: "X2D", process: "X2D" },
  "bambu-lab-h2s": { model: "Bambu Lab H2S", code: "H2S", process: "H2S" },
  "bambu-lab-h2d": { model: "Bambu Lab H2D", code: "H2D", process: "H2D" },
  "bambu-lab-h2d-pro": { model: "Bambu Lab H2D Pro", code: "H2DP", process: "H2DP" },
  "bambu-lab-h2c": { model: "Bambu Lab H2C", code: "H2C", process: "H2C" },
};

export type BambuPrinter = { model: string; code: string; process: string; known: boolean };
/** A non-Bambu printer falls back to the X1 Carbon, which Bambu Studio and OrcaSlicer always have. */
export function bambuPrinter(printerId: string | undefined): BambuPrinter {
  const p = printerId ? PRINTERS[printerId] : undefined;
  return p ? { ...p, known: true } : { ...PRINTERS["bambu-lab-x1-carbon"], known: false };
}

/** Bambu's preset name for a material on a printer, e.g. "Bambu PLA Basic @BBL X1C". */
export function bambuFilamentPreset(material: BambuMaterial, printer: BambuPrinter) {
  const code = material.presets.includes(printer.code) ? printer.code : material.presets.includes("X1C") ? "X1C" : material.presets[0] ?? "X1C";
  return `Bambu ${material.name} @BBL ${code}`;
}

export function filamentColorName(filament: ShapeFilament | undefined, hex: string) {
  if (!filament?.name) return null;
  const color = bambuMaterial(filament.material).colors.find((c) => c.n === filament.name);
  return color && color.h.toLowerCase() === hex.toLowerCase() ? filament.name : null;
}

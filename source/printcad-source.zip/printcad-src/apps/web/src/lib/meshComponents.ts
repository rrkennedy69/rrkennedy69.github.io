// PrintCAD: split an imported triangle soup into its separate objects (connected components),
// so a Tinkercad STL/OBJ/3MF of several objects comes in as one selectable body per object.
import type { WorkplaneShape } from "@/types/layerling";
import { importedShapeFromTriangleSoup } from "@/lib/stlImport";

const MAX_PARTS = 400;
type Box = [number, number, number, number, number, number];

function boxOf(p: readonly number[], tris: readonly number[]): Box {
  const b: Box = [Infinity, -Infinity, Infinity, -Infinity, Infinity, -Infinity];
  for (const t of tris) for (let v = 0; v < 3; v += 1) for (let k = 0; k < 3; k += 1) {
    const x = p[t * 9 + v * 3 + k];
    if (x < b[k * 2]) b[k * 2] = x;
    if (x > b[k * 2 + 1]) b[k * 2 + 1] = x;
  }
  return b;
}
const inside = (a: Box, b: Box, e: number) => a[0] > b[0] + e && a[1] < b[1] - e && a[2] > b[2] + e && a[3] < b[3] - e && a[4] > b[4] + e && a[5] < b[5] - e;

/** Triangle groups that share no corner with each other. A closed surface inside another
 * (the inner wall of a hollow part) stays with the part around it. */
export function meshComponents(positions: readonly number[]): number[][] {
  const count = Math.floor(positions.length / 9);
  if (count < 2) return [Array.from({ length: count }, (_, i) => i)];
  const parent = new Int32Array(count).map((_, i) => i);
  const find = (i: number): number => { while (parent[i] !== i) { parent[i] = parent[parent[i]]; i = parent[i]; } return i; };
  const owner = new Map<string, number>();
  for (let t = 0; t < count; t += 1) for (let v = 0; v < 3; v += 1) {
    const o = t * 9 + v * 3;
    const key = `${Math.round(positions[o] * 1e4)},${Math.round(positions[o + 1] * 1e4)},${Math.round(positions[o + 2] * 1e4)}`;
    const seen = owner.get(key);
    if (seen === undefined) owner.set(key, t); else { const a = find(seen), b = find(t); if (a !== b) parent[a] = b; }
  }
  const groups = new Map<number, number[]>();
  for (let t = 0; t < count; t += 1) { const r = find(t); const g = groups.get(r); if (g) g.push(t); else groups.set(r, [t]); }
  let parts = [...groups.values()].map((tris) => ({ tris, box: boxOf(positions, tris) }));
  parts.sort((a, b) => (b.box[1] - b.box[0]) * (b.box[3] - b.box[2]) * (b.box[5] - b.box[4]) - (a.box[1] - a.box[0]) * (a.box[3] - a.box[2]) * (a.box[5] - a.box[4]));
  const kept: typeof parts = [];
  for (const part of parts) {
    const host = kept.find((k) => inside(part.box, k.box, 1e-4));
    if (host) host.tris.push(...part.tris); else kept.push(part);
  }
  parts = kept;
  return parts.map((p) => p.tris.sort((a, b) => a - b));
}

/** One body per separate object; a shape of one object comes back unchanged. */
export function splitMeshComponents(shape: WorkplaneShape): WorkplaneShape[] {
  const mesh = shape.importedMesh;
  if (!mesh?.positions?.length || shape.kind !== "mesh") return [shape];
  const pos = mesh.positions, nor = mesh.normals?.length === pos.length ? mesh.normals : undefined;
  const comps = meshComponents(pos);
  if (comps.length <= 1 || comps.length > MAX_PARTS) return [shape];
  const sx = mesh.baseWidth ? shape.width / mesh.baseWidth : 1, sy = mesh.baseHeight ? shape.height / mesh.baseHeight : 1, sz = mesh.baseDepth ? shape.depth / mesh.baseDepth : 1;
  return comps.map((tris, i) => {
    const p: number[] = [], n: number[] | undefined = nor ? [] : undefined;
    for (const t of tris) for (let k = 0; k < 9; k += 1) { p.push(pos[t * 9 + k]); if (n && nor) n.push(nor[t * 9 + k]); }
    const b = boxOf(p, Array.from({ length: p.length / 9 }, (_, j) => j));
    const built = importedShapeFromTriangleSoup(shape.name, p, n, "json");
    return {
      ...built,
      name: `${shape.name} ${i + 1}`,
      color: shape.color,
      ...(shape.hole ? { hole: shape.hole } : {}),
      x: shape.x + ((b[0] + b[1]) / 2) * sx,
      z: shape.z + ((b[4] + b[5]) / 2) * sz,
      elevation: (shape.elevation ?? 0) + b[2] * sy,
      importedMesh: { ...built.importedMesh!, sourceFormat: "json" },
    };
  });
}

import { useSyncExternalStore } from "react";
import { AXIS_ARROW_COLORS } from "@/lib/workplaneGrid";

/** The X and Y axis colours (Settings), kept per browser; the defaults are the stock red and green. */
export type PlaneAxis = "x" | "y";
const KEY = (axis: PlaneAxis) => `printcad.axisColor.${axis}.v1`;
const EVENT = "printcad-axis-color";
export const DEFAULT_AXIS_COLORS: Record<PlaneAxis, string> = { x: AXIS_ARROW_COLORS.x, y: AXIS_ARROW_COLORS.y };
const valid = (v: unknown): v is string => typeof v === "string" && /^#[0-9a-f]{6}$/i.test(v);

export function axisColor(axis: PlaneAxis): string {
  try { const v = globalThis.localStorage?.getItem(KEY(axis)); return valid(v) ? v.toLowerCase() : DEFAULT_AXIS_COLORS[axis]; } catch { return DEFAULT_AXIS_COLORS[axis]; }
}
export function setAxisColor(axis: PlaneAxis, color: string | null) {
  try {
    if (!color || color.toLowerCase() === DEFAULT_AXIS_COLORS[axis]) globalThis.localStorage?.removeItem(KEY(axis));
    else if (valid(color)) globalThis.localStorage?.setItem(KEY(axis), color.toLowerCase());
  } catch { /* session only */ }
  if (typeof window !== "undefined") window.dispatchEvent(new Event(EVENT));
}
const snapshot = () => `${axisColor("x")}|${axisColor("y")}`;
/** "x|y" colours; changes whenever either is picked. */
export function useAxisColors(): string {
  return useSyncExternalStore(
    (notify) => { window.addEventListener(EVENT, notify); window.addEventListener("storage", notify); return () => { window.removeEventListener(EVENT, notify); window.removeEventListener("storage", notify); }; },
    snapshot,
    () => `${DEFAULT_AXIS_COLORS.x}|${DEFAULT_AXIS_COLORS.y}`,
  );
}

/**
 * Ribbon icons come from three drawings (48-unit art, 24-unit lucide, older crops), so the
 * same CSS box showed marks of very different sizes. This fits each icon's viewBox to its
 * own ink, so every mark fills the same share of the same box; CSS then draws every stroke
 * at one width (vector-effect: non-scaling-stroke).
 */
const FILL = 0.84; // share of the box the larger side of the ink takes

export function fitIconToInk(svg: SVGSVGElement) {
  if (svg.dataset.pcFit === "1") return;
  let box: DOMRect;
  try {
    box = svg.getBBox();
  } catch {
    return;
  }
  if (!box || box.width <= 0 || box.height <= 0) return; // not laid out yet; try again later
  const side = Math.max(box.width, box.height) / FILL;
  const cx = box.x + box.width / 2;
  const cy = box.y + box.height / 2;
  svg.setAttribute("viewBox", `${(cx - side / 2).toFixed(3)} ${(cy - side / 2).toFixed(3)} ${side.toFixed(3)} ${side.toFixed(3)}`);
  svg.dataset.pcFit = "1";
}

export const RIBBON_ICON_SELECTOR =
  ".toolbar-mode-content .toolbar-icon svg, .toolbar-mode-content .action-icon-button svg, .toolbar-mode-content .shape-menu-trigger svg";

export function fitRibbonIcons(root: ParentNode = document) {
  root.querySelectorAll<SVGSVGElement>(RIBBON_ICON_SELECTOR).forEach((svg) => {
    if (svg.closest("[data-no-fit]")) return;
    if (svg.parentElement?.closest("svg")) return;
    fitIconToInk(svg);
  });
}

/** Keeps fitting icons as the ribbon re-renders; returns a cleanup. */
export function watchRibbonIcons(): () => void {
  if (typeof window === "undefined" || typeof MutationObserver === "undefined") return () => {};
  let frame = 0;
  const run = () => {
    cancelAnimationFrame(frame);
    frame = requestAnimationFrame(() => fitRibbonIcons());
  };
  const observer = new MutationObserver((records) => {
    for (const r of records) {
      // An icon whose drawing changed gets measured again.
      if (r.type === "attributes" && r.attributeName === "d") {
        const svg = (r.target as Element).closest("svg") as SVGSVGElement | null;
        if (svg) delete svg.dataset.pcFit;
      }
    }
    run();
  });
  observer.observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ["d", "class"] });
  run();
  return () => {
    cancelAnimationFrame(frame);
    observer.disconnect();
  };
}

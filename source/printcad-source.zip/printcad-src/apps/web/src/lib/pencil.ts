import { useSyncExternalStore } from "react";
import { isAppleTouchDevice } from "./fileAccept";

/**
 * Apple Pencil mode, after Shapr3D on the iPad: the pen selects, draws and drags handles; fingers
 * only navigate (one finger orbits / pans the sketch, two pan and pinch). While the pen is down and
 * for PALM_MS after, touches are dropped before anything sees them (palm rejection on top of iPadOS's own).
 * The mode switches itself on the first time a pen is seen, unless it was switched off by hand.
 */
export const PENCIL_STORAGE_KEY = "printcad.pencilMode.v1"; // "1" on, "0" off, missing: not decided yet
export const PALM_MS = 300;
const listeners = new Set<() => void>();
let cached: boolean | null = null;
let penDown = false;
let penUpAt = -Infinity;

function stored(): string | null {
  try { return window.localStorage.getItem(PENCIL_STORAGE_KEY); } catch { return null; }
}

export function pencilModeEnabled(): boolean {
  if (cached === null) cached = typeof window !== "undefined" && stored() === "1";
  return cached;
}

export function setPencilMode(on: boolean) {
  cached = on;
  try { window.localStorage.setItem(PENCIL_STORAGE_KEY, on ? "1" : "0"); } catch { /* private mode */ }
  listeners.forEach((listener) => listener());
}

export function usePencilMode() {
  return useSyncExternalStore(
    (listener) => { listeners.add(listener); return () => listeners.delete(listener); },
    pencilModeEnabled,
    () => false,
  );
}

/** A touch that comes while the pen is down or just lifted is a palm (or the side of a hand). */
export function palmRejected(now = performance.now()) {
  return penDown || now - penUpAt < PALM_MS;
}

/** A finger in Pencil mode: it navigates and never selects or edits. */
export function fingerNavigatesOnly(event: { pointerType: string }) {
  return event.pointerType === "touch" && pencilModeEnabled();
}

export function isIpad(userAgent: string, maxTouchPoints: number) {
  return /iPad/.test(userAgent) || (/Macintosh/.test(userAgent) && maxTouchPoints > 1);
}

let installed = false;
export function installPencilInput() {
  if (installed || typeof window === "undefined") return;
  installed = true;
  if (isIpad(navigator.userAgent, navigator.maxTouchPoints ?? 0)) document.documentElement.classList.add("is-ipad");
  if (isAppleTouchDevice(navigator.userAgent, navigator.maxTouchPoints ?? 0)) document.documentElement.classList.add("is-apple-touch");
  const onPen = (event: PointerEvent) => {
    if (event.pointerType === "pen") {
      if (event.type === "pointerdown") {
        penDown = true;
        if (stored() === null) setPencilMode(true); // first pen seen: switch on, once
      } else if (event.type === "pointerup" || event.type === "pointercancel") {
        penDown = false;
        penUpAt = performance.now();
      }
      document.documentElement.classList.toggle("pen-hovering", event.type === "pointermove" && event.buttons === 0);
      return;
    }
    if (event.pointerType === "touch" && pencilModeEnabled() && palmRejected()) {
      event.stopImmediatePropagation();
      if (event.cancelable) event.preventDefault();
    }
  };
  for (const type of ["pointerdown", "pointermove", "pointerup", "pointercancel"]) {
    window.addEventListener(type, onPen as EventListener, { capture: true, passive: false });
  }
  window.addEventListener("pointerleave", () => document.documentElement.classList.remove("pen-hovering"), true);
}

installPencilInput();

/** Test hook: forget the pen state. */
export function resetPencilStateForTests() {
  penDown = false;
  penUpAt = -Infinity;
  cached = null;
}

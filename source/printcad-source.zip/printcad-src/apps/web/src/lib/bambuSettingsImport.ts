// Reads Bambu Studio settings: a project .3mf (Metadata/project_settings.config), preset .json files
// (printer / filament / process, system or user presets) and .bbscfg / .bbsflmt bundles (zips of presets).
// Supported keys are mapped onto the slicer's settings; every raw value is kept so it rides into the exported 3MF.
import { unzipSync, strFromU8 } from "fflate";
import type { SliceSettings } from "@/lib/slicer";

export type BambuValue = string | string[];
export type BambuKind = "printer" | "filament" | "process" | "project";
export type BambuImported = {
  /** Every imported key, latest file wins. */
  raw: Record<string, BambuValue>;
  /** Where each key came from (printer / filament / process / project). */
  kindOf: Record<string, BambuKind>;
  sources: { file: string; kind: BambuKind; name: string; keys: number }[];
  warnings: string[];
};

export const EMPTY_IMPORT: BambuImported = { raw: {}, kindOf: {}, sources: [], warnings: [] };

/** Identity keys that describe a preset rather than a setting. They are not carried into the export. */
const IDENTITY = new Set([
  "name", "from", "type", "inherits", "setting_id", "filament_id", "instantiation", "version", "is_custom_defined", "base_id",
  "user_id", "updated_time", "compatible_printers", "compatible_printers_condition", "compatible_prints", "compatible_prints_condition",
  "print_settings_id", "printer_settings_id", "filament_settings_id", "different_settings_to_system", "inherits_group",
  "filament_ids", "filament_colour", "printable_area", "printable_height", "printer_model", "printer_variant", "default_print_profile",
  "default_filament_profile", "upward_compatible_machine", "print_compatible_printers", "filament_map", "extruder_colour",
]);

const first = (v: BambuValue | undefined) => (Array.isArray(v) ? v[0] : v);
const num = (v: BambuValue | undefined) => {
  const s = first(v);
  if (s === undefined || s === "" || s === "nil") return undefined;
  const n = Number(String(s).replace("%", ""));
  return Number.isFinite(n) ? n : undefined;
};

type Mapping = { label: string; cura: string; apply: (v: BambuValue, s: SliceSettings) => Partial<SliceSettings> | null; write?: (s: SliceSettings) => BambuValue | undefined };
const INFILL: Record<string, SliceSettings["infillPattern"]> = { grid: "grid", line: "lines", "zig-zag": "zigzag", triangles: "triangles", cubic: "cubic", adaptivecubic: "cubic", gyroid: "gyroid", honeycomb: "cubic", "3dhoneycomb": "cubic", crosshatch: "grid", lightning: "lightning", concentric: "concentric", alignedrectilinear: "lines", rectilinear: "lines", tri_hexagon: "trihexagon", "tri-hexagon": "trihexagon", quartercubic: "quarter_cubic", supportcubic: "cubic" };
const SEAM: Record<string, SliceSettings["seam"]> = { aligned: "sharpest_corner", nearest: "shortest", back: "back", random: "random" };
const setNum = (key: keyof SliceSettings, min: number, max: number) => (v: BambuValue) => { const n = num(v); return n === undefined ? null : ({ [key]: Math.max(min, Math.min(max, n)) } as Partial<SliceSettings>); };

/** Bambu key → slicer setting. Keys not listed here are only carried through to the 3MF. */
export const BAMBU_MAPPINGS: Record<string, Mapping> = {
  layer_height: { label: "Layer height", cura: "layer_height", apply: setNum("layerHeight", 0.04, 0.6) },
  initial_layer_print_height: { label: "Initial layer height", cura: "layer_height_0", apply: setNum("firstLayerHeight", 0.08, 0.6) },
  wall_loops: { label: "Wall loops", cura: "wall_line_count", apply: setNum("walls", 1, 20) },
  top_shell_layers: { label: "Top shell layers", cura: "top_layers", apply: setNum("topLayers", 0, 50) },
  bottom_shell_layers: { label: "Bottom shell layers", cura: "bottom_layers", apply: setNum("bottomLayers", 0, 50) },
  sparse_infill_density: { label: "Sparse infill density", cura: "infill_sparse_density", apply: setNum("infill", 0, 100) },
  sparse_infill_pattern: { label: "Sparse infill pattern", cura: "infill_pattern", apply: (v) => { const p = INFILL[String(first(v))]; return p ? { infillPattern: p } : null; } },
  seam_position: { label: "Seam position", cura: "z_seam_type", apply: (v) => { const p = SEAM[String(first(v))]; return p ? { seam: p } : null; } },
  outer_wall_speed: { label: "Outer wall speed", cura: "speed_wall_0", apply: setNum("speedOuterWall", 5, 1000) },
  inner_wall_speed: { label: "Inner wall speed", cura: "speed_wall_x", apply: setNum("speedInnerWall", 5, 1000) },
  sparse_infill_speed: { label: "Sparse infill speed", cura: "speed_infill", apply: setNum("speedInfill", 5, 1000) },
  initial_layer_speed: { label: "Initial layer speed", cura: "speed_layer_0", apply: setNum("speedFirstLayer", 5, 500) },
  travel_speed: { label: "Travel speed", cura: "speed_travel", apply: setNum("speedTravel", 20, 1500) },
  enable_support: { label: "Enable support", cura: "support_enable", apply: (v) => ({ supports: first(v) === "1" || first(v) === "true" }) },
  support_type: { label: "Support type", cura: "support_structure", apply: (v) => ({ supportStyle: String(first(v)).startsWith("tree") ? "tree" : "normal" }) },
  support_threshold_angle: { label: "Support threshold angle", cura: "support_angle", apply: (v) => { const n = num(v); return n ? { supportAngle: 90 - Math.max(1, Math.min(89, n)) } : null; } },
  support_on_build_plate_only: { label: "On build plate only", cura: "support_type", apply: (v) => ({ supportBuildplateOnly: first(v) === "1" }) },
  brim_type: { label: "Brim type", cura: "adhesion_type", apply: (v, s) => ({ adhesion: first(v) === "no_brim" ? (s.adhesion === "brim" ? "none" : s.adhesion) : "brim" }) },
  brim_width: { label: "Brim width", cura: "brim_width", apply: setNum("brimWidth", 0, 30) },
  skirt_loops: { label: "Skirt loops", cura: "skirt_line_count", apply: (v, s) => { const n = num(v) ?? 0; return s.adhesion === "brim" ? null : { adhesion: n > 0 ? "skirt" : "none" }; } },
  ironing_type: { label: "Ironing type", cura: "ironing_enabled", apply: (v) => ({ ironing: first(v) !== "no ironing" }) },
  nozzle_temperature: { label: "Nozzle temperature", cura: "material_print_temperature", apply: setNum("nozzleTemp", 150, 350) },
  nozzle_temperature_initial_layer: { label: "Nozzle temp (initial layer)", cura: "material_print_temperature_layer_0", apply: setNum("nozzleTempFirst", 150, 350) },
  textured_plate_temp: { label: "Bed temp (Textured PEI)", cura: "material_bed_temperature", apply: setNum("bedTemp", 0, 130) },
  fan_max_speed: { label: "Fan max speed", cura: "cool_fan_speed", apply: setNum("fanSpeed", 0, 100) },
  filament_density: { label: "Filament density", cura: "(estimate)", apply: setNum("density", 0.5, 3) },
  nozzle_diameter: { label: "Nozzle diameter", cura: "machine_nozzle_size", apply: setNum("nozzle", 0.1, 1.2) },
  retraction_length: { label: "Retraction length", cura: "retraction_amount", apply: setNum("retractLength", 0, 15) },
  retraction_speed: { label: "Retraction speed", cura: "retraction_speed", apply: setNum("retractSpeed", 5, 150) },
  filament_retraction_length: { label: "Filament retraction length", cura: "retraction_amount", apply: setNum("retractLength", 0, 15) },
};

function kindOfPreset(obj: Record<string, unknown>, file: string): BambuKind {
  const t = String(obj.type ?? "").toLowerCase();
  if (t === "machine" || t === "printer") return "printer";
  if (t === "filament") return "filament";
  if (t === "process" || t === "print") return "process";
  if ("printer_settings_id" in obj && "print_settings_id" in obj && "filament_settings_id" in obj) return "project";
  if ("filament_type" in obj || "nozzle_temperature" in obj || /filament|\.bbsflmt/i.test(file)) return "filament";
  if ("printable_area" in obj || "machine_start_gcode" in obj || /machine|printer/i.test(file)) return "printer";
  return "process";
}

function normalise(obj: Record<string, unknown>): Record<string, BambuValue> {
  const out: Record<string, BambuValue> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (typeof v === "string") out[k] = v;
    else if (typeof v === "number" || typeof v === "boolean") out[k] = String(v);
    else if (Array.isArray(v) && v.every((x) => typeof x === "string" || typeof x === "number")) out[k] = v.map(String);
  }
  return out;
}

function addPreset(into: BambuImported, obj: Record<string, unknown>, file: string) {
  const kind = kindOfPreset(obj, file);
  const values = normalise(obj);
  let keys = 0;
  for (const [k, v] of Object.entries(values)) {
    if (IDENTITY.has(k)) continue;
    into.raw[k] = v;
    into.kindOf[k] = kind;
    keys++;
  }
  const name = String(obj.name ?? obj.print_settings_id ?? file);
  into.sources.push({ file, kind, name, keys });
  if (typeof obj.inherits === "string" && obj.inherits) into.warnings.push(`${name} is a user preset based on “${obj.inherits}”; only its changed values are in the file, the rest stay at PrintCaddy defaults.`);
}

/** Reads one dropped file and merges its settings into `into` (returns a new object). */
export async function importBambuFile(file: File, previous: BambuImported = EMPTY_IMPORT): Promise<BambuImported> {
  const into: BambuImported = { raw: { ...previous.raw }, kindOf: { ...previous.kindOf }, sources: [...previous.sources], warnings: [...previous.warnings] };
  const bytes = new Uint8Array(await file.arrayBuffer());
  const lower = file.name.toLowerCase();
  const parseJson = (text: string, name: string) => {
    try { addPreset(into, JSON.parse(text) as Record<string, unknown>, name); }
    catch { into.warnings.push(`${name}: not a readable Bambu settings JSON.`); }
  };
  const isZip = bytes[0] === 0x50 && bytes[1] === 0x4b;
  if (!isZip) {
    parseJson(strFromU8(bytes), file.name);
    return into;
  }
  let entries: Record<string, Uint8Array>;
  try { entries = unzipSync(bytes); } catch { throw new Error(`${file.name}: could not open the archive.`); }
  if (lower.endsWith(".3mf")) {
    const cfg = Object.keys(entries).find((k) => /metadata\/project_settings\.config$/i.test(k));
    if (!cfg) throw new Error(`${file.name} has no Metadata/project_settings.config: it is not a Bambu Studio project (try exporting with "Save project").`);
    parseJson(strFromU8(entries[cfg]), `${file.name} › project_settings`);
    return into;
  }
  // .bbscfg / .bbsflmt / .zip: a bundle of preset JSON files (plus bundle_structure.json).
  const jsons = Object.keys(entries).filter((k) => k.toLowerCase().endsWith(".json") && !/bundle_structure\.json$/i.test(k));
  if (!jsons.length) throw new Error(`${file.name}: no presets found inside.`);
  // Printers first, then process, then filaments so the filament values land last.
  const rank = (k: string) => (/printer|machine/i.test(k) ? 0 : /filament/i.test(k) ? 2 : 1);
  for (const k of jsons.sort((a, b) => rank(a) - rank(b))) parseJson(strFromU8(entries[k]), `${file.name} › ${k.split("/").pop()}`);
  return into;
}

/** Applies the mapped keys onto the settings. Returns the new settings and which keys took effect. */
export function applyBambu(imported: BambuImported, base: SliceSettings) {
  let s = { ...base };
  const applied = new Set<string>();
  // brim_type before skirt_loops so a brim wins.
  const order = Object.keys(BAMBU_MAPPINGS);
  for (const key of order) {
    const v = imported.raw[key];
    if (v === undefined) continue;
    const patch = BAMBU_MAPPINGS[key].apply(v, s);
    if (patch) { s = { ...s, ...patch }; applied.add(key); }
  }
  return { settings: s, applied };
}

/** Raw imported values to carry into the 3MF (identity keys already dropped). */
export function bambuCarryThrough(imported: BambuImported): Record<string, BambuValue> {
  return { ...imported.raw };
}

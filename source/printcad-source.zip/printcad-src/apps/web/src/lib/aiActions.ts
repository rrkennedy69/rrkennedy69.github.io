/**
 * AI helper: the action plan the model may return, its whitelist validator, a rule-based parser for
 * simple commands, print checks, smart arrange, prompts and the model callers. Nothing the model
 * returns is ever run as code - only the whitelisted actions below, with checked, clamped values.
 */
import type { AiSettings } from "@/lib/aiSettings";

export type AiMode = "model" | "check" | "explain" | "arrange";

export type AiShapeInfo = {
  id: string; name: string; kind: string; color: string; hole: boolean;
  x: number; z: number; elevation: number; width: number; depth: number; height: number; rotation: number;
  material?: string;
};

export type AiContext = {
  scope: "area" | "selection" | "scene";
  shapes: AiShapeInfo[];
  /** All shapes of the design, for the checks that look at neighbours. */
  allShapes: AiShapeInfo[];
  bed: { width: number; depth: number; height: number };
  plates: { number: number; offsetX: number; offsetZ: number }[];
  /** PNG data URL of the area (or the whole view). */
  snapshot?: string;
};

export const SHAPE_KINDS = ["box", "roundedBox", "cylinder", "sphere", "cone", "pyramid", "torus", "tube", "wedge", "halfSphere", "polygon", "star", "heart", "text"] as const;
export type AiShapeKind = (typeof SHAPE_KINDS)[number];

export type AiAction =
  | { op: "add_shape"; kind: AiShapeKind; width?: number; depth?: number; height?: number; x?: number; z?: number; elevation?: number; color?: string; name?: string; hole?: boolean }
  | { op: "move"; ids: string[]; dx?: number; dy?: number; dz?: number; x?: number; z?: number; elevation?: number }
  | { op: "rotate"; ids: string[]; angle: number; axis: "x" | "y" | "z" }
  | { op: "scale"; ids: string[]; percent: number }
  | { op: "resize"; ids: string[]; width?: number; depth?: number; height?: number }
  | { op: "color"; ids: string[]; color: string }
  | { op: "material"; ids: string[]; material: string }
  | { op: "fillet" | "chamfer"; ids: string[]; amount: number; edges: "all" | "top" | "bottom" | "vertical" }
  | { op: "hole"; ids: string[]; hole: boolean }
  | { op: "group"; ids: string[] }
  | { op: "duplicate"; ids: string[]; dx?: number; dz?: number }
  | { op: "pattern"; ids: string[]; mode: "row" | "circle"; count: number; spacing?: number; direction?: "x" | "y" | "z"; centerX?: number; centerY?: number }
  | { op: "align"; ids: string[]; axis: "x" | "y" | "z"; target: "min" | "center" | "max" }
  | { op: "arrange_plates"; ids: string[] }
  | { op: "delete"; ids: string[] };

export type AiPlan = { summary: string; actions: AiAction[]; reply?: string; warnings?: string[]; findings?: AiFinding[] };
export type AiFinding = { level: "warn" | "info"; text: string; ids: string[] };

export const AI_OPS = ["add_shape", "move", "rotate", "scale", "resize", "color", "material", "fillet", "chamfer", "hole", "group", "duplicate", "pattern", "align", "arrange_plates", "delete"] as const;

/* ---------------------------------------------------------------- validation */

const num = (v: unknown, min: number, max: number): number | undefined => {
  const n = typeof v === "string" ? Number(v) : v;
  if (typeof n !== "number" || !Number.isFinite(n)) return undefined;
  return Math.min(max, Math.max(min, n));
};
const LIM = 2000;
const COLOR_RE = /^#[0-9a-f]{6}$/i;
export const NAMED_COLORS: Record<string, string> = {
  red: "#e53935", orange: "#fb8c00", yellow: "#fdd835", green: "#43a047", blue: "#1e88e5", purple: "#8e24aa", pink: "#ec407a",
  black: "#212121", white: "#fafafa", gray: "#9e9e9e", grey: "#9e9e9e", brown: "#795548", cyan: "#00acc1", teal: "#00897b", gold: "#e4bd68", silver: "#a6a9aa",
};
function color(v: unknown): string | undefined {
  if (typeof v !== "string") return undefined;
  const s = v.trim().toLowerCase();
  if (COLOR_RE.test(s)) return s;
  if (/^#[0-9a-f]{3}$/i.test(s)) return `#${s[1]}${s[1]}${s[2]}${s[2]}${s[3]}${s[3]}`;
  return NAMED_COLORS[s];
}
export const MATERIALS: Record<string, string> = { pla: "GFA00", "pla matte": "GFA01", "pla silk": "GFA05", petg: "GFG02", abs: "GFB00", asa: "GFB01", tpu: "GFU01", pc: "GFC00" };

/**
 * Turns whatever the model returned into a plan of whitelisted actions. Unknown ops, ids not in the
 * design and values out of range are dropped (and reported), never passed on.
 */
export function validatePlan(raw: unknown, ctx: AiContext): AiPlan {
  const warnings: string[] = [];
  const obj = (typeof raw === "object" && raw ? raw : {}) as Record<string, unknown>;
  const known = new Set(ctx.allShapes.map((s) => s.id));
  const defaultIds = ctx.shapes.map((s) => s.id);
  const list = Array.isArray(obj.actions) ? obj.actions.slice(0, 40) : [];
  const actions: AiAction[] = [];
  let newCount = 0;
  for (const entry of list) {
    if (!entry || typeof entry !== "object") continue;
    const a = entry as Record<string, unknown>;
    // Small models drift: accept "type"/"action" for op, "shape"/"add" for add_shape, cube for box.
    let op = String(a.op ?? a.action ?? a.type ?? "");
    if (/^(shape|add|create|create_shape|add_object)$/.test(op) || (!op && a.kind)) op = "add_shape";
    if (/^(colour|set_color|paint)$/.test(op)) op = "color";
    if (!(AI_OPS as readonly string[]).includes(op)) { warnings.push(`Skipped unknown action "${op.slice(0, 30)}".`); continue; }
    let ids = (Array.isArray(a.ids) ? a.ids : typeof a.id === "string" ? [a.id] : []).filter((id): id is string => typeof id === "string" && (known.has(id) || /^new\d+$/.test(id) && Number(id.slice(3)) <= newCount));
    if (ids.length === 0 && op !== "add_shape") ids = defaultIds;
    if (ids.length === 0 && op !== "add_shape") { warnings.push(`Skipped ${op}: nothing to apply it to.`); continue; }
    switch (op) {
      case "add_shape": {
        const kind = String(a.kind ?? a.shape ?? "box").replace(/^(cube|block)$/, "box").replace(/^ball$/, "sphere") as AiShapeKind;
        if (!(SHAPE_KINDS as readonly string[]).includes(kind)) { warnings.push(`Skipped shape kind "${kind}".`); continue; }
        newCount += 1;
        actions.push({ op, kind, width: num(a.width ?? a.size ?? a.diameter, 0.1, LIM), depth: num(a.depth ?? a.size ?? a.diameter, 0.1, LIM), height: num(a.height ?? a.size ?? (kind === "box" && a.width && !a.depth ? a.width : undefined), 0.1, LIM), x: num(a.x, -LIM, LIM), z: num(a.z, -LIM, LIM), elevation: num(a.elevation, -LIM, LIM), color: color(a.color), name: typeof a.name === "string" ? a.name.slice(0, 60) : undefined, hole: a.hole === true });
        break;
      }
      case "move": actions.push({ op, ids, dx: num(a.dx, -LIM, LIM), dy: num(a.dy, -LIM, LIM), dz: num(a.dz, -LIM, LIM), x: num(a.x, -LIM, LIM), z: num(a.z, -LIM, LIM), elevation: num(a.elevation, -LIM, LIM) }); break;
      case "rotate": { const angle = num(a.angle ?? a.degrees, -360, 360); if (angle === undefined) continue; const axis = a.axis === "x" || a.axis === "y" ? a.axis : "z"; actions.push({ op, ids, angle, axis }); break; }
      case "scale": { const percent = num(a.percent, 1, 1000); if (percent === undefined) continue; actions.push({ op, ids, percent }); break; }
      case "resize": actions.push({ op, ids, width: num(a.width, 0.1, LIM), depth: num(a.depth, 0.1, LIM), height: num(a.height, 0.1, LIM) }); break;
      case "color": { const c = color(a.color); if (!c) { warnings.push("Skipped a colour I could not read."); continue; } actions.push({ op, ids, color: c }); break; }
      case "material": { const m = String(a.material ?? "").toLowerCase(); const id = MATERIALS[m] ?? (/^GF[A-Z]\d\d$/i.test(m) ? m.toUpperCase() : undefined); if (!id) { warnings.push(`Skipped unknown material "${m.slice(0, 20)}".`); continue; } actions.push({ op, ids, material: id }); break; }
      case "fillet": case "chamfer": { const amount = num(a.amount ?? a.radius ?? a.size, 0.1, 50); if (amount === undefined) continue; const edges = ["top", "bottom", "vertical"].includes(String(a.edges)) ? (a.edges as "top") : "all"; actions.push({ op, ids, amount, edges }); break; }
      case "hole": actions.push({ op, ids, hole: a.hole !== false }); break;
      case "group": if (ids.length < 2) { warnings.push("Grouping needs two or more objects."); continue; } actions.push({ op, ids }); break;
      case "duplicate": actions.push({ op, ids, dx: num(a.dx, -LIM, LIM), dz: num(a.dz, -LIM, LIM) }); break;
      case "pattern": { const count = Math.round(num(a.count, 2, 100) ?? 0); if (!count) continue; actions.push({ op, ids, mode: a.mode === "circle" ? "circle" : "row", count, spacing: num(a.spacing, 0.1, LIM), direction: a.direction === "y" || a.direction === "z" ? a.direction : "x", centerX: num(a.centerX, -LIM, LIM), centerY: num(a.centerY, -LIM, LIM) }); break; }
      case "align": { const axis = a.axis === "y" || a.axis === "z" ? a.axis : "x"; const target = a.target === "min" || a.target === "max" ? a.target : "center"; actions.push({ op, ids, axis, target }); break; }
      case "arrange_plates": actions.push({ op, ids }); break;
      case "delete": actions.push({ op, ids }); break;
    }
  }
  const summary = typeof obj.summary === "string" && obj.summary.trim() ? obj.summary.slice(0, 400) : describePlan(actions);
  const reply = typeof obj.reply === "string" ? obj.reply.slice(0, 4000) : undefined;
  return { summary, actions, reply, warnings };
}

export function describeAction(a: AiAction, names: Map<string, string>): string {
  const who = "ids" in a ? (a.ids.length > 3 ? `${a.ids.length} objects` : a.ids.map((id) => names.get(id) ?? (id.startsWith("new") ? "the new shape" : id)).join(", ")) : "";
  const r = (n?: number) => (n === undefined ? "" : String(Math.round(n * 100) / 100));
  switch (a.op) {
    case "add_shape": return `Add ${a.hole ? "hole " : ""}${a.kind}${a.width || a.depth || a.height ? ` ${r(a.width ?? 20)}×${r(a.depth ?? 20)}×${r(a.height ?? 20)} mm` : ""}${a.color ? ` in ${a.color}` : ""}${a.x !== undefined || a.z !== undefined ? ` at (${r(a.x ?? 0)}, ${r(a.z ?? 0)})` : ""}`;
    case "move": return `Move ${who}${a.dx || a.dy || a.dz ? ` by ${r(a.dx ?? 0)}, ${r(a.dz ?? 0)}, ${r(a.dy ?? 0)} mm (X, Y, Z)` : ""}${a.x !== undefined || a.z !== undefined || a.elevation !== undefined ? ` to ${a.x !== undefined ? `X ${r(a.x)} ` : ""}${a.z !== undefined ? `depth ${r(a.z)} ` : ""}${a.elevation !== undefined ? `height ${r(a.elevation)}` : ""}` : ""}`;
    case "rotate": return `Rotate ${who} ${r(a.angle)}° about ${a.axis === "z" ? "the vertical axis" : a.axis.toUpperCase()}`;
    case "scale": return `Scale ${who} to ${r(a.percent)}%`;
    case "resize": return `Resize ${who} to ${[a.width && `W ${r(a.width)}`, a.depth && `D ${r(a.depth)}`, a.height && `H ${r(a.height)}`].filter(Boolean).join(" ")} mm`;
    case "color": return `Colour ${who} ${a.color}`;
    case "material": return `Set material of ${who} to ${Object.entries(MATERIALS).find(([, v]) => v === a.material)?.[0].toUpperCase() ?? a.material}`;
    case "fillet": case "chamfer": return `${a.op === "fillet" ? "Fillet" : "Chamfer"} ${a.edges} edges of ${who} by ${r(a.amount)} mm`;
    case "hole": return `Make ${who} ${a.hole ? "a hole" : "solid"}`;
    case "group": return `Group ${who}`;
    case "duplicate": return `Duplicate ${who}`;
    case "pattern": return `${a.mode === "circle" ? "Circular" : "Linear"} pattern of ${who}: ${a.count} pieces${a.spacing ? `, ${r(a.spacing)} mm apart` : ""}`;
    case "align": return `Align ${who} ${a.axis.toUpperCase()} ${a.target}`;
    case "arrange_plates": return `Arrange ${who} across the build plates`;
    case "delete": return `Delete ${who}`;
  }
}

export function describePlan(actions: AiAction[]) {
  return actions.length === 0 ? "Nothing to change." : `${actions.length} step${actions.length === 1 ? "" : "s"}.`;
}

/* ---------------------------------------------------------------- rule-based parser */

const KIND_WORDS: [RegExp, AiShapeKind][] = [
  [/\b(cube|box|block|square)\b/, "box"], [/\brounded box\b/, "roundedBox"], [/\b(cylinder|disc|disk|rod|puck)\b/, "cylinder"], [/\b(sphere|ball)\b/, "sphere"],
  [/\bcone\b/, "cone"], [/\bpyramid\b/, "pyramid"], [/\b(torus|donut|ring)\b/, "torus"], [/\b(tube|pipe)\b/, "tube"], [/\bwedge\b/, "wedge"], [/\bstar\b/, "star"], [/\bheart\b/, "heart"],
];
const MM = "(-?\\d+(?:\\.\\d+)?)\\s*(?:mm|millimet(?:er|re)s?)?";
const DIR: Record<string, { dx?: number; dz?: number; dy?: number }> = {
  left: { dx: -1 }, right: { dx: 1 }, forward: { dz: 1 }, front: { dz: 1 }, back: { dz: -1 }, backward: { dz: -1 }, up: { dy: 1 }, down: { dy: -1 },
};

/** Simple English commands, offline: "make a 20mm cube", "move it left 10mm", "rotate 45", "make it red", "fillet 2mm". */
export function parseRuleCommand(text: string, ctx: AiContext): AiPlan | null {
  const parts = text.toLowerCase().split(/\s*(?:,|;|\bthen\b|\band then\b|\band\b(?=\s+(?:make|add|create|move|rotate|turn|scale|colou?r|paint|fillet|round|chamfer|duplicate|copy|delete|remove|group|combine|align|arrange|pattern|array)))\s*/).filter(Boolean);
  const raw: Record<string, unknown>[] = [];
  let newIdx = 0;
  const target = () => (newIdx > 0 && raw.some((r) => r.op === "add_shape") ? [`new${newIdx}`] : ctx.shapes.map((s) => s.id));
  for (const p of parts) {
    let m: RegExpMatchArray | null;
    const colorWord = Object.keys(NAMED_COLORS).find((c) => new RegExp(`\\b${c}\\b`).test(p)) ?? p.match(/#[0-9a-f]{6}\b/)?.[0];
    const kind = /\b(make|add|create|draw|put|insert|place|new|give me)\b/.test(p) || /^(a|an)\s/.test(p) ? KIND_WORDS.find(([re]) => re.test(p))?.[1] : undefined;
    if (kind && !/\b(it|them|this|these|selection|selected)\b/.test(p)) {
      const tri = p.match(new RegExp(`${MM}\\s*[x×*by]+\\s*${MM}(?:\\s*[x×*by]+\\s*${MM})?`));
      const size = p.match(new RegExp(`${MM}`));
      const dia = p.match(new RegExp(`(?:diameter|dia|wide|width)\\s*(?:of\\s*)?${MM}`)) ?? p.match(new RegExp(`${MM}\\s*(?:diameter|dia|wide)`));
      const r = p.match(new RegExp(`radius\\s*(?:of\\s*)?${MM}`)) ?? p.match(new RegExp(`${MM}\\s*radius`));
      const h = p.match(new RegExp(`(?:height|tall|high)\\s*(?:of\\s*)?${MM}`)) ?? p.match(new RegExp(`${MM}\\s*(?:tall|high)`));
      let width: number | undefined, depth: number | undefined, height: number | undefined;
      if (tri) { width = +tri[1]; depth = +tri[2]; height = tri[3] ? +tri[3] : +tri[2]; if (!tri[3]) { depth = +tri[1]; height = +tri[2]; } }
      else {
        const d = dia ? +dia[1] : r ? +r[1] * 2 : size ? +size[1] : undefined;
        width = d; depth = d; height = h ? +h[1] : d;
      }
      const hole = /\bhole\b/.test(p);
      newIdx += 1;
      raw.push({ op: "add_shape", kind, width, depth, height, color: colorWord, hole });
      continue;
    }
    if ((m = p.match(/\b(?:move|shift|nudge|slide)\b.*?\b(left|right|forward|front|backward|back|up|down)\b.*?(-?\d+(?:\.\d+)?)/)) || (m = p.match(/\b(?:move|shift|nudge|slide)\b.*?(-?\d+(?:\.\d+)?)\s*(?:mm)?\s*(left|right|forward|front|backward|back|up|down)\b/))) {
      const [dir, amount] = isNaN(Number(m[1])) ? [m[1], Number(m[2])] : [m[2], Number(m[1])];
      const d = DIR[dir];
      raw.push({ op: "move", ids: target(), dx: (d.dx ?? 0) * amount, dz: (d.dz ?? 0) * amount, dy: (d.dy ?? 0) * amount });
      continue;
    }
    if ((m = p.match(/\b(?:rotate|turn|spin)\b.*?(-?\d+(?:\.\d+)?)\s*(?:°|deg|degrees?)?(?:.*?\b(?:around|about|on)\s*(?:the\s*)?([xyz])\b)?/))) {
      raw.push({ op: "rotate", ids: target(), angle: Number(m[1]), axis: m[2] === "x" ? "x" : m[2] === "y" ? "y" : "z" });
      continue;
    }
    if ((m = p.match(/\b(?:scale|resize|grow|shrink)\b.*?(\d+(?:\.\d+)?)\s*%/)) || (m = p.match(/(\d+(?:\.\d+)?)\s*%\s*(bigger|larger|smaller)/))) {
      let percent = Number(m[1]);
      if (m[2] === "bigger" || m[2] === "larger") percent = 100 + percent;
      if (m[2] === "smaller") percent = 100 - percent;
      raw.push({ op: "scale", ids: target(), percent });
      continue;
    }
    if (/\b(double|twice)\b.*\b(size|big)\b|\bmake (it|them) (twice|double)/.test(p)) { raw.push({ op: "scale", ids: target(), percent: 200 }); continue; }
    if (/\bhalf\b.*\bsize\b|\bhalve\b/.test(p)) { raw.push({ op: "scale", ids: target(), percent: 50 }); continue; }
    if ((m = p.match(/\b(fillet|round(?:ed)?(?: the)? edges?|chamfer|bevel)\b.*?(\d+(?:\.\d+)?)/))) {
      const edges = /\btop\b/.test(p) ? "top" : /\bbottom\b/.test(p) ? "bottom" : /\bvertical\b/.test(p) ? "vertical" : "all";
      raw.push({ op: /chamfer|bevel/.test(m[1]) ? "chamfer" : "fillet", ids: target(), amount: Number(m[2]), edges });
      continue;
    }
    if (/\b(make|turn) (it|them|this|these|selection)? ?(into )?(a )?holes?\b/.test(p)) { raw.push({ op: "hole", ids: target(), hole: true }); continue; }
    if (/\bmake (it|them) solid\b/.test(p)) { raw.push({ op: "hole", ids: target(), hole: false }); continue; }
    const mat = Object.keys(MATERIALS).sort((a, b) => b.length - a.length).find((k) => new RegExp(`\\b${k}\\b`).test(p));
    if (mat && /\b(material|print (it|them) in|use|set|make)\b/.test(p)) { raw.push({ op: "material", ids: target(), material: mat }); continue; }
    if (colorWord && /\b(colou?r|paint|make|turn|set)\b/.test(p)) { raw.push({ op: "color", ids: target(), color: colorWord }); continue; }
    if ((m = p.match(/\b(?:pattern|array|repeat|row of|make)\b.*?(\d+)\s*(?:copies|times|pieces|x)?(?:.*?(\d+(?:\.\d+)?)\s*mm)?/)) && /\b(pattern|array|repeat|row|copies|circle)\b/.test(p)) {
      raw.push({ op: "pattern", ids: target(), mode: /\b(circle|circular|around|radial)\b/.test(p) ? "circle" : "row", count: Number(m[1]), spacing: m[2] ? Number(m[2]) : undefined, direction: /\b(back|forward|depth|y)\b/.test(p) ? "y" : "x" });
      continue;
    }
    if (/\b(duplicate|copy|clone)\b/.test(p)) { raw.push({ op: "duplicate", ids: target() }); continue; }
    if (/\b(group|combine|merge|join|union)\b/.test(p)) { raw.push({ op: "group", ids: target() }); continue; }
    if ((m = p.match(/\balign\b.*?\b(left|right|center|centre|middle|front|back|top|bottom)\b/))) {
      const w = m[1];
      const axis = w === "front" || w === "back" ? "z" : w === "top" || w === "bottom" ? "y" : "x";
      const tgt = w === "left" || w === "back" || w === "bottom" ? "min" : w === "right" || w === "front" || w === "top" ? "max" : "center";
      raw.push({ op: "align", ids: target(), axis, target: tgt });
      continue;
    }
    if (/\b(arrange|distribute|spread|pack)\b/.test(p)) { raw.push({ op: "arrange_plates", ids: target() }); continue; }
    if (/\b(delete|remove|erase)\b/.test(p)) { raw.push({ op: "delete", ids: target() }); continue; }
    return null; // one part not understood: let the caller say so instead of doing half
  }
  if (raw.length === 0) return null;
  const plan = validatePlan({ actions: raw }, ctx);
  const names = new Map(ctx.allShapes.map((s) => [s.id, s.name]));
  plan.summary = plan.actions.map((a) => describeAction(a, names)).join("; ");
  return plan;
}

/* ---------------------------------------------------------------- check my print */

const footprint = (s: AiShapeInfo) => {
  const turned = Math.abs(((s.rotation % 90) + 90) % 90) > 0.5;
  const w = turned ? Math.hypot(s.width, s.depth) : (Math.abs(Math.round(s.rotation / 90)) % 2 ? s.depth : s.width);
  const d = turned ? Math.hypot(s.width, s.depth) : (Math.abs(Math.round(s.rotation / 90)) % 2 ? s.width : s.depth);
  return { minX: s.x - w / 2, maxX: s.x + w / 2, minZ: s.z - d / 2, maxZ: s.z + d / 2, w, d };
};

/** Looks for what usually spoils a print and offers fixes as a plan. `overhangs` comes from the editor's overhang check. */
export function checkPrint(ctx: AiContext, overhangs: { id: string; area: number }[] = []): AiPlan {
  const findings: AiFinding[] = [];
  const actions: AiAction[] = [];
  const solids = ctx.shapes.filter((s) => !s.hole);
  const all = ctx.allShapes.filter((s) => !s.hole);
  for (const s of solids) {
    const f = footprint(s);
    if (f.w > ctx.bed.width || f.d > ctx.bed.depth || s.height > ctx.bed.height) {
      const factor = Math.min(ctx.bed.width / f.w, ctx.bed.depth / f.d, ctx.bed.height / s.height) * 0.95;
      findings.push({ level: "warn", text: `${s.name} (${Math.round(f.w)}×${Math.round(f.d)}×${Math.round(s.height)} mm) is bigger than the ${ctx.bed.width}×${ctx.bed.depth}×${ctx.bed.height} mm build volume.`, ids: [s.id] });
      actions.push({ op: "scale", ids: [s.id], percent: Math.floor(factor * 100) });
      continue;
    }
    const onPlate = ctx.plates.some((p) => f.minX >= p.offsetX - ctx.bed.width / 2 - 0.01 && f.maxX <= p.offsetX + ctx.bed.width / 2 + 0.01 && f.minZ >= p.offsetZ - ctx.bed.depth / 2 - 0.01 && f.maxZ <= p.offsetZ + ctx.bed.depth / 2 + 0.01);
    if (!onPlate) {
      findings.push({ level: "warn", text: `${s.name} is partly or fully off the build plate.`, ids: [s.id] });
      const p = ctx.plates[0];
      actions.push({ op: "move", ids: [s.id], x: Math.max(p.offsetX - ctx.bed.width / 2 + f.w / 2, Math.min(p.offsetX + ctx.bed.width / 2 - f.w / 2, s.x)), z: Math.max(p.offsetZ - ctx.bed.depth / 2 + f.d / 2, Math.min(p.offsetZ + ctx.bed.depth / 2 - f.d / 2, s.z)) });
    }
    if (s.elevation > 0.05) {
      const supported = all.some((o) => o.id !== s.id && Math.abs(o.elevation + o.height - s.elevation) < 0.2 && (() => { const g = footprint(o); return g.minX < f.maxX && g.maxX > f.minX && g.minZ < f.maxZ && g.maxZ > f.minZ; })());
      const touching = all.some((o) => o.id !== s.id && o.elevation < s.elevation + s.height && o.elevation + o.height > s.elevation && (() => { const g = footprint(o); return g.minX < f.maxX && g.maxX > f.minX && g.minZ < f.maxZ && g.maxZ > f.minZ; })());
      if (!supported && !touching) {
        findings.push({ level: "warn", text: `${s.name} floats ${Math.round(s.elevation * 10) / 10} mm above the plate with nothing under it.`, ids: [s.id] });
        actions.push({ op: "move", ids: [s.id], elevation: 0 });
      }
    }
    const thin = Math.min(s.width, s.depth, s.height);
    if (thin < 0.8 && thin > 0) findings.push({ level: "warn", text: `${s.name} is only ${Math.round(thin * 100) / 100} mm thick - thinner than two 0.4 mm lines; it may not print.`, ids: [s.id] });
    if (s.kind === "tube" && Math.min(s.width, s.depth) > 0 && s.width < 2) findings.push({ level: "info", text: `${s.name}: check the tube wall is at least 0.8 mm.`, ids: [s.id] });
  }
  for (const o of overhangs) {
    const s = ctx.shapes.find((x) => x.id === o.id);
    if (s && o.area > 1) findings.push({ level: "info", text: `${s.name} has about ${Math.round(o.area)} mm² of overhang that will need supports (or lay it flat / add a chamfer underneath).`, ids: [s.id] });
  }
  if (findings.length === 0) findings.push({ level: "info", text: `No problems found in ${solids.length} object${solids.length === 1 ? "" : "s"}: all fit the plate, rest on something and are thick enough.`, ids: [] });
  const names = new Map(ctx.allShapes.map((s) => [s.id, s.name]));
  return { summary: actions.length ? `Suggested fixes: ${actions.map((a) => describeAction(a, names)).join("; ")}` : "Nothing to fix automatically.", actions, findings };
}

/* ---------------------------------------------------------------- smart arrange */

/** Shelf-packs the parts onto the plates (biggest first), 5 mm apart; reports how many plates it needs. */
export function arrangeOntoPlates(parts: AiShapeInfo[], bed: { width: number; depth: number }, plateOffsets: (index: number) => { offsetX: number; offsetZ: number }, gap = 5) {
  const items = parts.map((s) => ({ s, f: footprint(s) })).sort((a, b) => b.f.w * b.f.d - a.f.w * a.f.d);
  const moves: { id: string; x: number; z: number; plate: number }[] = [];
  const tooBig: string[] = [];
  let plate = 0, cx = gap, cz = gap, rowH = 0;
  for (const { s, f } of items) {
    if (f.w > bed.width - 2 * gap || f.d > bed.depth - 2 * gap) { tooBig.push(s.id); continue; }
    if (cx + f.w > bed.width - gap) { cx = gap; cz += rowH + gap; rowH = 0; }
    if (cz + f.d > bed.depth - gap) { plate += 1; cx = gap; cz = gap; rowH = 0; }
    const o = plateOffsets(plate);
    moves.push({ id: s.id, x: o.offsetX - bed.width / 2 + cx + f.w / 2, z: o.offsetZ - bed.depth / 2 + cz + f.d / 2, plate });
    cx += f.w + gap; rowH = Math.max(rowH, f.d);
  }
  return { moves, platesNeeded: plate + 1, tooBig };
}

/* ---------------------------------------------------------------- explain (offline) */

export function explainOffline(ctx: AiContext): string {
  if (ctx.shapes.length === 0) return "The view is empty. Try “make a 20mm cube” or pick a shape from the toolbar.";
  const lines = ctx.shapes.slice(0, 12).map((s) => `• ${s.name} — ${s.hole ? "hole " : ""}${s.kind}, ${r1(s.width)}×${r1(s.depth)}×${r1(s.height)} mm at X ${r1(s.x)}, Y ${r1(-s.z)}${s.elevation ? `, ${r1(s.elevation)} mm up` : ""}${s.rotation ? `, turned ${r1(s.rotation)}°` : ""}${s.material ? `, ${s.material}` : ""}`);
  const minX = Math.min(...ctx.shapes.map((s) => footprint(s).minX)), maxX = Math.max(...ctx.shapes.map((s) => footprint(s).maxX));
  const minZ = Math.min(...ctx.shapes.map((s) => footprint(s).minZ)), maxZ = Math.max(...ctx.shapes.map((s) => footprint(s).maxZ));
  const top = Math.max(...ctx.shapes.map((s) => s.elevation + s.height));
  const holes = ctx.shapes.filter((s) => s.hole).length;
  return `${ctx.shapes.length} object${ctx.shapes.length === 1 ? "" : "s"} (${ctx.scope === "area" ? "in the selected area" : ctx.scope === "selection" ? "selected" : "whole design"}), together ${r1(maxX - minX)}×${r1(maxZ - minZ)}×${r1(top)} mm${holes ? `, ${holes} of them hole${holes === 1 ? "" : "s"} that cut the solids they touch when grouped` : ""}.\n${lines.join("\n")}${ctx.shapes.length > 12 ? `\n… and ${ctx.shapes.length - 12} more.` : ""}`;
}
const r1 = (n: number) => String(Math.round(n * 10) / 10);

/* ---------------------------------------------------------------- prompts */

export function systemPrompt(mode: AiMode) {
  return `You are the AI helper inside PrintCaddy, a browser CAD app for 3D printing. Units are millimetres.
Coordinates: x = left/right, z = front/back (positive z is toward the front), elevation = height of the object's bottom above the plate. x and z are the object's centre.
You NEVER write code. You answer with ONE JSON object only:
{"summary": "<one short sentence>", "reply": "<optional text for the user>", "actions": [ ... ]}
Allowed actions (anything else is ignored):
{"op":"add_shape","kind":"box|roundedBox|cylinder|sphere|cone|pyramid|torus|tube|wedge|halfSphere|polygon|star|heart","width":n,"depth":n,"height":n,"x":n,"z":n,"elevation":n,"color":"#rrggbb","name":"...","hole":bool}
{"op":"move","ids":[...],"dx":n,"dy":n,"dz":n} or with absolute "x","z","elevation"
{"op":"rotate","ids":[...],"angle":deg,"axis":"z|x|y"}   (z = about the vertical)
{"op":"scale","ids":[...],"percent":n}
{"op":"resize","ids":[...],"width":n,"depth":n,"height":n}
{"op":"color","ids":[...],"color":"#rrggbb"}
{"op":"material","ids":[...],"material":"pla|petg|abs|asa|tpu|pc"}
{"op":"fillet"|"chamfer","ids":[...],"amount":mm,"edges":"all|top|bottom|vertical"}
{"op":"hole","ids":[...],"hole":true|false}
{"op":"group","ids":[...]}   (combines; holes cut the solids)
{"op":"duplicate","ids":[...]}
{"op":"pattern","ids":[...],"mode":"row|circle","count":n,"spacing":mm,"direction":"x|y"}
{"op":"align","ids":[...],"axis":"x|y|z","target":"min|center|max"}
{"op":"arrange_plates","ids":[...]}
{"op":"delete","ids":[...]}
Refer to existing objects by their id. Shapes you add in this plan are "new1", "new2", ... in order. Omit ids to use the objects in context.
${mode === "explain" ? "The user wants an explanation: put it in \"reply\" and leave actions empty unless they asked for a change." : mode === "check" ? "Check the design for 3D-printing problems (overhangs, thin walls < 0.8 mm, parts off the plate or too big, floating parts) and put fixes in actions." : mode === "arrange" ? "Distribute the parts across the build plates with arrange_plates." : "Turn the request into actions. Build multi-part models from several add_shape steps and group them."}`;
}

export function userPrompt(text: string, ctx: AiContext) {
  const shapes = ctx.shapes.slice(0, 60).map((s) => ({ id: s.id, name: s.name, kind: s.kind, hole: s.hole || undefined, x: rd(s.x), z: rd(s.z), elevation: rd(s.elevation), width: rd(s.width), depth: rd(s.depth), height: rd(s.height), rotation: rd(s.rotation) || undefined, color: s.color }));
  return `Context (${ctx.scope}): ${JSON.stringify(shapes)}
Build volume: ${ctx.bed.width}×${ctx.bed.depth}×${ctx.bed.height} mm, plate 1 centred at x=0,z=0, ${ctx.plates.length} plate(s).
Request: ${text}`;
}
const rd = (n: number) => Math.round(n * 100) / 100;

/** Pulls the first JSON object out of a model's answer (models like to wrap it in prose or ```json). */
export function extractJson(text: string): unknown {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  const body = fenced ? fenced[1] : text;
  const start = body.indexOf("{");
  if (start < 0) return null;
  let depth = 0, inStr = false, esc = false;
  for (let i = start; i < body.length; i++) {
    const c = body[i];
    if (inStr) { if (esc) esc = false; else if (c === "\\") esc = true; else if (c === "\"") inStr = false; continue; }
    if (c === "\"") inStr = true; else if (c === "{") depth++; else if (c === "}" && --depth === 0) {
      try { return JSON.parse(body.slice(start, i + 1)); } catch { return null; }
    }
  }
  return null;
}

/* ---------------------------------------------------------------- callers */

type Msg = { role: "system" | "user" | "assistant"; content: string };

/** OpenAI-compatible chat completions (xAI, OpenAI, OpenRouter, Ollama ...), straight from the browser. */
export async function callOpenAiCompatible(s: AiSettings, system: string, user: string, image?: string, signal?: AbortSignal): Promise<string> {
  const content = image && s.vision ? [{ type: "text", text: user }, { type: "image_url", image_url: { url: image } }] : user;
  const res = await fetch(`${s.baseUrl.replace(/\/+$/, "")}/chat/completions`, {
    method: "POST",
    signal,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${s.apiKey.trim()}` },
    body: JSON.stringify({ model: s.model, temperature: 0.2, messages: [{ role: "system", content: system }, { role: "user", content }] }),
  });
  if (!res.ok) throw new Error(`The AI service answered ${res.status}: ${(await res.text().catch(() => "")).slice(0, 200)}`);
  const json = await res.json();
  return String(json?.choices?.[0]?.message?.content ?? "");
}

/** Anthropic Messages API, straight from the browser (needs Anthropic's direct-browser-access header). */
export async function callAnthropic(s: AiSettings, system: string, user: string, image?: string, signal?: AbortSignal): Promise<string> {
  const content: unknown[] = [{ type: "text", text: user }];
  if (image && s.vision) {
    const m = image.match(/^data:(image\/\w+);base64,(.*)$/);
    if (m) content.unshift({ type: "image", source: { type: "base64", media_type: m[1], data: m[2] } });
  }
  const res = await fetch(`${s.baseUrl.replace(/\/+$/, "")}/messages`, {
    method: "POST",
    signal,
    headers: { "Content-Type": "application/json", "x-api-key": s.apiKey.trim(), "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
    body: JSON.stringify({ model: s.model, max_tokens: 2000, system, messages: [{ role: "user", content }] }),
  });
  if (!res.ok) throw new Error(`The AI service answered ${res.status}: ${(await res.text().catch(() => "")).slice(0, 200)}`);
  const json = await res.json();
  return (json?.content ?? []).map((c: { text?: string }) => c.text ?? "").join("");
}

/* ---------------------------------------------------------------- on-device (WebLLM) */

export const WEBLLM_URL = "https://esm.run/@mlc-ai/web-llm@0.2.79";

export function webGpuAvailable() {
  return typeof navigator !== "undefined" && "gpu" in navigator;
}

type Engine = { chat: { completions: { create: (req: unknown) => Promise<{ choices: { message: { content: string } }[] }> } } };
let engine: { model: string; engine: Engine } | null = null;
let loading: Promise<Engine> | null = null;

export function localModelLoaded(model: string) {
  return engine?.model === model;
}

/** Loads the on-device model on first use (only after the user agreed); the browser caches it afterwards. */
export async function loadLocalModel(model: string, onProgress: (p: { progress: number; text: string }) => void): Promise<Engine> {
  if (engine?.model === model) return engine.engine;
  if (!webGpuAvailable()) throw new Error("This browser has no WebGPU, so the on-device model cannot run here.");
  const adapter = await (navigator as unknown as { gpu: { requestAdapter: () => Promise<{ features?: Set<string> } | null> } }).gpu.requestAdapter();
  if (!adapter) throw new Error("WebGPU is switched on but no graphics adapter is available.");
  if (!loading) {
    loading = (async () => {
      const webllm = await import(/* webpackIgnore: true */ WEBLLM_URL as string) as { CreateMLCEngine: (m: string, o: unknown) => Promise<Engine> };
      // GPUs without 16-bit shader support (some Android/PC GPUs, software renderers) need the f32 build.
      const runId = adapter.features?.has("shader-f16") ? model : model.replace("q4f16_1", "q4f32_1");
      const e = await webllm.CreateMLCEngine(runId, { initProgressCallback: (r: { progress: number; text: string }) => onProgress(r) });
      engine = { model, engine: e };
      return e;
    })().finally(() => { loading = null; });
  }
  return loading;
}

export async function callLocal(model: string, system: string, user: string, onProgress: (p: { progress: number; text: string }) => void): Promise<string> {
  const e = await loadLocalModel(model, onProgress);
  const messages: Msg[] = [{ role: "system", content: system }, { role: "user", content: user }];
  const out = await e.chat.completions.create({ messages, temperature: 0.1, max_tokens: 1200, response_format: { type: "json_object" } });
  return out.choices?.[0]?.message?.content ?? "";
}

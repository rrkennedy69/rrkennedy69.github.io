/**
 * Hands a Bambu-ready 3MF to Bambu Studio without uploading it anywhere.
 *
 * Bambu Studio's URL handlers (bambustudio://open?file=<url> on Windows/Linux, bambustudioopen://<url> on macOS)
 * only accept a public https URL that the app downloads itself, and current builds only accept MakerWorld URLs.
 * A blob: URL never reaches the app, so the protocol cannot work for a file made in the browser. Instead:
 *  - iPad / phones: the system share sheet with the file (navigator.share), falling back to a download;
 *  - desktop: a download, opened in Bambu Studio by double-click or drag-in (.3mf is associated with it on install).
 */
export type BambuHandoff = { method: "share" | "download" | "cancelled"; message: string };

export function isTouchDevice() {
  if (typeof navigator === "undefined") return false;
  const ua = navigator.userAgent;
  const iPadOs = /Macintosh/.test(ua) && navigator.maxTouchPoints > 1;
  return iPadOs || /iPad|iPhone|iPod|Android|Mobile/i.test(ua);
}

function download(file: File) {
  const url = URL.createObjectURL(file);
  const a = document.createElement("a");
  a.href = url; a.download = file.name; a.style.display = "none";
  document.body.appendChild(a); a.click(); a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export async function handOffToBambu(bytes: Uint8Array, fileName: string): Promise<BambuHandoff> {
  const file = new File([bytes as BlobPart], fileName, { type: "application/vnd.ms-package.3dmanufacturing-3dmodel+xml" });
  if (isTouchDevice() && typeof navigator.share === "function" && navigator.canShare?.({ files: [file] })) {
    try {
      await navigator.share({ files: [file], title: fileName });
      return { method: "share", message: `Shared ${fileName}. Pick Bambu Handy / Bambu Studio, or "Save to Files" and open it in Bambu Studio.` };
    } catch (e) {
      if (e instanceof DOMException && e.name === "AbortError") return { method: "cancelled", message: "Sharing cancelled - nothing was sent." };
      // NotAllowedError (the tap was too long ago) or anything else: fall through to a download.
    }
  }
  download(file);
  return { method: "download", message: `Downloaded ${fileName}. Open it in Bambu Studio (double-click or drag in) - your plates, colours, filaments and slice settings are in it.` };
}

/**
 * Ruler guides on the build plate: laser lines set from the X or Y plate ruler. Kept per design beside it in the
 * browser and in a `.lyl` file, like the framing square; never in the undo history.
 * `axis` is the ruler it came from: an "x" guide sits at an X position and runs along Y, and the other way round.
 * `position` is millimetres from the ruler's zero (the plate's front-left corner).
 */
export type PlateGuide = { axis: "x" | "y"; position: number };

const PREFIX = "printcaddy.plateGuides.";
export const PLATE_GUIDES_EVENT = "printcaddy-plate-guides";

export function normalizePlateGuides(value: unknown): PlateGuide[] | null {
  if (!Array.isArray(value)) return null;
  const guides = value
    .filter((g): g is PlateGuide => !!g && typeof g === "object" && (g.axis === "x" || g.axis === "y") && typeof g.position === "number" && Number.isFinite(g.position))
    .map((g) => ({ axis: g.axis, position: g.position }));
  return guides.length ? guides : null;
}

export function readPlateGuides(projectId: string | null | undefined): PlateGuide[] {
  if (!projectId) return [];
  try {
    const stored = window.localStorage.getItem(PREFIX + projectId);
    return (stored ? normalizePlateGuides(JSON.parse(stored)) : null) ?? [];
  } catch {
    return [];
  }
}

export function writePlateGuides(projectId: string | null | undefined, guides: readonly PlateGuide[] | null) {
  if (!projectId) return;
  try {
    const kept = normalizePlateGuides(guides ?? null);
    if (kept) window.localStorage.setItem(PREFIX + projectId, JSON.stringify(kept));
    else window.localStorage.removeItem(PREFIX + projectId);
  } catch { /* session only */ }
}

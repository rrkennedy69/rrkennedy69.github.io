// In-browser slicing with CuraEngine compiled to WebAssembly (cura-wasm, AGPL-3.0). The engine (~4 MB)
// is only fetched the first time someone slices, and it runs in its own Web Worker.
export type SlicerPresetId = "draft" | "standard" | "fine";
export type SliceSettings = {
  layerHeight: number;
  infill: number;
  walls: number;
  supports: boolean;
  adhesion: "skirt" | "brim" | "none";
};
export const SLICER_PRESETS: Record<SlicerPresetId, { label: string; layerHeight: number; walls: number; infill: number }> = {
  draft: { label: "Draft 0.28 mm", layerHeight: 0.28, walls: 2, infill: 10 },
  standard: { label: "Standard 0.20 mm", layerHeight: 0.2, walls: 2, infill: 15 },
  fine: { label: "Fine 0.12 mm", layerHeight: 0.12, walls: 3, infill: 15 },
};

export type MaterialTemps = { type: string; nozzle: number; bed: number; density: number; fan: number };
const TEMPS: Record<string, Omit<MaterialTemps, "type">> = {
  PLA: { nozzle: 220, bed: 55, density: 1.24, fan: 100 },
  PETG: { nozzle: 250, bed: 70, density: 1.27, fan: 40 },
  PET: { nozzle: 260, bed: 70, density: 1.3, fan: 30 },
  ABS: { nozzle: 260, bed: 100, density: 1.04, fan: 10 },
  ASA: { nozzle: 260, bed: 100, density: 1.07, fan: 10 },
  TPU: { nozzle: 230, bed: 35, density: 1.21, fan: 60 },
  PC: { nozzle: 270, bed: 110, density: 1.2, fan: 10 },
  PA: { nozzle: 280, bed: 100, density: 1.12, fan: 0 },
  PVA: { nozzle: 220, bed: 55, density: 1.23, fan: 50 },
};
export function materialTemps(type: string | undefined): MaterialTemps {
  const key = (type ?? "PLA").toUpperCase();
  const hit = Object.keys(TEMPS).find((k) => key === k) ?? Object.keys(TEMPS).find((k) => key.startsWith(k)) ?? "PLA";
  return { type: hit, ...TEMPS[hit] };
}

/** Moves the (Z-up, binary) STL so it stands centred on the bed: x/y around 0, lowest point at z 0. */
export function centerStl(buffer: ArrayBuffer) {
  const view = new DataView(buffer);
  const count = view.getUint32(80, true);
  const min = [Infinity, Infinity, Infinity];
  const max = [-Infinity, -Infinity, -Infinity];
  for (let t = 0; t < count; t++) for (let v = 0; v < 3; v++) for (let a = 0; a < 3; a++) {
    const value = view.getFloat32(84 + t * 50 + 12 + v * 12 + a * 4, true);
    if (value < min[a]) min[a] = value;
    if (value > max[a]) max[a] = value;
  }
  const shift = [-(min[0] + max[0]) / 2, -(min[1] + max[1]) / 2, -min[2]];
  for (let t = 0; t < count; t++) for (let v = 0; v < 3; v++) for (let a = 0; a < 3; a++) {
    const offset = 84 + t * 50 + 12 + v * 12 + a * 4;
    view.setFloat32(offset, view.getFloat32(offset, true) + shift[a], true);
  }
  return { size: [max[0] - min[0], max[1] - min[1], max[2] - min[2]] as [number, number, number], triangles: count };
}

export type ParsedGcode = {
  /** Extrusion segments, xyz pairs (Y-up for three.js: x, z, -y), in print order. */
  positions: Float32Array;
  colors: Float32Array;
  /** Vertex count at the end of each layer. */
  layerEnds: number[];
  layerZ: number[];
  filamentMm: number;
};
const TYPE_COLORS: Record<string, [number, number, number]> = {
  "WALL-OUTER": [0.93, 0.45, 0.13], "WALL-INNER": [0.95, 0.75, 0.2], SKIN: [0.85, 0.25, 0.3], FILL: [0.65, 0.3, 0.75],
  SUPPORT: [0.3, 0.75, 0.55], "SUPPORT-INTERFACE": [0.2, 0.6, 0.45], SKIRT: [0.4, 0.6, 0.9], PRIME_TOWER: [0.5, 0.5, 0.5],
};
export function parseGcode(text: string): ParsedGcode {
  const pos: number[] = [];
  const col: number[] = [];
  const layerEnds: number[] = [];
  const layerZ: number[] = [];
  let x = 0, y = 0, z = 0, e = 0, relE = false, inLayer = false, color = TYPE_COLORS["WALL-OUTER"], filament = 0;
  for (const raw of text.split("\n")) {
    if (raw.startsWith(";LAYER:")) {
      if (inLayer) { layerEnds.push(pos.length / 3); layerZ.push(z); }
      inLayer = true;
      continue;
    }
    if (raw.startsWith(";TYPE:")) { color = TYPE_COLORS[raw.slice(6).trim()] ?? [0.7, 0.7, 0.7]; continue; }
    if (raw.startsWith("M83")) relE = true; else if (raw.startsWith("M82")) relE = false;
    const isMove = raw.startsWith("G1 ") || raw.startsWith("G0 ");
    const isReset = raw.startsWith("G92");
    if (!isMove && !isReset) continue;
    let nx = x, ny = y, nz = z, ne: number | null = null;
    for (const word of raw.split(";")[0].split(" ")) {
      const v = Number(word.slice(1));
      switch (word[0]) {
        case "X": nx = v; break;
        case "Y": ny = v; break;
        case "Z": nz = v; break;
        case "E": ne = v; break;
      }
    }
    if (isReset) { if (ne !== null) e = ne; continue; }
    const de = ne === null ? 0 : relE ? ne : ne - e;
    if (ne !== null && !relE) e = ne;
    if (de > 0) filament += de;
    if (inLayer && de > 0 && (nx !== x || ny !== y)) {
      pos.push(x, z, -y, nx, nz, -ny);
      col.push(...color, ...color);
    }
    x = nx; y = ny; z = nz;
  }
  if (inLayer) { layerEnds.push(pos.length / 3); layerZ.push(z); }
  return { positions: new Float32Array(pos), colors: new Float32Array(col), layerEnds, layerZ, filamentMm: filament };
}

export type SliceResult = { gcode: string; printTimeSec: number; filamentMm: number; filamentG: number; parsed: ParsedGcode };

let definitionPromise: Promise<unknown> | null = null;

export async function sliceStl(
  stl: ArrayBuffer,
  bed: { width: number; depth: number; height: number },
  settings: SliceSettings,
  material: MaterialTemps,
  onProgress: (percent: number) => void,
  basePath = "",
): Promise<SliceResult> {
  definitionPromise ??= fetch(`${basePath}/cura-custom-definition.json`).then((r) => {
    if (!r.ok) throw new Error("Could not load the slicer printer definition");
    return r.json();
  });
  const [{ CuraWASM }, definition] = await Promise.all([import("cura-wasm"), definitionPromise]);
  const s = (key: string, value: string | number | boolean, scope?: "e0"): { key: string; value: string; scope?: "e0" } => (scope ? { scope, key, value: String(value) } : { key, value: String(value) });
  const lh = settings.layerHeight;
  const overrides = [
    s("machine_width", bed.width), s("machine_depth", bed.depth), s("machine_height", bed.height),
    s("machine_center_is_zero", true), s("machine_heated_bed", true),
    s("material_diameter", 1.75, "e0"), s("machine_nozzle_size", 0.4, "e0"),
    s("layer_height", lh), s("layer_height_0", Math.max(0.2, lh)),
    s("wall_line_count", settings.walls), s("infill_sparse_density", settings.infill),
    s("top_layers", Math.ceil(0.8 / lh)), s("bottom_layers", Math.ceil(0.6 / lh)),
    s("support_enable", settings.supports), s("support_type", "buildplate"), s("support_angle", 50),
    s("adhesion_type", settings.adhesion),
    s("material_print_temperature", material.nozzle), s("material_print_temperature_layer_0", material.nozzle),
    s("material_bed_temperature", material.bed), s("material_bed_temperature_layer_0", material.bed),
    s("cool_fan_speed", material.fan), s("cool_fan_enabled", material.fan > 0),
    s("speed_print", 100), s("retraction_enable", true), s("retraction_amount", 0.8),
  ];
  // CuraEngine reads many settings per extruder, so each is set globally and again on extruder 0.
  // cura-wasm passes them in order and every -s after "-e0" belongs to that extruder, so globals go first.
  const globals = overrides.filter((o) => !o.scope);
  const scoped = [...globals, ...overrides.filter((o) => o.scope), ...globals.map((o) => ({ ...o, scope: "e0" as const }))];
  const slicer = new CuraWASM({ definition: definition as never, overrides: scoped as never, transfer: true, verbose: false });
  slicer.on("progress", (p: number) => onProgress(p));
  try {
    const { gcode, metadata } = await slicer.slice(stl, "stl");
    const parsed = parseGcode(new TextDecoder().decode(gcode));
    const filamentMm = parsed.filamentMm;
    const text = new TextDecoder().decode(gcode)
      .replace(/^;TIME:\d+/m, `;TIME:${Math.round(Number((metadata as { printTime?: number } | null)?.printTime) || 0)}`)
      .replace(/^;Filament used: .*$/m, `;Filament used: ${(filamentMm / 1000).toFixed(4)}m`)
      .replace(/^;Generated with Cura_SteamEngine/m, ";Sliced in PrintCaddy with CuraEngine (cura-wasm, AGPL-3.0)\n;Generated with Cura_SteamEngine");
    const volume = filamentMm * Math.PI * 0.875 ** 2;
    return { gcode: text, printTimeSec: Number((metadata as { printTime?: number } | null)?.printTime) || 0, filamentMm, filamentG: (volume / 1000) * material.density, parsed };
  } finally {
    void slicer.destroy();
  }
}

export function formatDuration(sec: number) {
  const h = Math.floor(sec / 3600);
  const m = Math.round((sec % 3600) / 60);
  return h > 0 ? `${h} h ${m} min` : `${m} min`;
}

/** The panel's settings as Bambu Studio / OrcaSlicer process keys, carried into the exported 3MF project. */
export function bambuProcessOverrides(settings: SliceSettings): Record<string, string> {
  const lh = settings.layerHeight;
  return {
    layer_height: String(lh),
    sparse_infill_density: `${settings.infill}%`,
    wall_loops: String(settings.walls),
    top_shell_layers: String(Math.ceil(0.8 / lh)),
    bottom_shell_layers: String(Math.ceil(0.6 / lh)),
    enable_support: settings.supports ? "1" : "0",
    support_type: "tree(auto)",
    brim_type: settings.adhesion === "brim" ? "outer_only" : "no_brim",
    skirt_loops: settings.adhesion === "skirt" ? "1" : "0",
  };
}

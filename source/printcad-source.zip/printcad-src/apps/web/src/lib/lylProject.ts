import { checkedTypefaceData, customFontName, isCustomFontId, textCharacters, typefaceSubset } from "@/lib/customFonts";
import { customFontEntry, registerCustomFont } from "@/lib/textFonts";
import { strFromU8, strToU8, unzip } from "fflate";
import { boundedProjectZip } from "@/lib/boundedProjectZip";
import { editorHistoryEntry, hydrateEditorHistoryState, type EditorHistoryEntry } from "@/lib/editorHistory";
import { normalizePlacementWorkplane, placementWorkplaneIsBase, type PlacementWorkplane } from "@/lib/placementWorkplane";
import { importedShapeFromObj } from "@/lib/objImport";
import { normalizeProjectAsset, sha256Hex } from "@/lib/projectAssets";
import { canonicalizeShape } from "@/lib/workplaneShapes";
import { normalizeSketchStroke, SKETCH_STROKE_JOINS } from "@/lib/sketchStroke";
import { normalizeTextEdge } from "@/lib/textEdge";
import { isTextKeyring } from "@/lib/textGeometry";
import { normalizeNotes } from "@/lib/workplaneNotes";
import {
  attachmentListProblem,
  attachmentProblemText,
  attachmentTypeForFileName,
  attachmentTypeForMediaType,
  attachmentsFormatVersion,
} from "@/lib/projectAttachments";
import { normalizeQrSettings } from "@/lib/qrCode";
import { importedShapeFromStl } from "@/lib/stlImport";
import { importedShapeFromSvg } from "@/lib/svgImport";
import { importedShapeFrom3mf } from "@/lib/threemfImport";
import { normalizeDesignView, normalizeSavedViews, readDesignView, readSavedViews, type DesignView, type SavedDesignViews } from "@/lib/designView";
import { normalizeSavedCornerRulers, readCornerRulers, type SavedCornerRuler } from "@/lib/cornerRulerStore";
import { normalizeSavedTape, readTape, type SavedTape } from "@/lib/tapeStore";
import { isSketchKeyring } from "@/lib/sketchKeyring";
import { isReferenceImageOpacity } from "@/lib/referenceImage";
import { isThreadProfile } from "@/lib/threadProfiles";
import { normalizeSnapGrid, normalizeWorkspaceSettings } from "@/lib/workplaneSettings";
import type { CadDisplayEdge, GridSize, ProjectAsset, ProjectAssetSourceFormat, ProjectAttachment, SketchOperation, SketchRevolveSettings, WorkplaneNote, WorkplaneShape, WorkplaneWorkspaceSettings } from "@/types/layerling";

export const LYL_SCHEMA_ID = "com.layerling.project";
/** Written before the rename. Such a package is still opened - and saved back
 *  as a .lyl file with the current identifier. */
export const LEGACY_LYL_SCHEMA_ID = "com.sketchforge.project";

function knownSchema(schema: unknown) {
  return schema === LYL_SCHEMA_ID || schema === LEGACY_LYL_SCHEMA_ID;
}
// Version 2 stores display edges as deduplicated archive assets instead of repeating
// them inside every undo state. Version 1 packages are still read and migrated.
// This is the version a design is written with, unless it has attachments.
export const LYL_FORMAT_VERSION = 2;
export const LYL_MINIMUM_READER_VERSION = 2;
// Version 3 adds the files a design carries (#820). It is written only for a design that has
// some, so every other design stays a version 2 file, and a layerling that knows version 2 only
// refuses a version 3 package instead of opening it and dropping the files at its next save.
export const LYL_ATTACHMENTS_FORMAT_VERSION = 3;
// Version 4 adds attachment types beyond text (pictures and PDF, #820). A layerling that reads
// version 3 refuses a package with a type it does not know, so a design with such a file is written
// as version 4 and an older layerling says the design needs a newer one. A design whose attachments
// are all text stays a version 3 file. Which version each type needs is the `formatVersion` column
// of ATTACHMENT_TYPES in projectAttachments.ts.
export const LYL_FILE_TYPES_FORMAT_VERSION = 4;
/** The newest format this layerling reads. */
export const LYL_NEWEST_READABLE_FORMAT_VERSION = LYL_FILE_TYPES_FORMAT_VERSION;
export const LYL_OLDEST_READABLE_FORMAT_VERSION = 1;
export const LYL_CREATED_WITH_VERSION = "1.120.0";
export const LYL_MEDIA_TYPE = "application/vnd.layerling.project+zip";

export const LYL_LIMITS = {
  archiveBytes: 512 * 1024 * 1024,
  expandedBytes: 1024 * 1024 * 1024,
  projectJsonBytes: 64 * 1024 * 1024,
  assetBytes: 256 * 1024 * 1024,
  entries: 4096,
  states: 5001,
  objectsPerState: 100_000,
  features: 300_000,
  meshNumbers: 30_000_000,
  displayEdgeNumbers: 30_000_000,
} as const;

const SHAPE_KINDS = new Set([
  "box", "roundedBox", "cylinder", "slot", "ellipse", "sphere", "sketch", "scribble", "cone", "pyramid", "roof", "text", "roundRoof",
  "halfSphere", "paraboloid", "torus", "tube", "bentTube", "star", "heart", "crescent", "gear", "honeycomb", "hinge", "knurl", "dovetail", "counterbore", "countersink", "doubleCountersink", "teardrop", "loft", "vase", "thread", "spring", "gridfinity", "ring", "wedge", "polygon", "icosahedron", "ruler", "mesh",
]);

const FEATURE_TYPES = new Set([
  "group", "boolean-subtraction", "boolean-intersection", "mirror", "sketch-extrusion", "sketch-revolve", "sketch-sweep", "fillet", "chamfer", "chamfillet", "shell", "delete-face", "offset",
]);

type LylAssetKind = "source" | "derived-mesh" | "brep" | "image" | "display-edges" | "attachment";

const LYL_ASSET_KINDS: readonly LylAssetKind[] = ["source", "derived-mesh", "brep", "image", "display-edges", "attachment"];

/** A file the design carries: its name, and the asset that holds its bytes (two names may share one asset). */
export type LylAttachmentV3 = { id: string; fileName: string; assetId: string };

export type LylAssetRecordV1 = {
  id: string;
  kind: LylAssetKind;
  path: string;
  mediaType: string;
  byteLength: number;
  sha256: string;
  fileName?: string;
  sourceFormat?: ProjectAssetSourceFormat;
};

export type LylImportedMeshReferenceV1 = {
  sourceAssetId?: string;
  meshAssetId?: string;
  brepStepAssetId?: string;
  baseWidth: number;
  baseDepth: number;
  baseHeight: number;
  triangleCount: number;
  sourceFormat: NonNullable<WorkplaneShape["importedMesh"]>["sourceFormat"];
};

export type LylShapeNodeV1 = {
  nodeId: string;
  objectId: string;
  objectType: "native" | "imported" | "group" | "sketch";
  workplaneId: string;
  definition: Record<string, unknown>;
  importedMesh?: LylImportedMeshReferenceV1;
  groupedShapeNodeIds?: string[];
  edgeTreatmentHistory?: Array<{
    id: string;
    createdAt: number;
    feature: Record<string, unknown>;
    appliedFrame?: Record<string, unknown>;
    beforeNodeId: string;
  }>;
  cadBrepAssetId?: string;
  // Format version 2 and later. Version 1 nodes keep their display edges inline
  // in `definition.cadDisplayEdges`.
  cadDisplayEdgesAssetId?: string;
};

export type LylStateV1 = {
  id: string;
  rootNodeIds: string[];
  nodes: LylShapeNodeV1[];
  /**
   * Die Notizen dieses Standes. Sie sind kein Koerper und stehen deshalb neben
   * den Knoten, nicht darin. Ein aelterer Leser uebergeht das Feld - er oeffnet
   * die Datei, zeigt aber keine Notizen und schreibt sie beim naechsten Sichern
   * auch nicht zurueck.
   */
  notes?: WorkplaneNote[];
};

export type LylFeatureV1 = {
  id: string;
  type: string;
  outputObjectId: string;
  inputObjectIds: string[];
  dependsOnFeatureIds: string[];
  parameters?: Record<string, unknown>;
};

export type LylFontV1 = { id: string; name: string; typeface: unknown };

/** At most this many fonts of one's own travel with a design. */
const LYL_MAX_FONTS = 64;

/**
 * The letters each font of one's own needs in these states: every character of every text that
 * uses it, in every undo state, so going back in the history still finds its letters.
 */
function embeddedFonts(states: WorkplaneShape[][]): LylFontV1[] {
  const characters = new Map<string, Set<string>>();
  const visit = (shape: WorkplaneShape) => {
    if (isCustomFontId(shape.font) && shape.kind === "text") {
      const used = characters.get(shape.font) ?? new Set<string>();
      const glyphs = customFontEntry(shape.font)?.data.glyphs as Record<string, unknown> | undefined;
      textCharacters((shape.text ?? "TEXT").trim() || " ", glyphs).forEach((character) => used.add(character));
      characters.set(shape.font, used);
    }
    shape.groupedShapes?.forEach(visit);
  };
  states.forEach((shapes) => shapes.forEach(visit));
  const fonts: LylFontV1[] = [];
  for (const [id, used] of characters) {
    const entry = customFontEntry(id);
    if (entry) fonts.push({ id, name: entry.name, typeface: typefaceSubset(entry.data, used) });
  }
  return fonts.sort((a, b) => a.id.localeCompare(b.id)).slice(0, LYL_MAX_FONTS);
}

function validateFonts(fonts: unknown) {
  if (fonts === undefined) return [] as Array<{ id: string; name: string; data: ReturnType<typeof checkedTypefaceData> }>;
  if (!Array.isArray(fonts) || fonts.length > LYL_MAX_FONTS) throw new Error("project.json has an invalid font list");
  return fonts.map((raw, index) => {
    const font = objectRecord(raw, `fonts[${index}]`);
    if (!isCustomFontId(font.id)) throw new Error(`fonts[${index}].id is invalid`);
    const name = customFontName(stringValue(font.name, `fonts[${index}].name`), "Font");
    return { id: font.id, name, data: checkedTypefaceData(font.typeface, `fonts[${index}].typeface`) };
  });
}

export type LylProjectDocumentV1 = {
  schema: typeof LYL_SCHEMA_ID | typeof LEGACY_LYL_SCHEMA_ID;
  formatVersion: 1 | 2 | 3 | 4;
  minimumReaderVersion: number;
  createdWithVersion: string;
  metadata: {
    projectId?: string;
    projectName: string;
    units: string;
    createdAt: string;
    modifiedAt: string;
  };
  assets: LylAssetRecordV1[];
  sceneStateId: string;
  states: LylStateV1[];
  history: {
    entries: Array<{
      stateId: string;
      selectedObjectIds: string[];
      workplane?: PlacementWorkplane;
      /** When the state was recorded, ISO 8601. States from before this field exists have none. */
      recordedAt?: string;
    }>;
    index: number;
  };
  sketches: Array<{ id: string; nodeId: string; objectId: string; operation?: SketchOperation; extrusionDepth: number; revolve?: SketchRevolveSettings }>;
  features: LylFeatureV1[];
  groups: Array<{ id: string; nodeId: string; objectId: string; memberNodeIds: string[]; operation: string }>;
  workplanes: Array<{ id: string; kind: "base" | "offset"; elevation: number }>;
  exactCad: Array<{ nodeId: string; objectId: string; brepAssetId?: string; importedStepAssetId?: string }>;
  /** The files kept with the design (#820), in the order they are listed; a version 3 package only. */
  attachments?: LylAttachmentV3[];
  /**
   * Fonts of one's own the texts use (#customFonts): only the letters they use, as outlines in the
   * three.js typeface format - never the font file. Older readers pass over them and draw those
   * texts in the default font.
   */
  fonts?: LylFontV1[];
  editor: {
    workspace: WorkplaneWorkspaceSettings;
    snapGrid: GridSize;
    selectedWorkplaneId: string;
    placementElevation: number;
    placementWorkplane?: PlacementWorkplane;
    sketchPlacementWorkplane?: PlacementWorkplane;
    /** Where the camera looked when the design was saved (#220); older readers pass over it. */
    view?: DesignView;
    /** The views saved under 7, 8, 9 and 0, null where a slot is empty; older readers pass over them. */
    savedViews?: SavedDesignViews;
    /** The framing square where it was set (#829); older readers pass over it. */
    cornerRulers?: SavedCornerRuler[];
    /** The tape measure's measurements and whether they are shown (#881); older readers pass over it. */
    tapeMeasurements?: SavedTape;
  };
};

export type LylProjectExportInput = {
  projectId?: string | null;
  projectName: string;
  createdAt: number;
  modifiedAt: number;
  shapes: WorkplaneShape[];
  notes?: WorkplaneNote[];
  history: EditorHistoryEntry[];
  historyIndex: number;
  assets: ProjectAsset[];
  /** The files kept with the design (#820). A design with any is written as a version 3 package. */
  attachments?: ProjectAttachment[];
  workspace: WorkplaneWorkspaceSettings;
  snapGrid: GridSize;
  placementElevation: number;
  placementWorkplane?: PlacementWorkplane;
  sketchPlacementWorkplane?: PlacementWorkplane;
  /** The camera's view; when left out, the one the browser keeps for this design goes in. */
  view?: DesignView | null;
  /** The views saved under 7 to 0; when left out, the ones the browser keeps for this design go in. */
  savedViews?: SavedDesignViews | null;
  /** The framing square; when left out, the one the browser keeps for this design goes in (#829). */
  cornerRulers?: SavedCornerRuler[] | null;
  /** The tape measure's measurements; when left out, the ones the browser keeps for this design go in (#881). */
  tapeMeasurements?: SavedTape | null;
  compressionLevel?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;
  /** Weitere Dateien im Paket, etwa der Fehlerbericht; ein Leser uebergeht sie. */
  extraFiles?: Record<string, Uint8Array>;
};

export type LylRestoredProject = {
  sourceProjectId?: string;
  projectName: string;
  createdAt: number;
  modifiedAt: number;
  shapes: WorkplaneShape[];
  notes?: WorkplaneNote[];
  history: EditorHistoryEntry[];
  historyIndex: number;
  assets: ProjectAsset[];
  /** The files the design carried, when the file has any. */
  attachments?: ProjectAttachment[];
  workspace: WorkplaneWorkspaceSettings;
  snapGrid: GridSize;
  placementElevation: number;
  placementWorkplane: PlacementWorkplane;
  sketchPlacementWorkplane: PlacementWorkplane;
  /** The view the design was saved in, when the file has one. */
  view?: DesignView;
  /** The views saved under 7 to 0, when the file has any. */
  savedViews?: SavedDesignViews;
  /** The framing square, when the file has one (#829). */
  cornerRulers?: SavedCornerRuler[];
  /** The tape measure's measurements, when the file has them (#881). */
  tapeMeasurements?: SavedTape;
  migratedFromVersion?: number;
  /** Set when a newer layerling saved the design: its version, for a hint that an update helps. */
  savedWithNewerVersion?: string;
};

export type LylProjectPackageSummary = {
  projectName: string;
  createdAt: number;
  modifiedAt: number;
  formatVersion: number;
};

export type LylSourceImporter = (asset: ProjectAsset) => Promise<NonNullable<WorkplaneShape["importedMesh"]>>;

export type ImportLylOptions = {
  sourceImporter?: LylSourceImporter;
};

type ArchiveFiles = Record<string, Uint8Array>;

function exactArrayBuffer(bytes: Uint8Array) {
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
}

function finiteNumber(value: unknown, label: string) {
  if (typeof value !== "number" || !Number.isFinite(value)) throw new Error(`${label} must be a finite number`);
  return value;
}

function safeTimestamp(value: number, fallback: number) {
  return Number.isFinite(value) && value > 0 ? value : fallback;
}

function safeIsoTimestamp(value: number, fallback: number) {
  return new Date(safeTimestamp(value, fallback)).toISOString();
}

function parseIsoTimestamp(value: unknown, label: string) {
  if (typeof value !== "string") throw new Error(`${label} is missing`);
  const parsed = Date.parse(value);
  if (!Number.isFinite(parsed)) throw new Error(`${label} is invalid`);
  return parsed;
}

function safeNodeToken(value: string) {
  return encodeURIComponent(value).replace(/%/g, "~");
}

function safeArchivePath(path: string) {
  return Boolean(path)
    && !path.startsWith("/")
    && !path.startsWith("\\")
    && !/^[a-z]:/i.test(path)
    && !path.includes("\\")
    && path.split("/").every((part) => part && part !== "." && part !== "..");
}

function extensionForAsset(kind: LylAssetKind, mediaType: string, sourceFormat?: ProjectAssetSourceFormat) {
  if (kind === "source" && sourceFormat) return sourceFormat === "step" ? "step" : sourceFormat;
  if (kind === "derived-mesh") return "lylmesh";
  if (kind === "display-edges") return "lyledges";
  if (kind === "brep") return "brep";
  if (kind === "attachment") return attachmentTypeForMediaType(mediaType)?.extension ?? "bin";
  if (mediaType.includes("png")) return "png";
  if (mediaType.includes("jpeg")) return "jpg";
  if (mediaType.includes("webp")) return "webp";
  if (mediaType.includes("svg")) return "svg";
  if (mediaType.includes("gif")) return "gif";
  return "bin";
}

function encodeMeshCache(mesh: NonNullable<WorkplaneShape["importedMesh"]>) {
  if (mesh.positions.length > LYL_LIMITS.meshNumbers || (mesh.normals?.length ?? 0) > LYL_LIMITS.meshNumbers) {
    throw new Error("Imported mesh is too large for a layerling project file");
  }
  const normalLength = mesh.normals?.length ?? 0;
  const bytes = new Uint8Array(16 + (mesh.positions.length + normalLength) * 8);
  bytes.set(strToU8("LYLMSH1\0"), 0);
  const view = new DataView(bytes.buffer);
  view.setUint32(8, mesh.positions.length, true);
  view.setUint32(12, normalLength, true);
  let offset = 16;
  for (const value of mesh.positions) {
    if (!Number.isFinite(value)) throw new Error("Imported mesh contains an invalid coordinate");
    view.setFloat64(offset, value, true);
    offset += 8;
  }
  for (const value of mesh.normals ?? []) {
    if (!Number.isFinite(value)) throw new Error("Imported mesh contains an invalid normal");
    view.setFloat64(offset, value, true);
    offset += 8;
  }
  return bytes;
}

function decodeMeshCache(bytes: Uint8Array) {
  if (bytes.byteLength < 16 || !["LYLMSH1\0", "SKFMSH1\0"].includes(strFromU8(bytes.subarray(0, 8)))) {
    throw new Error("A derived mesh asset has an invalid header");
  }
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const positionLength = view.getUint32(8, true);
  const normalLength = view.getUint32(12, true);
  if (positionLength > LYL_LIMITS.meshNumbers || normalLength > LYL_LIMITS.meshNumbers) {
    throw new Error("A derived mesh asset exceeds the supported coordinate limit");
  }
  const expected = 16 + (positionLength + normalLength) * 8;
  if (expected !== bytes.byteLength) throw new Error("A derived mesh asset is truncated or malformed");
  const positions = new Array<number>(positionLength);
  const normals = normalLength ? new Array<number>(normalLength) : undefined;
  let offset = 16;
  for (let index = 0; index < positionLength; index += 1) {
    positions[index] = view.getFloat64(offset, true);
    offset += 8;
  }
  for (let index = 0; index < normalLength; index += 1) {
    (normals as number[])[index] = view.getFloat64(offset, true);
    offset += 8;
  }
  return { positions, normals };
}

function encodeDisplayEdges(edges: CadDisplayEdge[]) {
  let numbers = 0;
  for (const edge of edges) {
    if (!Array.isArray(edge?.points)) throw new Error("A display edge is missing its point list");
    numbers += edge.points.length;
  }
  if (numbers > LYL_LIMITS.displayEdgeNumbers) throw new Error("Display edges are too large for a layerling project file");
  const bytes = new Uint8Array(16 + edges.length * 4 + numbers * 8);
  bytes.set(strToU8("LYLEDG1\0"), 0);
  const view = new DataView(bytes.buffer);
  view.setUint32(8, edges.length, true);
  view.setUint32(12, numbers, true);
  let offset = 16 + edges.length * 4;
  edges.forEach((edge, index) => {
    view.setUint32(16 + index * 4, edge.points.length, true);
    for (const value of edge.points) {
      if (!Number.isFinite(value)) throw new Error("A display edge contains an invalid coordinate");
      view.setFloat64(offset, value, true);
      offset += 8;
    }
  });
  return bytes;
}

function decodeDisplayEdges(bytes: Uint8Array): CadDisplayEdge[] {
  if (bytes.byteLength < 16 || !["LYLEDG1\0", "SKFEDG1\0"].includes(strFromU8(bytes.subarray(0, 8)))) {
    throw new Error("A display edge asset has an invalid header");
  }
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const edgeCount = view.getUint32(8, true);
  const numbers = view.getUint32(12, true);
  if (numbers > LYL_LIMITS.displayEdgeNumbers) throw new Error("A display edge asset exceeds the supported coordinate limit");
  if (bytes.byteLength !== 16 + edgeCount * 4 + numbers * 8) throw new Error("A display edge asset is truncated or malformed");
  const edges = new Array<CadDisplayEdge>(edgeCount);
  let offset = 16 + edgeCount * 4;
  let counted = 0;
  for (let index = 0; index < edgeCount; index += 1) {
    const length = view.getUint32(16 + index * 4, true);
    counted += length;
    if (counted > numbers) throw new Error("A display edge asset is truncated or malformed");
    const points = new Array<number>(length);
    for (let point = 0; point < length; point += 1) {
      points[point] = view.getFloat64(offset, true);
      offset += 8;
    }
    edges[index] = { points };
  }
  if (counted !== numbers) throw new Error("A display edge asset is truncated or malformed");
  return edges;
}

function decodeDataUrl(dataUrl: string) {
  const match = dataUrl.match(/^data:([^;,]+)?(;base64)?,([\s\S]*)$/);
  if (!match) throw new Error("Embedded image has an invalid data URL");
  const mediaType = match[1] || "application/octet-stream";
  if (match[2]) {
    const binary = globalThis.atob(match[3].replace(/\s/g, ""));
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
    return { mediaType, bytes };
  }
  return { mediaType, bytes: strToU8(decodeURIComponent(match[3])) };
}

function bytesToDataUrl(bytes: Uint8Array, mediaType: string) {
  let binary = "";
  for (let offset = 0; offset < bytes.length; offset += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(offset, Math.min(bytes.length, offset + 0x8000)));
  }
  return `data:${mediaType};base64,${globalThis.btoa(binary)}`;
}

type EncodedAssetPayload = { bytes: Uint8Array; sha256: string };

// Encoding and hashing a resource is the most expensive part of an autosave, and
// shapes keep the same immutable mesh, edge, and asset objects across every undo
// state. Keying the result on the resource itself means an unchanged resource is
// encoded and hashed exactly once, no matter how many states reference it or how
// often the project is saved again.
const encodedAssetPayloads = new WeakMap<object, Promise<EncodedAssetPayload>>();

function encodedAssetPayload(resource: object, encode: () => Uint8Array) {
  const cached = encodedAssetPayloads.get(resource);
  if (cached) return cached;
  const pending = (async () => {
    try {
      const bytes = encode();
      return { bytes, sha256: await sha256Hex(bytes) };
    } catch (error) {
      encodedAssetPayloads.delete(resource);
      throw error;
    }
  })();
  encodedAssetPayloads.set(resource, pending);
  return pending;
}

// The exact-CAD text of a body (its B-rep) is a string, which a WeakMap cannot
// key, yet every undo state of an unchanged body carries the very same string.
// Without this each state encoded and hashed it again on every autosave. The
// cache is small and keeps the most recently used few.
const TEXT_PAYLOAD_CACHE_LIMIT = 6;
const encodedTextPayloads = new Map<string, Promise<EncodedAssetPayload>>();

function encodedTextPayload(text: string) {
  const cached = encodedTextPayloads.get(text);
  if (cached) {
    encodedTextPayloads.delete(text);
    encodedTextPayloads.set(text, cached);
    return cached;
  }
  const pending = (async () => {
    try {
      const bytes = strToU8(text);
      return { bytes, sha256: await sha256Hex(bytes) };
    } catch (error) {
      encodedTextPayloads.delete(text);
      throw error;
    }
  })();
  encodedTextPayloads.set(text, pending);
  while (encodedTextPayloads.size > TEXT_PAYLOAD_CACHE_LIMIT) {
    const oldest = encodedTextPayloads.keys().next();
    if (oldest.done) break;
    encodedTextPayloads.delete(oldest.value);
  }
  return pending;
}

const STATES_PLACEHOLDER = "@@layerling-states-placeholder-7f3a1c@@";

/** The serialized text of a history state and the assets it used, remembered per history entry. */
const serializedStateCache = new WeakMap<object, {
  stateId: string;
  sourceKey: string;
  json: string;
  used: Array<{ record: LylAssetRecordV1; bytes: Uint8Array }>;
}>();

class LylArchiveBuilder {
  readonly files: ArchiveFiles = {};
  readonly assets: LylAssetRecordV1[] = [];
  readonly sourceIdMap = new Map<string, string>();
  private readonly recordByKindAndHash = new Map<string, LylAssetRecordV1>();
  private recorded: Array<{ record: LylAssetRecordV1; bytes: Uint8Array }> | null = null;

  /** Runs `work` and returns which assets it registered, so a later save can register them again without redoing the work. */
  async recording<T>(work: () => Promise<T>) {
    const previous = this.recorded;
    const used: Array<{ record: LylAssetRecordV1; bytes: Uint8Array }> = [];
    this.recorded = used;
    try {
      return { result: await work(), used };
    } finally {
      this.recorded = previous;
    }
  }

  /** Registers assets that a remembered state used; the first registration of an asset wins, as when it is made fresh. */
  adopt(used: Array<{ record: LylAssetRecordV1; bytes: Uint8Array }>) {
    for (const { record, bytes } of used) {
      const key = `${record.kind}:${record.sha256}`;
      if (this.recordByKindAndHash.has(key)) continue;
      this.files[record.path] = bytes;
      this.assets.push(record);
      this.recordByKindAndHash.set(key, record);
    }
  }

  private registerAsset(
    kind: LylAssetKind,
    payload: EncodedAssetPayload,
    mediaType: string,
    options: { fileName?: string; sourceFormat?: ProjectAssetSourceFormat },
  ) {
    const { bytes, sha256 } = payload;
    if (bytes.byteLength > LYL_LIMITS.assetBytes) throw new Error(`${options.fileName ?? kind} exceeds the per-asset size limit`);
    const key = `${kind}:${sha256}`;
    const existing = this.recordByKindAndHash.get(key);
    if (existing) {
      this.recorded?.push({ record: existing, bytes: this.files[existing.path] ?? bytes });
      return existing;
    }
    const extension = extensionForAsset(kind, mediaType, options.sourceFormat);
    const id = `${kind}-${sha256.slice(0, 32)}`;
    const path = `assets/${kind}/${sha256}.${extension}`;
    const record: LylAssetRecordV1 = {
      id,
      kind,
      path,
      mediaType,
      byteLength: bytes.byteLength,
      sha256,
      ...(options.fileName ? { fileName: options.fileName } : {}),
      ...(options.sourceFormat ? { sourceFormat: options.sourceFormat } : {}),
    };
    this.files[path] = bytes;
    this.assets.push(record);
    this.recordByKindAndHash.set(key, record);
    this.recorded?.push({ record, bytes });
    return record;
  }

  async addAsset(
    kind: LylAssetKind,
    bytes: Uint8Array,
    mediaType: string,
    options: { fileName?: string; sourceFormat?: ProjectAssetSourceFormat } = {},
  ) {
    return this.registerAsset(kind, { bytes, sha256: await sha256Hex(bytes) }, mediaType, options);
  }

  async addTextAsset(kind: LylAssetKind, text: string, mediaType: string) {
    return this.registerAsset(kind, await encodedTextPayload(text), mediaType, {});
  }

  private async addCachedAsset(
    resource: object,
    kind: LylAssetKind,
    encode: () => Uint8Array,
    mediaType: string,
    options: { fileName?: string; sourceFormat?: ProjectAssetSourceFormat } = {},
  ) {
    return this.registerAsset(kind, await encodedAssetPayload(resource, encode), mediaType, options);
  }

  async addSources(assets: ProjectAsset[], referencedIds: Set<string>) {
    const referenced = assets
      .filter((asset) => referencedIds.has(asset.id))
      .sort((a, b) => a.id.localeCompare(b.id));
    for (const asset of referenced) {
      const options = { fileName: asset.name, sourceFormat: asset.sourceFormat };
      const encode = () => normalizeProjectAsset(asset).bytes;
      const source: object | null = typeof asset.bytes === "object" && asset.bytes !== null ? asset.bytes : null;
      const record = source
        ? await this.addCachedAsset(source, "source", encode, asset.mediaType, options)
        : await this.addAsset("source", encode(), asset.mediaType, options);
      this.sourceIdMap.set(asset.id, record.id);
    }
  }

  /**
   * Registers the files a design carries and lists each under its own name. Bytes that are the same
   * are stored once, and hashed once however often the design is saved, as the sources are.
   */
  async addAttachments(attachments: readonly ProjectAttachment[]) {
    const records: LylAttachmentV3[] = [];
    for (const attachment of attachments) {
      const asset = await this.addCachedAsset(attachment.bytes, "attachment", () => attachment.bytes, attachment.mediaType);
      records.push({ id: attachment.id, fileName: attachment.name, assetId: asset.id });
    }
    return records;
  }

  addDerivedMesh(mesh: NonNullable<WorkplaneShape["importedMesh"]>) {
    return this.addCachedAsset(mesh, "derived-mesh", () => encodeMeshCache(mesh), "application/vnd.layerling.mesh");
  }

  addDisplayEdges(edges: CadDisplayEdge[]) {
    return this.addCachedAsset(edges, "display-edges", () => encodeDisplayEdges(edges), "application/vnd.layerling.edges");
  }
}

function assertUniqueRuntimeObjectIds(shapes: WorkplaneShape[], stateLabel: string) {
  const ids = new Set<string>();
  const visit = (shape: WorkplaneShape) => {
    if (!shape.id || ids.has(shape.id)) throw new Error(`${stateLabel} contains duplicate object ID '${shape.id || "(empty)"}'`);
    ids.add(shape.id);
    shape.groupedShapes?.forEach(visit);
  };
  shapes.forEach(visit);
}

function repairDuplicateGroupedObjectIds(shapes: WorkplaneShape[]) {
  const rootIds = new Set<string>();
  for (const shape of shapes) {
    if (!shape.id || rootIds.has(shape.id)) {
      throw new Error(`Project state contains duplicate root object ID '${shape.id || "(empty)"}'`);
    }
    rootIds.add(shape.id);
  }

  const reservedIds = new Set<string>();
  const collectIds = (shape: WorkplaneShape) => {
    if (shape.id) reservedIds.add(shape.id);
    shape.groupedShapes?.forEach(collectIds);
  };
  shapes.forEach(collectIds);

  const seenIds = new Set(rootIds);
  let repairedIndex = 0;
  const freshRepairId = (shape: WorkplaneShape) => {
    let candidate = "";
    do {
      repairedIndex += 1;
      candidate = `${shape.kind || "object"}-repaired-${repairedIndex}`;
    } while (reservedIds.has(candidate) || seenIds.has(candidate));
    reservedIds.add(candidate);
    return candidate;
  };

  const repairChild = (shape: WorkplaneShape): WorkplaneShape => {
    const id = shape.id && !seenIds.has(shape.id) ? shape.id : freshRepairId(shape);
    seenIds.add(id);
    const groupedShapes = shape.groupedShapes?.map(repairChild);
    const childrenChanged = groupedShapes?.some((child, index) => child !== shape.groupedShapes?.[index]) ?? false;
    if (id === shape.id && !childrenChanged) {
      return shape;
    }
    return { ...shape, id, ...(groupedShapes ? { groupedShapes } : {}) };
  };

  return shapes.map((shape) => {
    const groupedShapes = shape.groupedShapes?.map(repairChild);
    const childrenChanged = groupedShapes?.some((child, index) => child !== shape.groupedShapes?.[index]) ?? false;
    return childrenChanged ? { ...shape, groupedShapes } : shape;
  });
}

function referencedSourceAssetIds(states: WorkplaneShape[][]) {
  const ids = new Set<string>();
  const visit = (shape: WorkplaneShape) => {
    if (shape.importedMesh?.assetId) ids.add(shape.importedMesh.assetId);
    shape.groupedShapes?.forEach(visit);
    shape.edgeTreatmentHistory?.forEach((entry) => visit(entry.before));
  };
  states.flat().forEach(visit);
  return ids;
}

async function serializeShapeNode(
  shape: WorkplaneShape,
  nodeId: string,
  nodes: LylShapeNodeV1[],
  builder: LylArchiveBuilder,
  sourceAssetsByArchiveId: Map<string, LylAssetRecordV1>,
): Promise<string> {
  const {
    importedMesh,
    groupedShapes,
    edgeTreatmentHistory,
    cadBrep,
    imagePlate,
    sketchProfile,
    cadDisplayEdges,
    ...baseDefinition
  } = canonicalizeShape(shape);
  const definition: Record<string, unknown> = { ...baseDefinition };
  // Display edges are the largest part of a CAD object and stay identical across
  // undo states, so they live in a deduplicated asset instead of in every state.
  const cadDisplayEdgesAssetId = cadDisplayEdges?.length ? (await builder.addDisplayEdges(cadDisplayEdges)).id : undefined;
  if (cadDisplayEdges && !cadDisplayEdges.length) definition.cadDisplayEdges = [];

  if (imagePlate) {
    const { dataUrl, ...plateDefinition } = imagePlate;
    const decoded = decodeDataUrl(dataUrl);
    const asset = await builder.addAsset("image", decoded.bytes, decoded.mediaType, { fileName: `${shape.name}-image` });
    definition.imagePlate = { ...plateDefinition, assetId: asset.id };
  }

  if (sketchProfile) {
    const images = await Promise.all((sketchProfile.images ?? []).map(async (image) => {
      const { dataUrl, ...imageDefinition } = image;
      const decoded = decodeDataUrl(dataUrl);
      const asset = await builder.addAsset("image", decoded.bytes, decoded.mediaType, { fileName: image.name });
      return { ...imageDefinition, assetId: asset.id };
    }));
    definition.sketchProfile = {
      points: sketchProfile.points,
      segments: sketchProfile.segments,
      ...(images.length ? { images } : {}),
      ...(sketchProfile.stroke ? { stroke: sketchProfile.stroke } : {}),
      ...(sketchProfile.silhouette ? { silhouette: true } : {}),
      ...(sketchProfile.keyring ? { keyring: sketchProfile.keyring } : {}),
      ...(sketchProfile.inset ? { inset: sketchProfile.inset } : {}),
      ...(sketchProfile.sweepAnchor && sketchProfile.sweepAnchor !== "center" ? { sweepAnchor: sketchProfile.sweepAnchor } : {}),
    };
  }

  let importedReference: LylImportedMeshReferenceV1 | undefined;
  if (importedMesh) {
    const archiveSourceId = importedMesh.assetId ? builder.sourceIdMap.get(importedMesh.assetId) : undefined;
    const archiveSource = archiveSourceId ? sourceAssetsByArchiveId.get(archiveSourceId) : undefined;
    const canRegenerate = Boolean(
      archiveSource
      && importedMesh.sourceFormat !== "json"
      && archiveSource?.sourceFormat === importedMesh.sourceFormat,
    );
    let meshAssetId: string | undefined;
    let brepStepAssetId: string | undefined;
    if (!canRegenerate) {
      meshAssetId = (await builder.addDerivedMesh(importedMesh)).id;
      if (importedMesh.brepStep) {
        brepStepAssetId = (await builder.addTextAsset("brep", importedMesh.brepStep, "application/step")).id;
      }
    }
    importedReference = {
      ...(canRegenerate && archiveSourceId ? { sourceAssetId: archiveSourceId } : {}),
      ...(meshAssetId ? { meshAssetId } : {}),
      ...(brepStepAssetId ? { brepStepAssetId } : {}),
      baseWidth: importedMesh.baseWidth,
      baseDepth: importedMesh.baseDepth,
      baseHeight: importedMesh.baseHeight,
      triangleCount: importedMesh.triangleCount,
      sourceFormat: importedMesh.sourceFormat,
    };
  }

  let cadBrepAssetId: string | undefined;
  if (cadBrep) cadBrepAssetId = (await builder.addTextAsset("brep", cadBrep, "application/vnd.layerling.brep")).id;

  const groupedShapeNodeIds: string[] = [];
  for (const child of groupedShapes ?? []) {
    const childNodeId = `${nodeId}/group/${safeNodeToken(child.id)}`;
    groupedShapeNodeIds.push(await serializeShapeNode(child, childNodeId, nodes, builder, sourceAssetsByArchiveId));
  }

  const serializedEdgeHistory: NonNullable<LylShapeNodeV1["edgeTreatmentHistory"]> = [];
  for (const entry of edgeTreatmentHistory ?? []) {
    const beforeNodeId = `${nodeId}/edge/${safeNodeToken(entry.id)}/before`;
    await serializeShapeNode(entry.before, beforeNodeId, nodes, builder, sourceAssetsByArchiveId);
    serializedEdgeHistory.push({
      id: entry.id,
      createdAt: entry.createdAt,
      feature: { ...entry.feature },
      ...(entry.appliedFrame ? { appliedFrame: { ...entry.appliedFrame } } : {}),
      beforeNodeId,
    });
  }

  const objectType = groupedShapeNodeIds.length
    ? "group"
    : sketchProfile
      ? "sketch"
    : importedReference
      ? "imported"
      : shape.kind === "sketch"
        ? "sketch"
        : "native";
  nodes.push({
    nodeId,
    objectId: shape.id,
    objectType,
    workplaneId: "base",
    definition,
    ...(importedReference ? { importedMesh: importedReference } : {}),
    ...(groupedShapeNodeIds.length ? { groupedShapeNodeIds } : {}),
    ...(serializedEdgeHistory.length ? { edgeTreatmentHistory: serializedEdgeHistory } : {}),
    ...(cadBrepAssetId ? { cadBrepAssetId } : {}),
    ...(cadDisplayEdgesAssetId ? { cadDisplayEdgesAssetId } : {}),
  });
  return nodeId;
}

async function serializeState(
  id: string,
  shapes: WorkplaneShape[],
  builder: LylArchiveBuilder,
  sourceAssetsByArchiveId: Map<string, LylAssetRecordV1>,
  notes: WorkplaneNote[] = [],
): Promise<LylStateV1> {
  assertUniqueRuntimeObjectIds(shapes, id);
  const nodes: LylShapeNodeV1[] = [];
  const rootNodeIds: string[] = [];
  for (const shape of shapes) {
    const nodeId = `${id}/object/${safeNodeToken(shape.id)}`;
    rootNodeIds.push(await serializeShapeNode(shape, nodeId, nodes, builder, sourceAssetsByArchiveId));
  }
  nodes.sort((a, b) => a.nodeId.localeCompare(b.nodeId));
  const state: LylStateV1 = { id, rootNodeIds, nodes };
  if (notes.length > 0) state.notes = notes;
  return state;
}

function nodeGroupOperation(node: LylShapeNodeV1, nodeById: Map<string, LylShapeNodeV1>) {
  if (node.definition.groupOperation === "intersection") return "boolean-intersection";
  if (node.definition.groupOperation === "bundle") return "group";
  // A hull keeps its parts as a group does; the operation itself travels in the definition (#863).
  if (node.definition.groupOperation === "hull" || node.definition.groupOperation === "loft") return "group";
  const children = (node.groupedShapeNodeIds ?? []).map((id) => nodeById.get(id)).filter(Boolean) as LylShapeNodeV1[];
  const hasHole = children.some((child) => child.definition.hole === true);
  const hasSolid = children.some((child) => child.definition.hole !== true);
  return hasHole && hasSolid ? "boolean-subtraction" : "group";
}

function activeProjectIndexes(state: LylStateV1) {
  const nodeById = new Map(state.nodes.map((node) => [node.nodeId, node]));
  const features: LylFeatureV1[] = [];
  const groups: LylProjectDocumentV1["groups"] = [];
  const sketches: LylProjectDocumentV1["sketches"] = [];
  const exactCad: LylProjectDocumentV1["exactCad"] = [];
  const lastFeatureByNode = new Map<string, string>();
  const visited = new Set<string>();

  const visit = (nodeId: string) => {
    if (visited.has(nodeId)) return;
    visited.add(nodeId);
    const node = nodeById.get(nodeId);
    if (!node) return;
    (node.groupedShapeNodeIds ?? []).forEach(visit);
    let previous: string | undefined;
    if (node.definition.sketchProfile) {
      const operation = node.definition.sketchOperation === "revolve" ? "revolve" : node.definition.sketchOperation === "sweep" ? "sweep" : "extrude";
      const featureType = operation === "revolve" ? "sketch-revolve" : operation === "sweep" ? "sketch-sweep" : "sketch-extrusion";
      const featureId = `feature/${safeNodeToken(node.nodeId)}/${featureType}`;
      features.push({
        id: featureId,
        type: featureType,
        outputObjectId: node.objectId,
        inputObjectIds: [],
        dependsOnFeatureIds: [],
        parameters: operation === "revolve"
          ? { ...(node.definition.sketchRevolve as Record<string, unknown> | undefined), axis: "vertical-sketch-axis", mode: "create" }
          : operation === "sweep"
            ? { path: "construction-line", mode: "create" }
            : { depth: node.definition.height, direction: "positive-y", mode: "create" },
      });
      sketches.push({
        id: `sketch/${safeNodeToken(node.objectId)}`,
        nodeId: node.nodeId,
        objectId: node.objectId,
        operation,
        extrusionDepth: operation === "extrude" ? Number(node.definition.height) : 0,
        ...(operation === "revolve" && node.definition.sketchRevolve ? { revolve: node.definition.sketchRevolve as SketchRevolveSettings } : {}),
      });
      previous = featureId;
    }
    if (node.groupedShapeNodeIds?.length) {
      const operation = nodeGroupOperation(node, nodeById);
      const featureId = `feature/${safeNodeToken(node.nodeId)}/${operation}`;
      const dependencies = node.groupedShapeNodeIds.flatMap((childId) => {
        const dependency = lastFeatureByNode.get(childId);
        return dependency ? [dependency] : [];
      });
      features.push({
        id: featureId,
        type: operation,
        outputObjectId: node.objectId,
        inputObjectIds: node.groupedShapeNodeIds.map((childId) => nodeById.get(childId)?.objectId ?? ""),
        dependsOnFeatureIds: dependencies,
      });
      groups.push({
        id: `group/${safeNodeToken(node.objectId)}`,
        nodeId: node.nodeId,
        objectId: node.objectId,
        memberNodeIds: [...node.groupedShapeNodeIds],
        operation,
      });
      previous = featureId;
    }
    const treatments = Array.isArray(node.definition.edgeTreatments) ? node.definition.edgeTreatments as Array<Record<string, unknown>> : [];
    treatments.forEach((treatment, index) => {
      const type = treatment.kind === "fillet" || treatment.kind === "chamfillet" || treatment.kind === "shell" || treatment.kind === "offset" ? treatment.kind : treatment.kind === "deleteFace" ? "delete-face" : "chamfer";
      const featureId = `feature/${safeNodeToken(node.nodeId)}/${type}/${index}`;
      features.push({
        id: featureId,
        type,
        outputObjectId: node.objectId,
        inputObjectIds: [node.objectId],
        dependsOnFeatureIds: previous ? [previous] : [],
        parameters: { ...treatment },
      });
      previous = featureId;
    });
    if (node.definition.mirrorX || node.definition.mirrorY || node.definition.mirrorZ) {
      const featureId = `feature/${safeNodeToken(node.nodeId)}/mirror`;
      features.push({
        id: featureId,
        type: "mirror",
        outputObjectId: node.objectId,
        inputObjectIds: [node.objectId],
        dependsOnFeatureIds: previous ? [previous] : [],
        parameters: { x: Boolean(node.definition.mirrorX), y: Boolean(node.definition.mirrorY), z: Boolean(node.definition.mirrorZ) },
      });
      previous = featureId;
    }
    if (previous) lastFeatureByNode.set(node.nodeId, previous);
    if (node.cadBrepAssetId || node.importedMesh?.sourceAssetId && node.importedMesh.sourceFormat === "step") {
      exactCad.push({
        nodeId: node.nodeId,
        objectId: node.objectId,
        ...(node.cadBrepAssetId ? { brepAssetId: node.cadBrepAssetId } : {}),
        ...(node.importedMesh?.sourceAssetId && node.importedMesh.sourceFormat === "step" ? { importedStepAssetId: node.importedMesh.sourceAssetId } : {}),
      });
    }
  };
  state.rootNodeIds.forEach(visit);
  return { features, groups, sketches, exactCad };
}

function zipAsync(files: ArchiveFiles, level: NonNullable<LylProjectExportInput["compressionLevel"]> = 6, stored?: ReadonlySet<string>) {
  return boundedProjectZip(files, level, stored);
}

function unzipAsync(bytes: Uint8Array) {
  return new Promise<ArchiveFiles>((resolve, reject) => {
    unzip(bytes, (error, files) => {
      if (error) reject(error);
      else resolve(files);
    });
  });
}

/** Only the project.json of a package, or nothing when it cannot be read; the rest stays packed. */
function unzipProjectJson(bytes: Uint8Array) {
  return new Promise<Uint8Array | null>((resolve) => {
    try {
      inspectZipBeforeExpansion(bytes);
    } catch {
      resolve(null);
      return;
    }
    unzip(bytes, { filter: (file) => file.name === "project.json" }, (error, files) => {
      resolve(error ? null : files["project.json"] ?? null);
    });
  });
}

function packagedLylProjectName(projectJson: Uint8Array | null) {
  if (!projectJson) return null;
  try {
    const name = (JSON.parse(strFromU8(projectJson)) as { metadata?: { projectName?: unknown } } | null)?.metadata?.projectName;
    return typeof name === "string" ? name : null;
  } catch {
    return null;
  }
}

export async function exportLylProject(input: LylProjectExportInput) {
  const placementElevation = Number.isFinite(input.placementElevation) ? input.placementElevation : 0;
  const placementWorkplane = normalizePlacementWorkplane(input.placementWorkplane, placementElevation);
  const hydrated = hydrateEditorHistoryState(input.shapes, input.history, input.historyIndex, "unlimited", normalizeNotes(input.notes), placementWorkplane);
  if (hydrated.entries.length > LYL_LIMITS.states) throw new Error("Project has too many undo states for the project format");
  const exportEntries = hydrated.entries.map((entry) => {
    const repaired = repairDuplicateGroupedObjectIds(entry.shapes);
    // `hydrated` entries are already canonical and fingerprinted; only a state that
    // needed an ID repair has to be measured again.
    const idsWereRepaired = repaired.some((shape, index) => shape !== entry.shapes[index]);
    return idsWereRepaired ? editorHistoryEntry(repaired, entry.selectedIds, normalizeNotes(entry.notes), entry.placementWorkplane) : entry;
  });
  const builder = new LylArchiveBuilder();
  const stateShapes = exportEntries.map((entry) => entry.shapes);
  const designFonts = embeddedFonts(stateShapes);
  await builder.addSources(input.assets, referencedSourceAssetIds(stateShapes));
  // The files of the design (#820) become assets of the kind "attachment", and the document lists them
  // below under their own names. The list is checked first with what a reader would check, so a
  // package that would not open again is never written.
  const attachments = input.attachments ?? [];
  const attachmentProblem = attachmentListProblem(attachments);
  if (attachmentProblem) throw new Error(attachmentProblemText(attachmentProblem.problem, attachmentProblem.fileName));
  const attachmentRecords = await builder.addAttachments(attachments);
  const sourceAssetsByArchiveId = new Map(builder.assets.filter((asset) => asset.kind === "source").map((asset) => [asset.id, asset]));
  // A state is serialized once and its text remembered on its history entry: the
  // states of an unchanged history come out the same on every save, and a long
  // history of a design with many bodies took most of a second to rebuild.
  const sourceKey = [...builder.sourceIdMap].map(([id, archiveId]) => `${id}>${archiveId}`).join(",")
    + "|" + [...sourceAssetsByArchiveId].map(([id, record]) => `${id}:${record.sourceFormat ?? ""}`).join(",");
  const stateTexts: string[] = [];
  const freshStates = new Map<string, LylStateV1>();
  const stateIdByFingerprint = new Map<string, string>();
  const historyEntries: LylProjectDocumentV1["history"]["entries"] = [];

  for (const entry of exportEntries) {
    let stateId = stateIdByFingerprint.get(entry.fingerprint);
    if (!stateId) {
      stateId = `state-${stateTexts.length + 1}`;
      const cached = serializedStateCache.get(entry);
      if (cached && cached.stateId === stateId && cached.sourceKey === sourceKey) {
        builder.adopt(cached.used);
        stateTexts.push(cached.json);
      } else {
        const { result: state, used } = await builder.recording(() => serializeState(stateId as string, entry.shapes, builder, sourceAssetsByArchiveId, normalizeNotes(entry.notes)));
        const json = JSON.stringify(state);
        serializedStateCache.set(entry, { stateId, sourceKey, json, used });
        freshStates.set(stateId, state);
        stateTexts.push(json);
      }
      stateIdByFingerprint.set(entry.fingerprint, stateId);
    }
    historyEntries.push({
      stateId,
      selectedObjectIds: [...entry.selectedIds],
      ...(entry.placementWorkplane ? { workplane: entry.placementWorkplane } : {}),
      ...(typeof entry.at === "number" && Number.isFinite(entry.at) ? { recordedAt: new Date(entry.at).toISOString() } : {}),
    });
  }

  const sceneStateId = historyEntries[hydrated.index]?.stateId;
  const activeStateIndex = sceneStateId ? Number(sceneStateId.slice("state-".length)) - 1 : -1;
  const activeState = sceneStateId && stateTexts[activeStateIndex] !== undefined
    ? (freshStates.get(sceneStateId) ?? (JSON.parse(stateTexts[activeStateIndex]) as LylStateV1))
    : undefined;
  if (!activeState) throw new Error("Could not identify the active project state");
  const indexes = activeProjectIndexes(activeState);
  const now = Date.now();
  const sketchPlacementWorkplane = normalizePlacementWorkplane(input.sketchPlacementWorkplane);
  const view = input.view === undefined ? readDesignView(input.projectId) : normalizeDesignView(input.view);
  const savedViews = normalizeSavedViews(input.savedViews === undefined ? readSavedViews(input.projectId) : input.savedViews);
  const cornerRulers = normalizeSavedCornerRulers(input.cornerRulers === undefined ? readCornerRulers(input.projectId) : input.cornerRulers);
  const tapeMeasurements = normalizeSavedTape(input.tapeMeasurements === undefined ? readTape(input.projectId) : input.tapeMeasurements);
  const selectedWorkplaneId = placementWorkplaneIsBase(placementWorkplane) ? "workplane-base" : "workplane-active";
  const document: Omit<LylProjectDocumentV1, "states"> & { states: typeof STATES_PLACEHOLDER } = {
    schema: LYL_SCHEMA_ID,
    // Only a design that has attachments is a version 3 package, or version 4 when one of them is of a
    // type that came with version 4: a layerling that does not know them refuses it (see
    // LYL_ATTACHMENTS_FORMAT_VERSION and LYL_FILE_TYPES_FORMAT_VERSION) instead of dropping the files
    // at its next save. Every other design is written exactly as before.
    formatVersion: attachmentsFormatVersion(attachments) ?? LYL_FORMAT_VERSION,
    minimumReaderVersion: attachmentsFormatVersion(attachments) ?? LYL_MINIMUM_READER_VERSION,
    createdWithVersion: LYL_CREATED_WITH_VERSION,
    metadata: {
      ...(input.projectId ? { projectId: input.projectId } : {}),
      projectName: input.projectName.trim() || "layerling design",
      units: normalizeWorkspaceSettings(input.workspace).units,
      createdAt: safeIsoTimestamp(input.createdAt, now),
      modifiedAt: safeIsoTimestamp(input.modifiedAt, now),
    },
    assets: builder.assets.sort((a, b) => a.id.localeCompare(b.id)),
    sceneStateId,
    states: STATES_PLACEHOLDER,
    history: { entries: historyEntries, index: hydrated.index },
    sketches: indexes.sketches,
    features: indexes.features,
    groups: indexes.groups,
    workplanes: [
      { id: "workplane-base", kind: "base", elevation: 0 },
      ...(selectedWorkplaneId === "workplane-active" ? [{ id: "workplane-active" as const, kind: "offset" as const, elevation: placementElevation }] : []),
    ],
    exactCad: indexes.exactCad,
    ...(attachmentRecords.length > 0 ? { attachments: attachmentRecords } : {}),
    ...(designFonts.length ? { fonts: designFonts } : {}),
    editor: {
      workspace: normalizeWorkspaceSettings(input.workspace),
      snapGrid: normalizeSnapGrid(input.snapGrid),
      selectedWorkplaneId,
      placementElevation,
      placementWorkplane,
      sketchPlacementWorkplane,
      ...(view ? { view } : {}),
      ...(savedViews ? { savedViews } : {}),
      ...(cornerRulers ? { cornerRulers } : {}),
      ...(tapeMeasurements ? { tapeMeasurements } : {}),
    },
  };
  // The states are already text; put them in where the placeholder stands. The
  // result is the same text JSON.stringify would give for the whole document.
  const projectJson = strToU8(JSON.stringify(document).replace(`"states":${JSON.stringify(STATES_PLACEHOLDER)}`, () => `"states":[${stateTexts.join(",")}]`));
  if (projectJson.byteLength > LYL_LIMITS.projectJsonBytes) {
    throw new Error("Project data exceeds the 64 MB project file limit. Export with fewer history steps or simplify the project.");
  }
  builder.files["project.json"] = projectJson;
  for (const [path, bytes] of Object.entries(input.extraFiles ?? {})) {
    if (path in builder.files || !safeArchivePath(path)) throw new Error(`Cannot add '${path}' to the project package`);
    builder.files[path] = bytes;
  }
  if (Object.keys(builder.files).length > LYL_LIMITS.entries) {
    throw new Error("Project has too many stored assets for the project format. Export with fewer history steps.");
  }
  // Attached pictures and PDF files are compressed already: they go in as they are (see `compressed`).
  const stored = new Set(builder.assets.filter((asset) => asset.kind === "attachment" && attachmentTypeForMediaType(asset.mediaType)?.compressed).map((asset) => asset.path));
  return zipAsync(Object.fromEntries(Object.entries(builder.files).sort(([a], [b]) => a.localeCompare(b))), input.compressionLevel, stored);
}

function inspectZipBeforeExpansion(bytes: Uint8Array) {
  if (bytes.byteLength > LYL_LIMITS.archiveBytes) throw new Error(".lyl file exceeds the 512 MB archive limit");
  if (bytes.byteLength < 22) throw new Error(".lyl file is not a valid package");
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let eocd = -1;
  const minimum = Math.max(0, bytes.byteLength - 65_557);
  for (let offset = bytes.byteLength - 22; offset >= minimum; offset -= 1) {
    if (view.getUint32(offset, true) === 0x06054b50) {
      eocd = offset;
      break;
    }
  }
  if (eocd < 0) throw new Error(".lyl package is missing its ZIP directory");
  const entryCount = view.getUint16(eocd + 10, true);
  const centralSize = view.getUint32(eocd + 12, true);
  const centralOffset = view.getUint32(eocd + 16, true);
  if (entryCount === 0xffff || centralSize === 0xffffffff || centralOffset === 0xffffffff) {
    throw new Error("ZIP64 .lyl packages are not supported");
  }
  if (entryCount === 0 || entryCount > LYL_LIMITS.entries) throw new Error(".lyl package has an invalid number of files");
  if (centralOffset + centralSize > bytes.byteLength) throw new Error(".lyl package directory is truncated");
  let offset = centralOffset;
  let expandedBytes = 0;
  let hasProject = false;
  const names = new Set<string>();
  for (let index = 0; index < entryCount; index += 1) {
    if (offset + 46 > bytes.byteLength || view.getUint32(offset, true) !== 0x02014b50) throw new Error(".lyl package directory is malformed");
    const flags = view.getUint16(offset + 8, true);
    const method = view.getUint16(offset + 10, true);
    const expanded = view.getUint32(offset + 24, true);
    const nameLength = view.getUint16(offset + 28, true);
    const extraLength = view.getUint16(offset + 30, true);
    const commentLength = view.getUint16(offset + 32, true);
    const end = offset + 46 + nameLength + extraLength + commentLength;
    if (end > bytes.byteLength) throw new Error(".lyl package directory entry is truncated");
    if (flags & 1) throw new Error("Encrypted .lyl packages are not supported");
    if (method !== 0 && method !== 8) throw new Error(".lyl package uses an unsupported compression method");
    const name = strFromU8(bytes.subarray(offset + 46, offset + 46 + nameLength));
    if (!safeArchivePath(name) || names.has(name)) throw new Error(".lyl package contains an unsafe or duplicate file path");
    names.add(name);
    if (expanded > LYL_LIMITS.assetBytes && name !== "project.json") throw new Error(`Asset '${name}' exceeds the expansion limit`);
    if (name === "project.json") {
      hasProject = true;
      if (expanded > LYL_LIMITS.projectJsonBytes) throw new Error("project.json exceeds the supported size limit");
    }
    expandedBytes += expanded;
    if (expandedBytes > LYL_LIMITS.expandedBytes) throw new Error(".lyl package expands beyond the 1 GB safety limit");
    offset = end;
  }
  if (!hasProject) throw new Error(".lyl package is missing project.json");
}

function objectRecord(value: unknown, label: string): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error(`${label} must be an object`);
  return value as Record<string, unknown>;
}

function stringValue(value: unknown, label: string) {
  if (typeof value !== "string" || !value.trim()) throw new Error(`${label} must be a non-empty string`);
  return value;
}

/** The time a history entry was recorded, if the package carries one that parses. */
function historyRecordedAt(value: string | undefined): number | undefined {
  if (typeof value !== "string") return undefined;
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? parsed : undefined;
}

function stringArray(value: unknown, label: string) {
  if (!Array.isArray(value) || value.some((entry) => typeof entry !== "string" || !entry)) throw new Error(`${label} must be a string array`);
  return value as string[];
}

function validateSketchProfile(value: unknown, label: string) {
  const profile = objectRecord(value, label);
  if (!Array.isArray(profile.points) || !Array.isArray(profile.segments)) throw new Error(`${label} is missing points or segments`);
  const pointIds = new Set<string>();
  profile.points.forEach((rawPoint, index) => {
    const point = objectRecord(rawPoint, `${label}.points[${index}]`);
    const id = stringValue(point.id, `${label}.points[${index}].id`);
    if (pointIds.has(id)) throw new Error(`${label} contains duplicate point ID '${id}'`);
    pointIds.add(id);
    finiteNumber(point.x, `${label}.points[${index}].x`);
    finiteNumber(point.z, `${label}.points[${index}].z`);
    if (point.locked !== undefined && typeof point.locked !== "boolean") throw new Error(`${label}.points[${index}].locked must be true or false`);
  });
  const segmentIds = new Set<string>();
  profile.segments.forEach((rawSegment, index) => {
    const segment = objectRecord(rawSegment, `${label}.segments[${index}]`);
    const id = stringValue(segment.id, `${label}.segments[${index}].id`);
    if (segmentIds.has(id)) throw new Error(`${label} contains duplicate segment ID '${id}'`);
    segmentIds.add(id);
    const startId = stringValue(segment.startId, `${label}.segments[${index}].startId`);
    const endId = stringValue(segment.endId, `${label}.segments[${index}].endId`);
    if (!pointIds.has(startId) || !pointIds.has(endId)) throw new Error(`${label} contains a segment with a missing point reference`);
    if (segment.construction !== undefined && typeof segment.construction !== "boolean") throw new Error(`${label}.segments[${index}].construction must be true or false`);
  });
  if (profile.silhouette !== undefined && typeof profile.silhouette !== "boolean") throw new Error(`${label}.silhouette must be true or false`);
  if (profile.keyring !== undefined && !isSketchKeyring(profile.keyring)) throw new Error(`${label}.keyring must be { side, diameter, x, z } and a free place (#598) with corners of -1 or 1 if it has one`);
  if (profile.sweepAnchor !== undefined && profile.sweepAnchor !== "left" && profile.sweepAnchor !== "center" && profile.sweepAnchor !== "right") throw new Error(`${label}.sweepAnchor must be left, center or right`);
  if (profile.inset !== undefined) {
    const inset = objectRecord(profile.inset, `${label}.inset`);
    const distance = finiteNumber(inset.distance, `${label}.inset.distance`);
    const radius = finiteNumber(inset.radius, `${label}.inset.radius`);
    if (distance < 0 || radius < 0 || distance > 1e6 || radius > 1e6) throw new Error(`${label}.inset is outside the supported range`);
  }
}

const BENT_TUBE_PROFILE_VALUES = new Set(["round", "square", "hexagon", "octagon"]);

/**
 * Missing values are allowed - the geometry falls back to its defaults. A value
 * the geometry could not interpret is not: the same ranges the editor clamps to.
 */
function validateBentTubeDefinition(definition: Record<string, unknown>, label: string) {
  if (definition.bentTubeProfile !== undefined && !BENT_TUBE_PROFILE_VALUES.has(definition.bentTubeProfile as string)) {
    throw new Error(`${label}.bentTubeProfile is invalid`);
  }
  if (definition.bentTubeInnerProfile !== undefined && definition.bentTubeInnerProfile !== "none" && !BENT_TUBE_PROFILE_VALUES.has(definition.bentTubeInnerProfile as string)) {
    throw new Error(`${label}.bentTubeInnerProfile is invalid`);
  }
  if (definition.bentTubeSize !== undefined) {
    const size = finiteNumber(definition.bentTubeSize, `${label}.bentTubeSize`);
    if (size <= 0 || size > 1e6) throw new Error(`${label}.bentTubeSize is outside the supported range`);
  }
  if (definition.bentTubeWall !== undefined) {
    const wall = finiteNumber(definition.bentTubeWall, `${label}.bentTubeWall`);
    if (wall < 0 || wall > 1e6) throw new Error(`${label}.bentTubeWall is outside the supported range`);
  }
  if (definition.bentTubeQuality !== undefined) {
    const quality = finiteNumber(definition.bentTubeQuality, `${label}.bentTubeQuality`);
    if (!Number.isInteger(quality) || quality < 4 || quality > 256) throw new Error(`${label}.bentTubeQuality is outside the supported range`);
  }
  if (definition.bentTubeSegments !== undefined) {
    if (!Array.isArray(definition.bentTubeSegments)) throw new Error(`${label}.bentTubeSegments must be an array`);
    const segments = definition.bentTubeSegments as unknown[];
    if (segments.length < 1 || segments.length > 64) throw new Error(`${label}.bentTubeSegments has an unsupported number of segments`);
    segments.forEach((raw, index) => {
      const segmentLabel = `${label}.bentTubeSegments[${index}]`;
      const segment = objectRecord(raw, segmentLabel);
      const length = finiteNumber(segment.length, `${segmentLabel}.length`);
      const bendAngle = finiteNumber(segment.bendAngle, `${segmentLabel}.bendAngle`);
      const bendRadius = finiteNumber(segment.bendRadius, `${segmentLabel}.bendRadius`);
      const roll = finiteNumber(segment.roll, `${segmentLabel}.roll`);
      if (length < 0 || length > 1e6) throw new Error(`${segmentLabel}.length is outside the supported range`);
      if (Math.abs(bendAngle) > 360) throw new Error(`${segmentLabel}.bendAngle is outside the supported range`);
      if (bendRadius <= 0 || bendRadius > 1e6) throw new Error(`${segmentLabel}.bendRadius is outside the supported range`);
      if (Math.abs(roll) > 360) throw new Error(`${segmentLabel}.roll is outside the supported range`);
    });
  }
}

function validateShapeDefinition(definition: Record<string, unknown>, label: string) {
  const id = stringValue(definition.id, `${label}.id`);
  // An emptied name is a name too: the editor shows the shape's default name for it, so a design
  // renamed to nothing must still open (it is what the object list stores when its field is cleared).
  if (typeof definition.name !== "string") throw new Error(`${label}.name must be a string`);
  const kind = stringValue(definition.kind, `${label}.kind`);
  if (!SHAPE_KINDS.has(kind)) throw new Error(`${label} has unknown shape type '${kind}'`);
  stringValue(definition.color, `${label}.color`);
  ["x", "z", "size", "width", "depth", "height", "rotation"].forEach((field) => finiteNumber(definition[field], `${label}.${field}`));
  if ((definition.width as number) <= 0 || (definition.depth as number) <= 0 || (definition.height as number) <= 0) {
    throw new Error(`${label} has non-positive dimensions`);
  }
  if ([definition.width, definition.depth, definition.height].some((value) => Math.abs(value as number) > 1e9)) {
    throw new Error(`${label} dimensions exceed the supported range`);
  }
  if (definition.importedMesh || definition.groupedShapes || definition.edgeTreatmentHistory || definition.cadBrep) {
    throw new Error(`${label} contains inline package-only geometry fields`);
  }
  if (definition.formulas !== undefined) {
    // The calculations typed into number fields (#180): short texts by field id, nothing else.
    const formulas = objectRecord(definition.formulas, `${label}.formulas`);
    for (const [field, text] of Object.entries(formulas)) {
      if (typeof text !== "string" || text.length > 80) throw new Error(`${label}.formulas.${field} must be a short text`);
    }
  }
  // A text's fill mode (#215): a stroke like a sketch's, and the silhouette switch.
  if (definition.textStroke !== undefined && !normalizeSketchStroke(definition.textStroke)) {
    throw new Error(`${label}.textStroke must be a stroke with a width above 0`);
  }
  if (definition.textSilhouette !== undefined && typeof definition.textSilhouette !== "boolean") {
    throw new Error(`${label}.textSilhouette must be true or false`);
  }
  if (definition.textStretch !== undefined && typeof definition.textStretch !== "boolean") {
    throw new Error(`${label}.textStretch must be true or false`);
  }
  if (definition.textVertical !== undefined && typeof definition.textVertical !== "boolean") {
    throw new Error(`${label}.textVertical must be true or false`);
  }
  // The space between a text's letters (#594), in per cent of the letter size.
  if (definition.textSpacing !== undefined && !(typeof definition.textSpacing === "number" && Number.isFinite(definition.textSpacing) && definition.textSpacing >= -50 && definition.textSpacing <= 300)) {
    throw new Error(`${label}.textSpacing must be a number from -50 to 300`);
  }
  // The top edge of a text's letters (#225): round or chamfer, with a size.
  if (definition.textEdge !== undefined && !normalizeTextEdge(definition.textEdge)) {
    throw new Error(`${label}.textEdge must be a round or chamfer edge with a size`);
  }
  if (definition.layeredText !== undefined && typeof definition.layeredText !== "boolean") {
    throw new Error(`${label}.layeredText must be true or false`);
  }
  if (definition.layeredIcon !== undefined && typeof definition.layeredIcon !== "boolean") {
    throw new Error(`${label}.layeredIcon must be true or false`);
  }
  if (definition.keyringTab !== undefined && typeof definition.keyringTab !== "boolean") {
    throw new Error(`${label}.keyringTab must be true or false`);
  }
  // A reference image's see-through (#680): 0.1 to 1, or none on an old picture plate.
  if (definition.imagePlate !== undefined && !isReferenceImageOpacity((definition.imagePlate as { opacity?: unknown } | null)?.opacity)) {
    throw new Error(`${label}.imagePlate.opacity must be a number from 0.1 to 1`);
  }
  // A QR code's settings (#553): a text and known choices. Old projects have none.
  if (definition.qrCode !== undefined && !normalizeQrSettings(definition.qrCode)) {
    throw new Error(`${label}.qrCode must hold the code's text`);
  }
  // The corners of a text's line (#215): a layer of a name tag can be bevelled or sharp now, so an
  // unknown corner is refused rather than read as sharp.
  const textJoin = (definition.textStroke as { join?: unknown } | undefined)?.join;
  if (textJoin !== undefined && !SKETCH_STROKE_JOINS.includes(textJoin as never)) {
    throw new Error(`${label}.textStroke.join must be miter, round or bevel`);
  }
  // A name tag's key ring hole (#215): a known side, a diameter within range, how far beyond the letters it sits; where it was put freely (#598).
  if (definition.textKeyring !== undefined && !isTextKeyring(definition.textKeyring)) {
    throw new Error(`${label}.textKeyring must be a side (left, right or top), a diameter of 1 to 20 mm and an offset, and a free place (#598) with corners of -1 or 1 if it has one`);
  }
  if (definition.parametricSource !== undefined) {
    // Was der Koerper vor dem Drehen war. Fehlt oder stimmt hier etwas nicht,
    // ist der Koerper immer noch da - nur seine Bauwerte waeren nicht mehr zu
    // erreichen. Ein Paket deswegen abzulehnen waere der groessere Schaden.
    const source = objectRecord(definition.parametricSource, `${label}.parametricSource`);
    const sourceKind = stringValue(source.kind, `${label}.parametricSource.kind`);
    if (!SHAPE_KINDS.has(sourceKind)) throw new Error(`${label}.parametricSource has unknown shape type '${sourceKind}'`);
    ["width", "depth", "height", "size", "rotation", "rotationX", "rotationZ"].forEach((field) => {
      finiteNumber(source[field], `${label}.parametricSource.${field}`);
    });
    if ([source.width, source.depth, source.height].some((value) => (value as number) <= 0 || Math.abs(value as number) > 1e9)) {
      throw new Error(`${label}.parametricSource dimensions are outside the supported range`);
    }
  }
  if (definition.sketchProfile) validateSketchProfile(definition.sketchProfile, `${label}.sketchProfile`);
  if (definition.sketchOperation !== undefined && definition.sketchOperation !== "extrude" && definition.sketchOperation !== "revolve" && definition.sketchOperation !== "sweep") {
    throw new Error(`${label}.sketchOperation is invalid`);
  }
  if (definition.sketchRevolve !== undefined) {
    const settings = objectRecord(definition.sketchRevolve, `${label}.sketchRevolve`);
    ["startAngle", "sweepAngle", "sides", "quality"].forEach((field) => finiteNumber(settings[field], `${label}.sketchRevolve.${field}`));
    if (settings.pitch !== undefined) finiteNumber(settings.pitch, `${label}.sketchRevolve.pitch`);
  }
  if (kind === "thread") {
    // Fehlende Werte sind erlaubt: der Geometriebauer setzt dann seine
    // Vorgaben ein. Verboten ist nur ein Wert, den er nicht deuten kann - ein
    // Paket, das sich nicht mehr speichern laesst, waere der groessere Schaden.
    if (definition.threadRole !== undefined && !["rod", "screw", "nut", "bore"].includes(definition.threadRole as string)) {
      throw new Error(`${label}.threadRole is invalid`);
    }
    if (definition.threadHead !== undefined && !["cylinder", "countersunk", "hex"].includes(definition.threadHead as string)) {
      throw new Error(`${label}.threadHead is invalid`);
    }
    if (definition.threadHand !== undefined && definition.threadHand !== "right" && definition.threadHand !== "left") {
      throw new Error(`${label}.threadHand is invalid`);
    }
    if (definition.threadProfile !== undefined && !isThreadProfile(definition.threadProfile)) {
      throw new Error(`${label}.threadProfile is invalid`);
    }
    if (definition.threadDiameter !== undefined) {
      const threadDiameter = finiteNumber(definition.threadDiameter, `${label}.threadDiameter`);
      if (threadDiameter < 1 || threadDiameter > 160) throw new Error(`${label}.threadDiameter is outside the supported range`);
    }
    if (definition.threadPitch !== undefined) {
      const threadPitch = finiteNumber(definition.threadPitch, `${label}.threadPitch`);
      if (threadPitch < 0.2 || threadPitch > 12) throw new Error(`${label}.threadPitch is outside the supported range`);
    }
    if (definition.threadClearance !== undefined) {
      const threadClearance = finiteNumber(definition.threadClearance, `${label}.threadClearance`);
      if (threadClearance < 0 || threadClearance > 1.5) throw new Error(`${label}.threadClearance is outside the supported range`);
    }
    if (definition.threadBoltClearance !== undefined) {
      const threadBoltClearance = finiteNumber(definition.threadBoltClearance, `${label}.threadBoltClearance`);
      if (threadBoltClearance < 0 || threadBoltClearance > 1) throw new Error(`${label}.threadBoltClearance is outside the supported range`);
    }
    if (definition.threadAxialClearance !== undefined) {
      const threadAxialClearance = finiteNumber(definition.threadAxialClearance, `${label}.threadAxialClearance`);
      if (threadAxialClearance < 0 || threadAxialClearance > 1) throw new Error(`${label}.threadAxialClearance is outside the supported range`);
    }
    if (definition.threadDepth !== undefined) {
      const threadDepth = finiteNumber(definition.threadDepth, `${label}.threadDepth`);
      if (threadDepth <= 0 || threadDepth > 480) throw new Error(`${label}.threadDepth is outside the supported range`);
    }
    if (definition.threadFlankAngle !== undefined) {
      const threadFlankAngle = finiteNumber(definition.threadFlankAngle, `${label}.threadFlankAngle`);
      if (threadFlankAngle < 10 || threadFlankAngle > 90) throw new Error(`${label}.threadFlankAngle is outside the supported range`);
    }
    if (definition.threadQuality !== undefined) {
      const threadQuality = finiteNumber(definition.threadQuality, `${label}.threadQuality`);
      if (!Number.isInteger(threadQuality) || threadQuality < 12 || threadQuality > 96) {
        throw new Error(`${label}.threadQuality is outside the supported range`);
      }
    }
    if (definition.threadHeadHeight !== undefined) {
      const threadHeadHeight = finiteNumber(definition.threadHeadHeight, `${label}.threadHeadHeight`);
      if (threadHeadHeight < 0 || threadHeadHeight > 480) throw new Error(`${label}.threadHeadHeight is outside the supported range`);
    }
    if (definition.threadChamferBottom !== undefined) {
      const threadChamferBottom = finiteNumber(definition.threadChamferBottom, `${label}.threadChamferBottom`);
      if (threadChamferBottom < 0 || threadChamferBottom > 480) throw new Error(`${label}.threadChamferBottom is outside the supported range`);
    }
    if (definition.threadChamfer !== undefined) {
      const threadChamfer = finiteNumber(definition.threadChamfer, `${label}.threadChamfer`);
      if (threadChamfer < 0 || threadChamfer > 480) throw new Error(`${label}.threadChamfer is outside the supported range`);
    }
    if (definition.threadHeadChamfer !== undefined) {
      const threadHeadChamfer = finiteNumber(definition.threadHeadChamfer, `${label}.threadHeadChamfer`);
      if (threadHeadChamfer < 0 || threadHeadChamfer > 480) throw new Error(`${label}.threadHeadChamfer is outside the supported range`);
    }
  }
  if (kind === "pyramid") {
    ["topWidth", "topDepth"].forEach((field) => {
      if (definition[field] === undefined) return;
      const value = finiteNumber(definition[field], `${label}.${field}`);
      if (value < 0 || value > 1e6) throw new Error(`${label}.${field} is outside the supported range`);
    });
  }
  if (kind === "spring") {
    // Fehlende Werte sind erlaubt: der Geometriebauer setzt seine Vorgaben ein.
    // Verboten ist nur ein Wert, den er nicht deuten kann.
    if (definition.springTurns !== undefined) {
      const springTurns = finiteNumber(definition.springTurns, `${label}.springTurns`);
      if (!Number.isInteger(springTurns) || springTurns < 1 || springTurns > 60) {
        throw new Error(`${label}.springTurns is outside the supported range`);
      }
    }
    if (definition.springWire !== undefined) {
      const springWire = finiteNumber(definition.springWire, `${label}.springWire`);
      if (springWire <= 0 || springWire > 480) throw new Error(`${label}.springWire is outside the supported range`);
    }
    if (definition.springHand !== undefined && definition.springHand !== "right" && definition.springHand !== "left") {
      throw new Error(`${label}.springHand is invalid`);
    }
    if (definition.springQuality !== undefined) {
      const springQuality = finiteNumber(definition.springQuality, `${label}.springQuality`);
      if (!Number.isInteger(springQuality) || springQuality < 12 || springQuality > 96) {
        throw new Error(`${label}.springQuality is outside the supported range`);
      }
    }
  }
  if (kind === "gear") {
    const teeth = finiteNumber(definition.teeth, `${label}.teeth`);
    if (!Number.isInteger(teeth) || teeth < 6 || teeth > 150) throw new Error(`${label}.teeth is outside the supported range`);
    const toothSize = finiteNumber(definition.toothSize, `${label}.toothSize`);
    if (toothSize <= 0) throw new Error(`${label}.toothSize must be positive`);
    if (definition.toothWidth !== undefined) {
      const toothWidth = finiteNumber(definition.toothWidth, `${label}.toothWidth`);
      if (toothWidth <= 0) throw new Error(`${label}.toothWidth must be positive`);
    }
    if (definition.centerHoleSize !== undefined) {
      const centerHoleSize = finiteNumber(definition.centerHoleSize, `${label}.centerHoleSize`);
      if (centerHoleSize < 0) throw new Error(`${label}.centerHoleSize cannot be negative`);
    }
    if (!["spur", "helical", "herringbone", "bevel", "internal", "rack"].includes(definition.gearType as string)) throw new Error(`${label}.gearType is invalid`);
    if (definition.gearRim !== undefined) {
      const rim = finiteNumber(definition.gearRim, `${label}.gearRim`);
      if (rim <= 0) throw new Error(`${label}.gearRim must be positive`);
    }
    if (definition.helixAngle !== undefined) {
      const helixAngle = finiteNumber(definition.helixAngle, `${label}.helixAngle`);
      if (helixAngle < -45 || helixAngle > 45) throw new Error(`${label}.helixAngle is outside the supported range`);
    }
    if (definition.helixQuality !== undefined) {
      const helixQuality = finiteNumber(definition.helixQuality, `${label}.helixQuality`);
      if (!Number.isInteger(helixQuality) || helixQuality < 4 || helixQuality > 32) {
        throw new Error(`${label}.helixQuality is outside the supported range`);
      }
    }
    if (definition.gearProfile !== undefined && !["involute", "round", "simple"].includes(definition.gearProfile as string)) throw new Error(`${label}.gearProfile is invalid`);
    if (definition.gearPressureAngle !== undefined) {
      const pressureAngle = finiteNumber(definition.gearPressureAngle, `${label}.gearPressureAngle`);
      if (pressureAngle < 14.5 || pressureAngle > 30) throw new Error(`${label}.gearPressureAngle is outside the supported range`);
    }
    if (definition.gearBacklash !== undefined) {
      const backlash = finiteNumber(definition.gearBacklash, `${label}.gearBacklash`);
      if (backlash < 0 || backlash > 2) throw new Error(`${label}.gearBacklash is outside the supported range`);
    }
  }
  if (kind === "star") {
    if (definition.starPoints !== undefined) {
      const starPoints = finiteNumber(definition.starPoints, `${label}.starPoints`);
      if (!Number.isInteger(starPoints) || starPoints < 3 || starPoints > 32) {
        throw new Error(`${label}.starPoints is outside the supported range`);
      }
    }
    if (definition.starInnerSize !== undefined) {
      const starInnerSize = finiteNumber(definition.starInnerSize, `${label}.starInnerSize`);
      if (starInnerSize <= 0 || starInnerSize > 1e6) throw new Error(`${label}.starInnerSize is outside the supported range`);
    }
    if (definition.starOuterFillet !== undefined) {
      const starOuterFillet = finiteNumber(definition.starOuterFillet, `${label}.starOuterFillet`);
      if (starOuterFillet < 0 || starOuterFillet > 1e6) throw new Error(`${label}.starOuterFillet is outside the supported range`);
    }
    if (definition.starInnerFillet !== undefined) {
      const starInnerFillet = finiteNumber(definition.starInnerFillet, `${label}.starInnerFillet`);
      if (starInnerFillet < 0 || starInnerFillet > 1e6) throw new Error(`${label}.starInnerFillet is outside the supported range`);
    }
    if (definition.starQuality !== undefined) {
      const starQuality = finiteNumber(definition.starQuality, `${label}.starQuality`);
      if (!Number.isInteger(starQuality) || starQuality < 4 || starQuality > 48) {
        throw new Error(`${label}.starQuality is outside the supported range`);
      }
    }
  }
  if (kind === "heart") {
    if (definition.heartTipFillet !== undefined) {
      const heartTipFillet = finiteNumber(definition.heartTipFillet, `${label}.heartTipFillet`);
      if (heartTipFillet < 0 || heartTipFillet > 1e6) throw new Error(`${label}.heartTipFillet is outside the supported range`);
    }
    if (definition.heartQuality !== undefined) {
      const heartQuality = finiteNumber(definition.heartQuality, `${label}.heartQuality`);
      if (!Number.isInteger(heartQuality) || heartQuality < 16 || heartQuality > 64) {
        throw new Error(`${label}.heartQuality is outside the supported range`);
      }
    }
  }
  if (kind === "crescent") {
    if (definition.crescentThickness !== undefined) {
      const crescentThickness = finiteNumber(definition.crescentThickness, `${label}.crescentThickness`);
      if (crescentThickness <= 0 || crescentThickness > 1e6) throw new Error(`${label}.crescentThickness is outside the supported range`);
    }
    if (definition.crescentTipFillet !== undefined) {
      const crescentTipFillet = finiteNumber(definition.crescentTipFillet, `${label}.crescentTipFillet`);
      if (crescentTipFillet < 0 || crescentTipFillet > 1e6) throw new Error(`${label}.crescentTipFillet is outside the supported range`);
    }
    if (definition.crescentQuality !== undefined) {
      const crescentQuality = finiteNumber(definition.crescentQuality, `${label}.crescentQuality`);
      if (!Number.isInteger(crescentQuality) || crescentQuality < 16 || crescentQuality > 64) {
        throw new Error(`${label}.crescentQuality is outside the supported range`);
      }
    }
  }
  if (kind === "counterbore" || kind === "countersink" || kind === "doubleCountersink") {
    // Lenient on purpose: the geometry clamps the values itself; only nonsense is refused.
    for (const key of ["screwHoleShaft", "screwHoleHeadDepth", "screwHoleAngle"] as const) {
      if (definition[key] === undefined) continue;
      const value = finiteNumber(definition[key], `${label}.${key}`);
      if (value < 0 || value > 1e6) throw new Error(`${label}.${key} is outside the supported range`);
    }
  }
  if (kind === "knurl") {
    // Lenient on purpose: the geometry clamps the values itself; only nonsense is refused.
    for (const key of ["knurlCount", "knurlDepth", "knurlAngle", "knurlChamfer"] as const) {
      if (definition[key] === undefined) continue;
      const value = finiteNumber(definition[key], `${label}.${key}`);
      if (value < 0 || value > 1e6) throw new Error(`${label}.${key} is outside the supported range`);
    }
    if (definition.knurlPattern !== undefined && definition.knurlPattern !== "straight" && definition.knurlPattern !== "diamond" && definition.knurlPattern !== "round") {
      throw new Error(`${label}.knurlPattern must be straight, diamond or round`);
    }
  }
  if (kind === "gridfinity") {
    // The size is rounded to whole grid units on loading (a tray's is kept to its limits), and the geometry clamps the label shelf's, the finger scoop's, the floor's, the lip chamfer's, the wall's, the corners' (a baseplate's and a bin's) and the dividers' values; only nonsense is refused.
    if (definition.gridfinityType !== undefined && definition.gridfinityType !== "bin" && definition.gridfinityType !== "baseplate" && definition.gridfinityType !== "tray") {
      throw new Error(`${label}.gridfinityType is invalid`);
    }
    for (const key of ["gridfinityLip", "gridfinityMagnets", "gridfinityHalfGrid", "gridfinityLabelBack", "gridfinityLabelFront", "gridfinityLabelLeft", "gridfinityLabelRight", "gridfinityScoopBack", "gridfinityScoopFront", "gridfinityScoopLeft", "gridfinityScoopRight", "gridfinityOpenBack", "gridfinityOpenFront", "gridfinityOpenLeft", "gridfinityOpenRight", "hingePinless"] as const) {
      if (definition[key] !== undefined && typeof definition[key] !== "boolean") throw new Error(`${label}.${key} must be true or false`);
    }
    for (const key of ["gridfinityLabelBackWidth", "gridfinityLabelBackLength", "gridfinityLabelBackOffset", "gridfinityLabelFrontWidth", "gridfinityLabelFrontLength", "gridfinityLabelFrontOffset", "gridfinityLabelLeftWidth", "gridfinityLabelLeftLength", "gridfinityLabelLeftOffset", "gridfinityLabelRightWidth", "gridfinityLabelRightLength", "gridfinityLabelRightOffset", "gridfinityLabelCornerSize", "gridfinityScoopRadius", "gridfinityFloorHeight", "gridfinityLipChamfer", "gridfinityWallThickness", "gridfinityOpeningCornerSize", "gridfinityPaddingBack", "gridfinityPaddingFront", "gridfinityPaddingLeft", "gridfinityPaddingRight", "gridfinityCornerRadius", "gridfinityBinCornerRadius", "gridfinityCompartmentsX", "gridfinityCompartmentsZ", "gridfinityDividerThickness"] as const) {
      if (definition[key] === undefined) continue;
      const value = finiteNumber(definition[key], `${label}.${key}`);
      // Only an offset runs both ways along a wall.
      if ((!key.endsWith("Offset") && value < 0) || Math.abs(value) > 1e6) throw new Error(`${label}.${key} is outside the supported range`);
    }
    if (definition.gridfinityLabelCorner !== undefined && definition.gridfinityLabelCorner !== "round" && definition.gridfinityLabelCorner !== "chamfer") {
      throw new Error(`${label}.gridfinityLabelCorner is invalid`);
    }
    if (definition.gridfinityOpeningCorner !== undefined && definition.gridfinityOpeningCorner !== "round" && definition.gridfinityOpeningCorner !== "chamfer") {
      throw new Error(`${label}.gridfinityOpeningCorner is invalid`);
    }
    for (const key of ["gridfinityDividerPositionsX", "gridfinityDividerPositionsZ"] as const) {
      if (definition[key] === undefined) continue;
      if (!Array.isArray(definition[key])) throw new Error(`${label}.${key} must be an array`);
      const positions = definition[key] as unknown[];
      if (positions.length > 64) throw new Error(`${label}.${key} has an unsupported number of dividers`);
      positions.forEach((raw, index) => {
        const position = finiteNumber(raw, `${label}.${key}[${index}]`);
        if (position < 0 || position > 1e6) throw new Error(`${label}.${key}[${index}] is outside the supported range`);
      });
    }
    if (definition.gridfinityCompartmentLabels !== undefined) {
      if (!Array.isArray(definition.gridfinityCompartmentLabels)) throw new Error(`${label}.gridfinityCompartmentLabels must be an array`);
      const labels = definition.gridfinityCompartmentLabels as unknown[];
      if (labels.length > 576) throw new Error(`${label}.gridfinityCompartmentLabels has an unsupported number of labels`);
      labels.forEach((raw, index) => {
        const entryLabel = `${label}.gridfinityCompartmentLabels[${index}]`;
        const entry = objectRecord(raw, entryLabel);
        for (const key of ["column", "row"] as const) {
          const value = finiteNumber(entry[key], `${entryLabel}.${key}`);
          if (value < 0 || value > 1e6) throw new Error(`${entryLabel}.${key} is outside the supported range`);
        }
        if (entry.side !== "back" && entry.side !== "front" && entry.side !== "left" && entry.side !== "right") throw new Error(`${entryLabel}.side is invalid`);
        for (const key of ["length", "width"] as const) {
          if (entry[key] === undefined) continue;
          const value = finiteNumber(entry[key], `${entryLabel}.${key}`);
          if (value < 0 || value > 1e6) throw new Error(`${entryLabel}.${key} is outside the supported range`);
        }
        if (entry.align !== undefined && entry.align !== "start" && entry.align !== "middle" && entry.align !== "end") throw new Error(`${entryLabel}.align is invalid`);
      });
    }
    if (definition.gridfinityOpenings !== undefined) {
      if (!Array.isArray(definition.gridfinityOpenings)) throw new Error(`${label}.gridfinityOpenings must be an array`);
      const openings = definition.gridfinityOpenings as unknown[];
      if (openings.length > 4) throw new Error(`${label}.gridfinityOpenings has an unsupported number of openings`);
      const sides = new Set<unknown>();
      openings.forEach((raw, index) => {
        const entryLabel = `${label}.gridfinityOpenings[${index}]`;
        const entry = objectRecord(raw, entryLabel);
        if (entry.side !== "back" && entry.side !== "front" && entry.side !== "left" && entry.side !== "right") throw new Error(`${entryLabel}.side is invalid`);
        if (sides.has(entry.side)) throw new Error(`${entryLabel}.side is given twice`);
        sides.add(entry.side);
        for (const key of ["depth", "width", "distance"] as const) {
          if (entry[key] === undefined) continue;
          const value = finiteNumber(entry[key], `${entryLabel}.${key}`);
          if (value < 0 || value > 1e6) throw new Error(`${entryLabel}.${key} is outside the supported range`);
        }
        if (entry.align !== undefined && entry.align !== "start" && entry.align !== "middle" && entry.align !== "end") throw new Error(`${entryLabel}.align is invalid`);
      });
    }
  }
  if (kind === "hinge") {
    // Lenient on purpose: the geometry clamps the values itself; only nonsense is refused.
    for (const key of ["hingeKnuckles", "hingeKnuckleWidth", "hingeConeSize", "hingePinDiameter", "hingeLeafThickness", "hingeClearance", "hingeAngle", "hingeScrewHoles", "hingeScrewDiameter", "hingeScrewSpacing", "hingeScrewAcross", "hingeCornerRadius"] as const) {
      if (definition[key] === undefined) continue;
      const value = finiteNumber(definition[key], `${label}.${key}`);
      if (value < 0 || value > 1e6) throw new Error(`${label}.${key} is outside the supported range`);
    }
  }
  if (kind === "torus" && definition.torusTubeRatio !== undefined) {
    // Up to 1, not 0.5: a design from before #981 carries its height as the tube, and that may have been taller than the hole allowed.
    const ratio = finiteNumber(definition.torusTubeRatio, `${label}.torusTubeRatio`);
    if (ratio <= 0 || ratio > 1) throw new Error(`${label}.torusTubeRatio is outside the supported range`);
  }
  if (kind === "slot" && definition.slotEndRatio !== undefined) {
    const ratio = finiteNumber(definition.slotEndRatio, `${label}.slotEndRatio`);
    if (ratio <= 0 || ratio > 1) throw new Error(`${label}.slotEndRatio is outside the supported range`);
  }
  if (kind === "loft") {
    // Lenient on purpose: the geometry clamps the values itself; only nonsense is refused.
    for (const key of ["loftBottomWidth", "loftBottomDepth", "loftTopWidth", "loftTopDepth", "loftBottomCorner", "loftTopCorner", "loftBottomSides", "loftTopSides", "loftOffsetX", "loftOffsetZ", "loftWall", "loftTwist", "loftTiltX", "loftTiltZ", "loftSmooth", "loftSegments"] as const) {
      if (definition[key] === undefined) continue;
      const value = finiteNumber(definition[key], `${label}.${key}`);
      if (Math.abs(value) > 1e6) throw new Error(`${label}.${key} is outside the supported range`);
    }
    for (const key of ["loftBottomOutline", "loftTopOutline"] as const) {
      const value = definition[key];
      if (value !== undefined && value !== "round" && value !== "rectangle" && value !== "polygon") {
        throw new Error(`${label}.${key} must be round, rectangle or polygon`);
      }
    }
  }
  if (kind === "dovetail") {
    // Lenient on purpose: the geometry clamps the values itself; only nonsense is refused.
    for (const key of ["dovetailNeckWidth", "dovetailClearance"] as const) {
      if (definition[key] === undefined) continue;
      const value = finiteNumber(definition[key], `${label}.${key}`);
      if (value < 0 || value > 1e6) throw new Error(`${label}.${key} is outside the supported range`);
    }
  }
  if (kind === "honeycomb") {
    if (definition.honeycombCellSize !== undefined) {
      const honeycombCellSize = finiteNumber(definition.honeycombCellSize, `${label}.honeycombCellSize`);
      if (honeycombCellSize <= 0 || honeycombCellSize > 1e6) throw new Error(`${label}.honeycombCellSize is outside the supported range`);
    }
    if (definition.honeycombWallThickness !== undefined) {
      const honeycombWallThickness = finiteNumber(definition.honeycombWallThickness, `${label}.honeycombWallThickness`);
      if (honeycombWallThickness <= 0 || honeycombWallThickness > 1e6) throw new Error(`${label}.honeycombWallThickness is outside the supported range`);
    }
    if (definition.honeycombFrameWidth !== undefined) {
      const honeycombFrameWidth = finiteNumber(definition.honeycombFrameWidth, `${label}.honeycombFrameWidth`);
      if (honeycombFrameWidth < 0 || honeycombFrameWidth > 1e6) throw new Error(`${label}.honeycombFrameWidth is outside the supported range`);
    }
  }
  // A rotated bent tube is stored baked as a mesh but keeps its parameters,
  // so they are checked for either form.
  const parametricKind = definition.parametricSource && typeof definition.parametricSource === "object"
    ? (definition.parametricSource as Record<string, unknown>).kind
    : undefined;
  if (kind === "bentTube" || parametricKind === "bentTube") {
    validateBentTubeDefinition(definition, label);
  }
  if (kind === "roundedBox") {
    if (definition.cornerFillet !== undefined) {
      const cornerFillet = finiteNumber(definition.cornerFillet, `${label}.cornerFillet`);
      if (cornerFillet < 0 || cornerFillet > 1e6) throw new Error(`${label}.cornerFillet is outside the supported range`);
    }
    if (definition.topBottomFillet !== undefined) {
      const topBottomFillet = finiteNumber(definition.topBottomFillet, `${label}.topBottomFillet`);
      if (topBottomFillet < 0 || topBottomFillet > 1e6) throw new Error(`${label}.topBottomFillet is outside the supported range`);
    }
    if (definition.roundedBoxQuality !== undefined) {
      const roundedBoxQuality = finiteNumber(definition.roundedBoxQuality, `${label}.roundedBoxQuality`);
      if (!Number.isInteger(roundedBoxQuality) || roundedBoxQuality < 1 || roundedBoxQuality > 64) {
        throw new Error(`${label}.roundedBoxQuality is outside the supported range`);
      }
    }
  }
  return id;
}

function validateFeatureGraph(features: unknown, activeObjectIds: Set<string>) {
  if (!Array.isArray(features) || features.length > LYL_LIMITS.features) throw new Error("features is invalid or too large");
  const byId = new Map<string, Record<string, unknown>>();
  features.forEach((rawFeature, index) => {
    const feature = objectRecord(rawFeature, `features[${index}]`);
    const id = stringValue(feature.id, `features[${index}].id`);
    if (byId.has(id)) throw new Error(`Duplicate feature ID '${id}'`);
    const type = stringValue(feature.type, `features[${index}].type`);
    if (!FEATURE_TYPES.has(type)) throw new Error(`Unknown operation type '${type}'`);
    const output = stringValue(feature.outputObjectId, `features[${index}].outputObjectId`);
    if (!activeObjectIds.has(output)) throw new Error(`Feature '${id}' references missing output object '${output}'`);
    stringArray(feature.inputObjectIds, `features[${index}].inputObjectIds`).forEach((input) => {
      if (!activeObjectIds.has(input)) throw new Error(`Feature '${id}' references missing input object '${input}'`);
    });
    stringArray(feature.dependsOnFeatureIds, `features[${index}].dependsOnFeatureIds`);
    byId.set(id, feature);
  });
  byId.forEach((feature, id) => {
    (feature.dependsOnFeatureIds as string[]).forEach((dependency) => {
      if (!byId.has(dependency)) throw new Error(`Feature '${id}' references missing dependency '${dependency}'`);
    });
  });
  const visiting = new Set<string>();
  const visited = new Set<string>();
  const visit = (id: string) => {
    if (visiting.has(id)) throw new Error(`Cyclic feature dependency detected at '${id}'`);
    if (visited.has(id)) return;
    visiting.add(id);
    ((byId.get(id)?.dependsOnFeatureIds as string[] | undefined) ?? []).forEach(visit);
    visiting.delete(id);
    visited.add(id);
  };
  byId.forEach((_feature, id) => visit(id));
}

async function validateDocumentAndAssets(raw: unknown, files: ArchiveFiles) {
  const document = objectRecord(raw, "project.json") as unknown as LylProjectDocumentV1;
  if (!knownSchema(document.schema)) throw new Error("This file is not a layerling project");
  if (!Number.isInteger(document.formatVersion)) throw new Error("layerling formatVersion is missing");
  if (document.formatVersion > LYL_NEWEST_READABLE_FORMAT_VERSION) {
    throw new Error(`This project uses project format ${document.formatVersion}, which requires a newer layerling version`);
  }
  if (document.formatVersion < LYL_OLDEST_READABLE_FORMAT_VERSION) {
    throw new Error(`Packaged project format ${document.formatVersion} requires migration support that is not available`);
  }
  if (!Number.isInteger(document.minimumReaderVersion) || document.minimumReaderVersion > LYL_NEWEST_READABLE_FORMAT_VERSION) {
    throw new Error("This project requires a newer layerling reader and was not opened");
  }
  const metadata = objectRecord(document.metadata, "metadata");
  stringValue(metadata.projectName, "metadata.projectName");
  parseIsoTimestamp(metadata.createdAt, "metadata.createdAt");
  parseIsoTimestamp(metadata.modifiedAt, "metadata.modifiedAt");
  if (!Array.isArray(document.assets) || !Array.isArray(document.states) || !Array.isArray(document.history?.entries)) {
    throw new Error("project.json is missing assets, states, or history");
  }
  if (document.states.length === 0 || document.states.length > LYL_LIMITS.states) throw new Error("Project contains an invalid number of states");
  validateFonts(document.fonts);

  const assetById = new Map<string, LylAssetRecordV1>();
  const assetPaths = new Set<string>();
  for (let index = 0; index < document.assets.length; index += 1) {
    const asset = document.assets[index];
    const id = stringValue(asset?.id, `assets[${index}].id`);
    if (assetById.has(id)) throw new Error(`Duplicate asset ID '${id}'`);
    if (!asset || !LYL_ASSET_KINDS.includes(asset.kind)) throw new Error(`Asset '${id}' has an unknown type`);
    if (!safeArchivePath(asset.path) || assetPaths.has(asset.path)) throw new Error(`Asset '${id}' has an unsafe or duplicate path`);
    assetPaths.add(asset.path);
    const bytes = files[asset.path];
    if (!bytes) throw new Error(`Missing asset '${asset.path}'`);
    if (bytes.byteLength !== asset.byteLength) throw new Error(`Asset '${asset.path}' has an invalid size`);
    const hash = await sha256Hex(bytes);
    if (hash !== asset.sha256) throw new Error(`Asset '${asset.path}' failed its integrity check`);
    if (asset.kind === "source" && !["stl", "obj", "svg", "step", "3mf"].includes(asset.sourceFormat ?? "")) {
      throw new Error(`Source asset '${id}' has an unknown source format`);
    }
    // An attachment's bytes are checked again here, whatever the package says about them: its type has to
    // be one that may be attached and its content has to be what that type is (see projectAttachments.ts).
    if (asset.kind === "attachment") {
      const type = attachmentTypeForMediaType(asset.mediaType);
      if (!type) throw new Error(`Attachment asset '${id}' has a file type that cannot be attached`);
      if (bytes.byteLength > type.maxBytes) throw new Error(`Attachment asset '${id}' is larger than ${type.maxBytes / (1024 * 1024)} MB`);
      const problem = bytes.byteLength === 0 ? "empty" : type.check(bytes);
      if (problem) throw new Error(`Attachment asset '${id}': ${attachmentProblemText(problem)}`);
    }
    assetById.set(id, asset);
  }
  // The list of files comes after the assets: it is checked against them.
  const attachments = validateAttachments(document, assetById);

  const stateById = new Map<string, LylStateV1>();
  const activeObjectIds = new Set<string>();
  for (let stateIndex = 0; stateIndex < document.states.length; stateIndex += 1) {
    const state = document.states[stateIndex];
    const stateId = stringValue(state?.id, `states[${stateIndex}].id`);
    if (stateById.has(stateId)) throw new Error(`Duplicate state ID '${stateId}'`);
    if (!Array.isArray(state.nodes) || state.nodes.length > LYL_LIMITS.objectsPerState) throw new Error(`State '${stateId}' has too many objects`);
    const nodeById = new Map<string, LylShapeNodeV1>();
    state.nodes.forEach((node, nodeIndex) => {
      const nodeId = stringValue(node?.nodeId, `states[${stateIndex}].nodes[${nodeIndex}].nodeId`);
      if (nodeById.has(nodeId)) throw new Error(`State '${stateId}' contains duplicate node ID '${nodeId}'`);
      const definition = objectRecord(node.definition, `node '${nodeId}'.definition`);
      const objectId = validateShapeDefinition(definition, `node '${nodeId}'`);
      if (node.objectId !== objectId) throw new Error(`Node '${nodeId}' objectId does not match its shape definition`);
      if (node.importedMesh) {
        const source = node.importedMesh.sourceAssetId ? assetById.get(node.importedMesh.sourceAssetId) : undefined;
        const mesh = node.importedMesh.meshAssetId ? assetById.get(node.importedMesh.meshAssetId) : undefined;
        if (!source && !mesh) throw new Error(`Imported object '${objectId}' is missing its source or mesh asset`);
        if (source && source.kind !== "source" || mesh && mesh.kind !== "derived-mesh") throw new Error(`Imported object '${objectId}' has an invalid asset reference`);
        if (node.importedMesh.brepStepAssetId && assetById.get(node.importedMesh.brepStepAssetId)?.kind !== "brep") throw new Error(`Imported object '${objectId}' has a missing STEP B-Rep asset`);
        ["baseWidth", "baseDepth", "baseHeight", "triangleCount"].forEach((field) => finiteNumber(node.importedMesh?.[field as keyof LylImportedMeshReferenceV1], `object '${objectId}'.${field}`));
      }
      if (node.cadBrepAssetId && assetById.get(node.cadBrepAssetId)?.kind !== "brep") throw new Error(`Object '${objectId}' has a missing exact B-Rep asset`);
      if (node.cadDisplayEdgesAssetId && assetById.get(node.cadDisplayEdgesAssetId)?.kind !== "display-edges") {
        throw new Error(`Object '${objectId}' has a missing display edge asset`);
      }
      nodeById.set(nodeId, node);
    });
    const roots = stringArray(state.rootNodeIds, `state '${stateId}'.rootNodeIds`);
    const visiting = new Set<string>();
    const visited = new Set<string>();
    const primaryObjectIds = new Set<string>();
    const walk = (nodeId: string, primary: boolean) => {
      if (visiting.has(nodeId)) throw new Error(`Cyclic group or history reference detected at '${nodeId}'`);
      if (visited.has(`${primary ? "primary" : "history"}:${nodeId}`)) return;
      const node = nodeById.get(nodeId);
      if (!node) throw new Error(`State '${stateId}' references missing node '${nodeId}'`);
      visiting.add(nodeId);
      if (primary) {
        if (primaryObjectIds.has(node.objectId)) throw new Error(`State '${stateId}' contains duplicate object ID '${node.objectId}'`);
        primaryObjectIds.add(node.objectId);
      }
      (node.groupedShapeNodeIds ?? []).forEach((child) => walk(child, primary));
      (node.edgeTreatmentHistory ?? []).forEach((entry) => walk(entry.beforeNodeId, false));
      visiting.delete(nodeId);
      visited.add(`${primary ? "primary" : "history"}:${nodeId}`);
    };
    roots.forEach((root) => walk(root, true));
    if (stateId === document.sceneStateId) primaryObjectIds.forEach((id) => activeObjectIds.add(id));
    stateById.set(stateId, state);
  }
  if (!stateById.has(document.sceneStateId)) throw new Error("Active scene state is missing");
  if (!Number.isInteger(document.history.index) || document.history.index < 0 || document.history.index >= document.history.entries.length) {
    throw new Error("Undo history index is invalid");
  }
  document.history.entries.forEach((entry, index) => {
    if (!stateById.has(entry.stateId)) throw new Error(`History entry ${index} references missing state '${entry.stateId}'`);
    stringArray(entry.selectedObjectIds, `history.entries[${index}].selectedObjectIds`);
    if (entry.recordedAt !== undefined && typeof entry.recordedAt !== "string") {
      throw new Error(`history.entries[${index}].recordedAt must be a string`);
    }
  });
  if (document.history.entries[document.history.index]?.stateId !== document.sceneStateId) throw new Error("Active scene and undo history index do not match");
  validateFeatureGraph(document.features, activeObjectIds);
  const editor = objectRecord(document.editor, "editor");
  finiteNumber(editor.placementElevation, "editor.placementElevation");
  for (const fieldName of ["placementWorkplane", "sketchPlacementWorkplane"] as const) {
    if (editor[fieldName] === undefined) continue;
    const workplane = objectRecord(editor[fieldName], `editor.${fieldName}`);
    for (const field of ["origin", "normal", "xAxis", "zAxis"] as const) {
      const coordinates = objectRecord(workplane[field], `editor.${fieldName}.${field}`);
      finiteNumber(coordinates.x, `editor.${fieldName}.${field}.x`);
      finiteNumber(coordinates.y, `editor.${fieldName}.${field}.y`);
      finiteNumber(coordinates.z, `editor.${fieldName}.${field}.z`);
    }
  }
  return { document, assetById, stateById, attachments };
}

/** The list of files a package carries, checked: each has its file, a name that suits its type, and the whole is within the limits. */
function validateAttachments(document: LylProjectDocumentV1, assetById: Map<string, LylAssetRecordV1>) {
  if (document.attachments === undefined) return [];
  if (document.formatVersion < LYL_ATTACHMENTS_FORMAT_VERSION) throw new Error(`Project format ${document.formatVersion} does not carry attachments`);
  if (!Array.isArray(document.attachments)) throw new Error("project.json attachments must be a list");
  const ids = new Set<string>();
  const records = document.attachments.map((entry, index): LylAttachmentV3 => {
    const record = objectRecord(entry, `attachments[${index}]`);
    const id = stringValue(record.id, `attachments[${index}].id`);
    const fileName = stringValue(record.fileName, `attachments[${index}].fileName`);
    const assetId = stringValue(record.assetId, `attachments[${index}].assetId`);
    if (ids.has(id)) throw new Error(`Duplicate attachment ID '${id}'`);
    ids.add(id);
    const asset = assetById.get(assetId);
    if (!asset || asset.kind !== "attachment") throw new Error(`Attachment '${fileName}' is missing its file`);
    const type = attachmentTypeForFileName(fileName);
    if (type?.mediaType !== asset.mediaType) throw new Error(`Attachment '${fileName}' does not match the type of its file`);
    // A package that says it is older than its files: a hand-made one, or one changed by hand.
    if (type.formatVersion > document.formatVersion) throw new Error(`Project format ${document.formatVersion} does not carry ${type.label} attachments`);
    return { id, fileName, assetId };
  });
  const problem = attachmentListProblem(records.map((record) => ({ name: record.fileName, byteLength: assetById.get(record.assetId)?.byteLength ?? 0 })));
  if (problem) throw new Error(attachmentProblemText(problem.problem, problem.fileName));
  // More files, or more bytes, than version 3 allowed: such a list is written as version 4 only.
  const needed = attachmentsFormatVersion(records.map((record) => assetById.get(record.assetId)!));
  if (needed !== undefined && needed > document.formatVersion) throw new Error(`Project format ${document.formatVersion} does not carry this many attachments`);
  return records;
}

type ImportedMesh = NonNullable<WorkplaneShape["importedMesh"]>;

// Undo states mostly reference the same few meshes. Handing every state the
// same immutable mesh object - not just the same coordinate arrays - is what
// lets the history fingerprint and the autosave encoder, which both remember
// their work per object, do that work once instead of once per undo state.
const sharedImportedMeshes = new WeakMap<object, Map<string, ImportedMesh>>();

function sharedImportedMesh(decoded: object, reference: string, create: () => ImportedMesh) {
  let byReference = sharedImportedMeshes.get(decoded);
  if (!byReference) {
    byReference = new Map();
    sharedImportedMeshes.set(decoded, byReference);
  }
  let mesh = byReference.get(reference);
  if (!mesh) {
    mesh = create();
    byReference.set(reference, mesh);
  }
  return mesh;
}

async function defaultSourceImporter(asset: ProjectAsset) {
  if (asset.sourceFormat === "stl") {
    // In the browser the file is read off the page (lib/geometryWorker.ts); the server reads it here.
    if (typeof window !== "undefined") {
      const { importedShapeFromStlOffThread } = await import("@/lib/geometryWorker");
      return (await importedShapeFromStlOffThread(asset.name, exactArrayBuffer(asset.bytes))).importedMesh as NonNullable<WorkplaneShape["importedMesh"]>;
    }
    return importedShapeFromStl(asset.name, exactArrayBuffer(asset.bytes)).importedMesh as NonNullable<WorkplaneShape["importedMesh"]>;
  }
  if (asset.sourceFormat === "obj") return importedShapeFromObj(asset.name, strFromU8(asset.bytes), true).importedMesh as NonNullable<WorkplaneShape["importedMesh"]>;
  if (asset.sourceFormat === "svg") return importedShapeFromSvg(asset.name, strFromU8(asset.bytes)).importedMesh as NonNullable<WorkplaneShape["importedMesh"]>;
  if (asset.sourceFormat === "3mf") return importedShapeFrom3mf(asset.name, exactArrayBuffer(asset.bytes)).importedMesh as NonNullable<WorkplaneShape["importedMesh"]>;
  if (asset.sourceFormat === "step") {
    const { importedShapeFromStep } = await import("@/lib/stepImport");
    return (await importedShapeFromStep(asset.name, exactArrayBuffer(asset.bytes))).importedMesh as NonNullable<WorkplaneShape["importedMesh"]>;
  }
  throw new Error("Layerling cannot reconstruct this source asset format");
}

async function restoreShapeFromNode(
  nodeId: string,
  nodeById: Map<string, LylShapeNodeV1>,
  assetById: Map<string, LylAssetRecordV1>,
  files: ArchiveFiles,
  runtimeAssetByArchiveId: Map<string, ProjectAsset>,
  sourceMeshCache: Map<string, Promise<NonNullable<WorkplaneShape["importedMesh"]>>>,
  derivedMeshCache: Map<string, ReturnType<typeof decodeMeshCache>>,
  displayEdgeCache: Map<string, CadDisplayEdge[]>,
  sourceImporter: LylSourceImporter,
  restoring = new Set<string>(),
): Promise<WorkplaneShape> {
  if (restoring.has(nodeId)) throw new Error(`Cyclic shape dependency detected at '${nodeId}'`);
  const node = nodeById.get(nodeId);
  if (!node) throw new Error(`Missing shape node '${nodeId}'`);
  restoring.add(nodeId);
  const definition = { ...node.definition } as Record<string, unknown>;
  const serializedPlate = definition.imagePlate as (Record<string, unknown> & { assetId?: string }) | undefined;
  if (serializedPlate?.assetId) {
    const record = assetById.get(serializedPlate.assetId);
    if (!record || record.kind !== "image") throw new Error(`Object '${node.objectId}' has a missing image asset`);
    const { assetId: _assetId, ...plate } = serializedPlate;
    definition.imagePlate = { ...plate, dataUrl: bytesToDataUrl(files[record.path], record.mediaType) };
  }
  const serializedProfile = definition.sketchProfile as (Record<string, unknown> & { images?: Array<Record<string, unknown> & { assetId?: string }> }) | undefined;
  if (serializedProfile?.images) {
    definition.sketchProfile = {
      ...serializedProfile,
      images: serializedProfile.images.map((image) => {
        const record = image.assetId ? assetById.get(image.assetId) : undefined;
        if (!record || record.kind !== "image") throw new Error(`Sketch '${node.objectId}' has a missing image asset`);
        const { assetId: _assetId, ...rest } = image;
        return { ...rest, dataUrl: bytesToDataUrl(files[record.path], record.mediaType) };
      }),
    };
  }

  if (node.cadDisplayEdgesAssetId) {
    const edgeRecord = assetById.get(node.cadDisplayEdgesAssetId);
    if (!edgeRecord) throw new Error(`Object '${node.objectId}' is missing its display edges`);
    let edges = displayEdgeCache.get(edgeRecord.id);
    if (!edges) {
      edges = decodeDisplayEdges(files[edgeRecord.path]);
      displayEdgeCache.set(edgeRecord.id, edges);
    }
    // Every state that references the asset shares one immutable edge list, which
    // keeps restored history cheap in memory and in later autosaves.
    definition.cadDisplayEdges = edges;
  }

  let importedMesh: WorkplaneShape["importedMesh"];
  if (node.importedMesh?.sourceAssetId) {
    const sourceAsset = runtimeAssetByArchiveId.get(node.importedMesh.sourceAssetId);
    if (!sourceAsset) throw new Error(`Object '${node.objectId}' is missing its imported source asset`);
    let promise = sourceMeshCache.get(sourceAsset.id);
    if (!promise) {
      promise = sourceImporter(sourceAsset);
      sourceMeshCache.set(sourceAsset.id, promise);
    }
    const regenerated = await promise;
    importedMesh = sharedImportedMesh(regenerated, sourceAsset.id, () => ({ ...regenerated, assetId: sourceAsset.id }));
  } else if (node.importedMesh?.meshAssetId) {
    const meshRecord = assetById.get(node.importedMesh.meshAssetId);
    if (!meshRecord) throw new Error(`Object '${node.objectId}' is missing its derived mesh`);
    let decoded = derivedMeshCache.get(meshRecord.id);
    if (!decoded) {
      decoded = decodeMeshCache(files[meshRecord.path]);
      derivedMeshCache.set(meshRecord.id, decoded);
    }
    const brepRecord = node.importedMesh.brepStepAssetId ? assetById.get(node.importedMesh.brepStepAssetId) : undefined;
    const reference = node.importedMesh;
    importedMesh = sharedImportedMesh(decoded, JSON.stringify(reference), () => ({
      ...decoded,
      baseWidth: reference.baseWidth,
      baseDepth: reference.baseDepth,
      baseHeight: reference.baseHeight,
      triangleCount: reference.triangleCount,
      sourceFormat: reference.sourceFormat,
      ...(brepRecord ? { brepStep: strFromU8(files[brepRecord.path]) } : {}),
    }));
  }

  const groupedShapes = node.groupedShapeNodeIds?.length
    ? await Promise.all(node.groupedShapeNodeIds.map((childId) => restoreShapeFromNode(childId, nodeById, assetById, files, runtimeAssetByArchiveId, sourceMeshCache, derivedMeshCache, displayEdgeCache, sourceImporter, new Set(restoring))))
    : undefined;
  const edgeTreatmentHistory = node.edgeTreatmentHistory?.length
    ? await Promise.all(node.edgeTreatmentHistory.map(async (entry) => ({
        id: entry.id,
        createdAt: entry.createdAt,
        feature: entry.feature as NonNullable<WorkplaneShape["edgeTreatmentHistory"]>[number]["feature"],
        before: await restoreShapeFromNode(entry.beforeNodeId, nodeById, assetById, files, runtimeAssetByArchiveId, sourceMeshCache, derivedMeshCache, displayEdgeCache, sourceImporter, new Set(restoring)),
        ...(entry.appliedFrame ? { appliedFrame: entry.appliedFrame as NonNullable<WorkplaneShape["edgeTreatmentHistory"]>[number]["appliedFrame"] } : {}),
      })))
    : undefined;
  const cadBrepRecord = node.cadBrepAssetId ? assetById.get(node.cadBrepAssetId) : undefined;
  restoring.delete(nodeId);
  return canonicalizeShape({
    ...(definition as WorkplaneShape),
    ...(importedMesh ? { importedMesh } : {}),
    ...(groupedShapes ? { groupedShapes } : {}),
    ...(edgeTreatmentHistory ? { edgeTreatmentHistory } : {}),
    ...(cadBrepRecord ? { cadBrep: strFromU8(files[cadBrepRecord.path]) } : {}),
  });
}

async function restoreV1(document: LylProjectDocumentV1, assetById: Map<string, LylAssetRecordV1>, files: ArchiveFiles, options: ImportLylOptions) {
  const runtimeAssetByArchiveId = new Map<string, ProjectAsset>();
  for (const record of document.assets.filter((asset) => asset.kind === "source")) {
    const bytes = new Uint8Array(files[record.path]);
    const asset: ProjectAsset = normalizeProjectAsset({
      id: record.id,
      name: record.fileName ?? `Imported ${record.sourceFormat?.toUpperCase() ?? "asset"}`,
      mediaType: record.mediaType,
      sourceFormat: record.sourceFormat as ProjectAssetSourceFormat,
      bytes,
      byteLength: bytes.byteLength,
      sha256: record.sha256,
    });
    runtimeAssetByArchiveId.set(record.id, asset);
  }
  const sourceMeshCache = new Map<string, Promise<NonNullable<WorkplaneShape["importedMesh"]>>>();
  const derivedMeshCache = new Map<string, ReturnType<typeof decodeMeshCache>>();
  const displayEdgeCache = new Map<string, CadDisplayEdge[]>();
  const sourceImporter = options.sourceImporter ?? defaultSourceImporter;
  const restoredStates = new Map<string, WorkplaneShape[]>();
  const restoredNotes = new Map<string, WorkplaneNote[]>();
  for (const state of document.states) {
    const nodeById = new Map(state.nodes.map((node) => [node.nodeId, node]));
    const shapes = await Promise.all(state.rootNodeIds.map((nodeId) => restoreShapeFromNode(
      nodeId,
      nodeById,
      assetById,
      files,
      runtimeAssetByArchiveId,
      sourceMeshCache,
      derivedMeshCache,
      displayEdgeCache,
      sourceImporter,
    )));
    restoredStates.set(state.id, shapes);
    restoredNotes.set(state.id, normalizeNotes(state.notes));
  }
  const history = document.history.entries.map((entry) => editorHistoryEntry(
    restoredStates.get(entry.stateId) ?? [],
    entry.selectedObjectIds,
    restoredNotes.get(entry.stateId) ?? [],
    entry.workplane,
    historyRecordedAt(entry.recordedAt),
  ));
  const shapes = restoredStates.get(document.sceneStateId) ?? [];
  const notes = restoredNotes.get(document.sceneStateId) ?? [];
  const placementWorkplane = normalizePlacementWorkplane(document.editor.placementWorkplane, document.editor.placementElevation);
  const hydrated = hydrateEditorHistoryState(shapes, history, document.history.index, "unlimited", notes, placementWorkplane);
  const restoredView = normalizeDesignView(document.editor.view);
  const restoredSavedViews = normalizeSavedViews(document.editor.savedViews);
  const restoredCornerRulers = normalizeSavedCornerRulers(document.editor.cornerRulers);
  const restoredTape = normalizeSavedTape(document.editor.tapeMeasurements);
  // The files were checked with the document; each is copied out of the archive.
  const attachments = (document.attachments ?? []).map((record): ProjectAttachment => {
    const asset = assetById.get(record.assetId) as LylAssetRecordV1;
    const bytes = new Uint8Array(files[asset.path]);
    return { id: record.id, name: record.fileName, mediaType: asset.mediaType, bytes, byteLength: bytes.byteLength, sha256: asset.sha256 };
  });
  if (hydrated.entries.length !== history.length || hydrated.index !== document.history.index) throw new Error("Undo history could not be restored without data loss");
  return {
    sourceProjectId: document.metadata.projectId,
    projectName: document.metadata.projectName,
    createdAt: parseIsoTimestamp(document.metadata.createdAt, "metadata.createdAt"),
    modifiedAt: parseIsoTimestamp(document.metadata.modifiedAt, "metadata.modifiedAt"),
    shapes: hydrated.entries[hydrated.index]?.shapes ?? shapes,
    notes: hydrated.entries[hydrated.index]?.notes ?? notes,
    history: hydrated.entries,
    historyIndex: hydrated.index,
    assets: [...runtimeAssetByArchiveId.values()],
    ...(attachments.length > 0 ? { attachments } : {}),
    workspace: normalizeWorkspaceSettings(document.editor.workspace),
    snapGrid: normalizeSnapGrid(document.editor.snapGrid),
    placementElevation: document.editor.placementElevation,
    placementWorkplane: normalizePlacementWorkplane(document.editor.placementWorkplane, document.editor.placementElevation),
    sketchPlacementWorkplane: normalizePlacementWorkplane(document.editor.sketchPlacementWorkplane),
    ...(restoredView ? { view: restoredView } : {}),
    ...(restoredSavedViews ? { savedViews: restoredSavedViews } : {}),
    ...(restoredCornerRulers ? { cornerRulers: restoredCornerRulers } : {}),
    ...(restoredTape ? { tapeMeasurements: restoredTape } : {}),
    ...(document.formatVersion < LYL_FORMAT_VERSION ? { migratedFromVersion: document.formatVersion } : {}),
  } satisfies LylRestoredProject;
}

function migrateV0(raw: Record<string, unknown>): LylRestoredProject {
  const project = objectRecord(raw.project, "project");
  const shapes = Array.isArray(raw.shapes) ? raw.shapes as WorkplaneShape[] : [];
  assertUniqueRuntimeObjectIds(shapes, "Legacy project");
  shapes.forEach((shape, index) => validateLegacyRuntimeShape(shape, `shapes[${index}]`));
  const historyRaw = Array.isArray(raw.history) ? raw.history as EditorHistoryEntry[] : undefined;
  const requestedIndex = typeof raw.historyIndex === "number" ? raw.historyIndex : undefined;
  const placementElevation = typeof raw.placementElevation === "number" && Number.isFinite(raw.placementElevation) ? raw.placementElevation : 0;
  const placementWorkplane = normalizePlacementWorkplane(
    raw.placementWorkplane,
    placementElevation,
  );
  const hydrated = hydrateEditorHistoryState(shapes.map(canonicalizeShape), historyRaw, requestedIndex, "unlimited", [], placementWorkplane);
  const now = Date.now();
  return {
    sourceProjectId: typeof project.id === "string" ? project.id : undefined,
    projectName: typeof project.name === "string" && project.name.trim() ? project.name : "Imported Layerling project",
    createdAt: safeTimestamp(typeof project.createdAt === "number" ? project.createdAt : now, now),
    modifiedAt: safeTimestamp(typeof project.modifiedAt === "number" ? project.modifiedAt : now, now),
    shapes: hydrated.entries[hydrated.index]?.shapes ?? shapes,
    history: hydrated.entries,
    historyIndex: hydrated.index,
    assets: [],
    workspace: normalizeWorkspaceSettings(raw.workspace),
    snapGrid: normalizeSnapGrid(raw.snapGrid),
    placementElevation,
    placementWorkplane,
    sketchPlacementWorkplane: normalizePlacementWorkplane(raw.sketchPlacementWorkplane),
    migratedFromVersion: 0,
  };
}

function validateLegacyRuntimeShape(shape: WorkplaneShape, label: string) {
  const definition = { ...shape } as Record<string, unknown>;
  const importedMesh = definition.importedMesh;
  const groupedShapes = definition.groupedShapes;
  const edgeHistory = definition.edgeTreatmentHistory;
  const cadBrep = definition.cadBrep;
  delete definition.importedMesh;
  delete definition.groupedShapes;
  delete definition.edgeTreatmentHistory;
  delete definition.cadBrep;
  validateShapeDefinition(definition, label);
  if (importedMesh) {
    const mesh = objectRecord(importedMesh, `${label}.importedMesh`);
    if (!Array.isArray(mesh.positions) || mesh.positions.length > LYL_LIMITS.meshNumbers || mesh.positions.some((value) => typeof value !== "number" || !Number.isFinite(value))) {
      throw new Error(`${label}.importedMesh has invalid positions`);
    }
  }
  if (Array.isArray(groupedShapes)) groupedShapes.forEach((child, index) => validateLegacyRuntimeShape(child as WorkplaneShape, `${label}.groupedShapes[${index}]`));
  if (Array.isArray(edgeHistory)) edgeHistory.forEach((entry, index) => validateLegacyRuntimeShape((entry as { before: WorkplaneShape }).before, `${label}.edgeTreatmentHistory[${index}].before`));
  if (cadBrep !== undefined && typeof cadBrep !== "string") throw new Error(`${label}.cadBrep is invalid`);
}

function projectInputBytes(input: ArrayBuffer | Uint8Array) {
  const bytes = input instanceof Uint8Array ? new Uint8Array(input) : new Uint8Array(input.slice(0));
  if (!bytes.byteLength) throw new Error(".lyl file is empty");
  return bytes;
}

/** Whether version `saved` (like "1.58.0") is newer than `current`. Anything unreadable is not. */
export function isNewerLayerlingVersion(saved: unknown, current: string) {
  if (typeof saved !== "string") return false;
  const parts = (value: string) => value.split(/[.-]/).slice(0, 3).map((part) => Number.parseInt(part, 10));
  const a = parts(saved);
  const b = parts(current);
  if (a.some((part) => !Number.isFinite(part))) return false;
  for (let index = 0; index < 3; index += 1) {
    if ((a[index] ?? 0) !== (b[index] ?? 0)) return (a[index] ?? 0) > (b[index] ?? 0);
  }
  return false;
}

/**
 * A design saved by a newer layerling may hold what this one does not know yet - a new shape,
 * a new setting, fonts of one's own. Where that stops it from opening, the reason says so, with
 * both versions, instead of the bare technical one (userErrors.ts turns it into the user's
 * language).
 */
function newerDesignError(saved: unknown, error: unknown) {
  if (!isNewerLayerlingVersion(saved, LYL_CREATED_WITH_VERSION)) return error;
  const detail = error instanceof Error ? error.message : String(error);
  return new Error(`This design was saved with layerling ${saved as string}, newer than this layerling ${LYL_CREATED_WITH_VERSION}, and holds something this version does not know yet (${detail})`);
}

async function readPackagedLyl(bytes: Uint8Array) {
  inspectZipBeforeExpansion(bytes);
  let files: ArchiveFiles;
  try {
    files = await unzipAsync(bytes);
  } catch (error) {
    throw new Error(`Could not expand .lyl package: ${error instanceof Error ? error.message : "corrupt ZIP data"}`);
  }
  let raw: unknown;
  try {
    raw = JSON.parse(strFromU8(files["project.json"]));
  } catch {
    throw new Error("project.json is malformed");
  }
  try {
    return { files, validated: await validateDocumentAndAssets(raw, files) };
  } catch (error) {
    throw newerDesignError((raw as { createdWithVersion?: unknown } | null)?.createdWithVersion, error);
  }
}

export async function inspectLylProjectPackage(input: ArrayBuffer | Uint8Array): Promise<LylProjectPackageSummary> {
  const bytes = projectInputBytes(input);
  const prefix = strFromU8(bytes.subarray(0, Math.min(bytes.length, 64))).trimStart();
  if (prefix.startsWith("{")) throw new Error("Shared storage accepts packaged .lyl files, not legacy JSON projects");
  const { validated } = await readPackagedLyl(bytes);
  return {
    projectName: validated.document.metadata.projectName,
    createdAt: Date.parse(validated.document.metadata.createdAt),
    modifiedAt: Date.parse(validated.document.metadata.modifiedAt),
    formatVersion: validated.document.formatVersion,
  };
}

/**
 * The package with another design name inside. Renaming a design on the start page changes its card only; the
 * saved package keeps the old name until the design is changed again, so whatever hands the package on writes the
 * card's name in first (#689). Everything else stays as it was; a package that already has the name comes back as is.
 */
export async function withLylProjectName(input: ArrayBuffer | Uint8Array, projectName: string): Promise<Uint8Array> {
  const bytes = projectInputBytes(input);
  const name = projectName.trim();
  const prefix = strFromU8(bytes.subarray(0, Math.min(bytes.length, 64))).trimStart();
  if (!name || prefix.startsWith("{")) return bytes;
  // Only project.json is read to compare the name: unpacking and checking every mesh of every design
  // made backing up many large designs slow (#991). The whole package is opened only to rename it.
  if (packagedLylProjectName(await unzipProjectJson(bytes)) === name) return bytes;
  const { files, validated } = await readPackagedLyl(bytes);
  if (validated.document.metadata.projectName === name) return bytes;
  const raw = JSON.parse(strFromU8(files["project.json"])) as { metadata: { projectName: string } };
  raw.metadata.projectName = name;
  files["project.json"] = strToU8(JSON.stringify(raw));
  return zipAsync(Object.fromEntries(Object.entries(files).sort(([a], [b]) => a.localeCompare(b))), 1);
}

export async function importLylProject(input: ArrayBuffer | Uint8Array, options: ImportLylOptions = {}): Promise<LylRestoredProject> {
  const bytes = projectInputBytes(input);
  const prefix = strFromU8(bytes.subarray(0, Math.min(bytes.length, 64))).trimStart();
  if (prefix.startsWith("{")) {
    if (bytes.byteLength > LYL_LIMITS.projectJsonBytes) throw new Error("Legacy JSON project exceeds the supported size limit");
    let raw: unknown;
    try {
      raw = JSON.parse(strFromU8(bytes));
    } catch {
      throw new Error("Legacy JSON project is malformed");
    }
    const document = objectRecord(raw, "Legacy .lyl project");
    if (!knownSchema(document.schema)) throw new Error("This file is not a layerling project");
    if (document.formatVersion === 0) return migrateV0(document);
    if (typeof document.formatVersion === "number" && document.formatVersion > LYL_FORMAT_VERSION) {
      throw new Error(`This project uses project format ${document.formatVersion}, which requires a newer layerling version`);
    }
    throw new Error("This legacy project version is not supported");
  }

  const { files, validated } = await readPackagedLyl(bytes);
  // The letters a design brought along: its texts draw in their own font, even where the font
  // is not installed. A complete font kept in this browser wins over them.
  validateFonts(validated.document.fonts).forEach((font) => registerCustomFont(font, false));
  const savedWith = validated.document.createdWithVersion;
  let restored: LylRestoredProject;
  try {
    restored = await restoreV1(validated.document, validated.assetById, files, options);
  } catch (error) {
    throw newerDesignError(savedWith, error);
  }
  // Opened, but saved by a newer layerling: what it added may look different here.
  return isNewerLayerlingVersion(savedWith, LYL_CREATED_WITH_VERSION) ? { ...restored, savedWithNewerVersion: savedWith } : restored;
}

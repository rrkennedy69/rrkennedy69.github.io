/**
 * Custom keyboard shortcuts. Settings > Keyboard shortcuts lets each row of the shortcut list
 * take a new combo; it is kept in localStorage. The editor's key handlers still listen for
 * the built-in keys, so a capture listener that runs before all of them translates: the new
 * combo is re-sent as the built-in one, and the built-in combo of a rebound row is swallowed.
 * The Shortcuts dialog reads the same bindings, so it always shows what the keys really do.
 */
import { useSyncExternalStore } from "react";
import { SHORTCUT_GROUPS, comboKeys, type Shortcut, type ShortcutGroup } from "@/lib/shortcutCatalog";

export const KEY_BINDINGS_STORAGE_KEY = "printcad.keyBindings.v1";
type Mode = ShortcutGroup["mode"];
export type Bindings = Record<string, string>;

const MODIFIERS = ["Ctrl", "Alt", "Shift"] as const;
const NAMED_KEYS = new Set(["Esc", "Delete", "Backspace", "Enter", "Home", "End", "Tab", "Insert", "Space", ...Array.from({ length: 12 }, (_, i) => `F${i + 1}`)]);
const PUNCTUATION = new Set([",", ".", "+", "−", "/", ";", "'", "[", "]", "\\", "`"]);

export function rowId(mode: Mode, shortcut: Pick<Shortcut, "label">) {
  return `${mode}:${shortcut.label}`;
}

function isMainKey(key: string) {
  return /^[A-Z0-9]$/.test(key) || NAMED_KEYS.has(key) || PUNCTUATION.has(key);
}

/** A concrete combo: modifiers plus one real key (no mouse, ranges or "any arrow"). */
export function isConcreteCombo(combo: string) {
  if (/[\/–]|Click|Drag|Wheel|0-9|</.test(combo) && combo !== "/") return false;
  const keys = comboKeys(combo);
  const main = keys[keys.length - 1];
  return keys.slice(0, -1).every((k) => (MODIFIERS as readonly string[]).includes(k)) && isMainKey(main);
}

/** Every row that can take a new combo: concrete keys, and no other row in its mode shares them. */
export function rebindableRows() {
  const out: { mode: Mode; group: ShortcutGroup; shortcut: Shortcut; id: string }[] = [];
  const seen = new Map<string, number>();
  for (const group of SHORTCUT_GROUPS) for (const s of group.shortcuts) for (const c of s.combos) seen.set(`${group.mode}|${c}`, (seen.get(`${group.mode}|${c}`) ?? 0) + 1);
  const ids = new Set<string>();
  for (const group of SHORTCUT_GROUPS) {
    for (const shortcut of group.shortcuts) {
      const id = rowId(group.mode, shortcut);
      if (ids.has(id)) continue;
      if (!shortcut.combos.every(isConcreteCombo)) continue;
      if (shortcut.combos.some((c) => (seen.get(`${group.mode}|${c}`) ?? 0) > 1)) continue;
      ids.add(id);
      out.push({ mode: group.mode, group, shortcut, id });
    }
  }
  return out;
}

export function isRebindable(mode: Mode, shortcut: Shortcut) {
  const id = rowId(mode, shortcut);
  return rebindableRows().some((row) => row.id === id);
}

// ---- storage -------------------------------------------------------------------------------
let cache: Bindings | null = null;
const listeners = new Set<() => void>();

export function readBindings(): Bindings {
  if (cache) return cache;
  let parsed: Bindings = {};
  try {
    const raw = typeof localStorage !== "undefined" ? localStorage.getItem(KEY_BINDINGS_STORAGE_KEY) : null;
    const value = raw ? JSON.parse(raw) : {};
    if (value && typeof value === "object") for (const [k, v] of Object.entries(value)) if (typeof v === "string" && isConcreteCombo(v)) parsed[k] = v;
  } catch {
    parsed = {};
  }
  cache = parsed;
  return cache;
}

function writeBindings(next: Bindings) {
  cache = next;
  try {
    if (Object.keys(next).length) localStorage.setItem(KEY_BINDINGS_STORAGE_KEY, JSON.stringify(next));
    else localStorage.removeItem(KEY_BINDINGS_STORAGE_KEY);
  } catch {
    /* private mode: the binding still holds for this session */
  }
  listeners.forEach((l) => l());
}

export function setBinding(id: string, combo: string) {
  const row = rebindableRows().find((r) => r.id === id);
  if (!row || !isConcreteCombo(combo)) return;
  const next = { ...readBindings() };
  if (row.shortcut.combos.length === 1 && row.shortcut.combos[0] === combo) delete next[id];
  else next[id] = combo;
  writeBindings(next);
}
export function resetBinding(id: string) {
  const next = { ...readBindings() };
  delete next[id];
  writeBindings(next);
}
export function resetAllBindings() {
  writeBindings({});
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  const onStorage = (event: StorageEvent) => {
    if (event.key === KEY_BINDINGS_STORAGE_KEY) {
      cache = null;
      listener();
    }
  };
  window.addEventListener("storage", onStorage);
  return () => {
    listeners.delete(listener);
    window.removeEventListener("storage", onStorage);
  };
}
const EMPTY: Bindings = {};
export function useKeyBindings(): Bindings {
  return useSyncExternalStore(subscribe, readBindings, () => EMPTY);
}

/** What a row answers to now. */
export function effectiveCombos(mode: Mode, shortcut: Shortcut, bindings: Bindings = readBindings()): string[] {
  const custom = bindings[rowId(mode, shortcut)];
  return custom ? [custom] : shortcut.combos;
}

/** Rows in the same mode that answer to the same combo as `id` would with `combo`. */
export function conflictsFor(id: string, combo: string, bindings: Bindings = readBindings()) {
  const [mode] = id.split(":") as [Mode];
  const out: { group: ShortcutGroup; shortcut: Shortcut }[] = [];
  const done = new Set<string>();
  for (const group of SHORTCUT_GROUPS) {
    if (group.mode !== mode) continue;
    for (const shortcut of group.shortcuts) {
      const other = rowId(mode, shortcut);
      if (other === id || done.has(other)) continue;
      if (effectiveCombos(mode, shortcut, bindings).includes(combo)) {
        done.add(other);
        out.push({ group, shortcut });
      }
    }
  }
  return out;
}

// ---- keys <-> combos -----------------------------------------------------------------------
const KEY_NAMES: Record<string, string> = { Escape: "Esc", " ": "Space", "-": "−", "=": "+", "_": "−" };

/** The combo a key press spells, or null for a lone modifier. */
export function comboFromEvent(event: Pick<KeyboardEvent, "key" | "code" | "ctrlKey" | "metaKey" | "altKey" | "shiftKey">): string | null {
  if (["Control", "Meta", "Alt", "Shift", "AltGraph", "CapsLock", "OS"].includes(event.key)) return null;
  let main: string;
  if (/^Key[A-Z]$/.test(event.code)) main = event.code.slice(3);
  else if (/^Digit[0-9]$/.test(event.code)) main = event.code.slice(5);
  else if (/^Numpad[0-9]$/.test(event.code)) main = event.code.slice(6);
  else if (event.code === "NumpadAdd") main = "+";
  else if (event.code === "NumpadSubtract") main = "−";
  else main = KEY_NAMES[event.key] ?? (event.key.length === 1 ? event.key.toUpperCase() : event.key);
  if (!isMainKey(main)) return null;
  const punct = PUNCTUATION.has(main);
  const parts: string[] = [];
  if (event.ctrlKey || event.metaKey) parts.push("Ctrl");
  if (event.altKey) parts.push("Alt");
  if (event.shiftKey && !punct) parts.push("Shift");
  parts.push(main);
  return parts.join("+");
}

const NAMED_TO_KEY: Record<string, [string, string]> = {
  Esc: ["Escape", "Escape"], Space: [" ", "Space"], "+": ["+", "Equal"], "−": ["-", "Minus"], ",": [",", "Comma"], ".": [".", "Period"],
  "/": ["/", "Slash"], ";": [";", "Semicolon"], "'": ["'", "Quote"], "[": ["[", "BracketLeft"], "]": ["]", "BracketRight"], "\\": ["\\", "Backslash"], "`": ["`", "Backquote"],
};

function appleKeyboard() {
  return typeof navigator !== "undefined" && /Macintosh|Mac OS X|iPhone|iPad|iPod/.test(navigator.userAgent);
}

/** The key event the built-in handlers listen for, for a combo. */
export function eventInitFromCombo(combo: string): KeyboardEventInit {
  const keys = comboKeys(combo);
  const main = keys[keys.length - 1];
  const mods = new Set(keys.slice(0, -1));
  const shift = mods.has("Shift");
  let key = main;
  let code = main;
  if (/^[A-Z]$/.test(main)) {
    key = shift ? main : main.toLowerCase();
    code = `Key${main}`;
  } else if (/^[0-9]$/.test(main)) code = `Digit${main}`;
  else if (NAMED_TO_KEY[main]) [key, code] = NAMED_TO_KEY[main];
  const ctrl = mods.has("Ctrl");
  const apple = appleKeyboard();
  return { key, code, ctrlKey: ctrl && !apple, metaKey: ctrl && apple, altKey: mods.has("Alt"), shiftKey: shift, bubbles: true, cancelable: true, composed: true };
}

// ---- the translating listener --------------------------------------------------------------
const SYNTHETIC = Symbol.for("printcad.reboundKey");

function editable(target: EventTarget | null) {
  const el = target as HTMLElement | null;
  if (!el || !el.tagName) return false;
  return el.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName) || !!el.closest?.("[data-key-capture]");
}

export function currentMode(): Mode {
  return typeof document !== "undefined" && document.querySelector(".sketch-workspace-stage") ? "sketch" : "geometry";
}

/** For a mode: new combo -> built-in combo to send, and built-in combos that are now silent. */
export function remapTable(mode: Mode, bindings: Bindings = readBindings()) {
  const send = new Map<string, string>();
  const silence = new Set<string>();
  for (const row of rebindableRows()) {
    if (row.mode !== mode) continue;
    const custom = bindings[row.id];
    if (!custom) continue;
    send.set(custom, row.shortcut.combos[0]);
    row.shortcut.combos.forEach((c) => silence.add(c));
  }
  for (const c of send.keys()) silence.delete(c);
  return { send, silence };
}

function onKeyDown(event: KeyboardEvent) {
  if ((event as unknown as Record<symbol, boolean>)[SYNTHETIC]) return;
  const bindings = readBindings();
  if (Object.keys(bindings).length === 0 || editable(event.target)) return;
  const combo = comboFromEvent(event);
  if (!combo) return;
  const { send, silence } = remapTable(currentMode(), bindings);
  const target = send.get(combo);
  if (target && target !== combo) {
    event.preventDefault();
    event.stopImmediatePropagation();
    const synthetic = new KeyboardEvent("keydown", eventInitFromCombo(target));
    (synthetic as unknown as Record<symbol, boolean>)[SYNTHETIC] = true;
    (event.target ?? window).dispatchEvent(synthetic);
    return;
  }
  if (!target && silence.has(combo)) {
    event.preventDefault();
    event.stopImmediatePropagation();
  }
}

let installed = false;
/** Called at module load by the editors, before any of their own key listeners exist. */
export function installKeyBindings() {
  if (installed || typeof window === "undefined") return;
  installed = true;
  window.addEventListener("keydown", onKeyDown, true);
}
installKeyBindings();

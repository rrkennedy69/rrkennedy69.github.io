import { useSyncExternalStore } from "react";
import { meshAabb } from "./editorMeshCore";
import type { WorkplaneShape } from "@/types/layerling";

/** Gravity (Manage → Gravity): moved or newly placed parts drop along Z onto the plate or the part below. */
export const GRAVITY_STORAGE_KEY = "printcad.gravity.v1";
const listeners = new Set<() => void>();
let cached: boolean | null = null;

export function gravityEnabled(): boolean {
  if (cached !== null) return cached;
  try {
    cached = typeof window !== "undefined" && window.localStorage.getItem(GRAVITY_STORAGE_KEY) === "1";
  } catch {
    cached = false;
  }
  return cached;
}

export function setGravityEnabled(on: boolean) {
  cached = on;
  try { window.localStorage.setItem(GRAVITY_STORAGE_KEY, on ? "1" : "0"); } catch { /* private mode */ }
  listeners.forEach((listener) => listener());
}

export function useGravityEnabled() {
  return useSyncExternalStore(
    (listener) => { listeners.add(listener); return () => listeners.delete(listener); },
    gravityEnabled,
    () => false,
  );
}

const EPS = 1e-6;

/**
 * Drops the parts `ids` (moved together, as one rigid set) straight down until the lowest of them
 * rests on the plate (height 0) or on the top of the highest solid, non-hole part whose footprint
 * overlaps theirs and that sits below them. Footprints are axis-aligned boxes. Returns the shapes
 * unchanged when nothing has to move.
 */
export function dropShapes(shapes: readonly WorkplaneShape[], ids: readonly string[]): WorkplaneShape[] {
  const moving = new Set(ids);
  const movers = shapes.filter((shape) => moving.has(shape.id) && !shape.locked);
  if (!movers.length) return shapes as WorkplaneShape[];
  const boxes = movers.map((shape) => ({ shape, box: meshAabb(shape) }));
  const bottom = Math.min(...boxes.map(({ box }) => box.minY));
  let rest = 0;
  for (const other of shapes) {
    if (moving.has(other.id) || other.hole || other.hidden) continue;
    const ob = meshAabb(other);
    if (ob.maxY > bottom + EPS) continue; // not below the set
    const overlaps = boxes.some(({ box }) =>
      box.minX < ob.maxX - EPS && box.maxX > ob.minX + EPS && box.minZ < ob.maxZ - EPS && box.maxZ > ob.minZ + EPS);
    if (overlaps && ob.maxY > rest) rest = ob.maxY;
  }
  const delta = rest - bottom;
  if (Math.abs(delta) < EPS) return shapes as WorkplaneShape[];
  return shapes.map((shape) => moving.has(shape.id) && !shape.locked
    ? { ...shape, elevation: (shape.elevation ?? 0) + delta }
    : shape);
}

/** The ids whose position changed between two versions of the scene: what a drag moved. */
export function movedIds(before: readonly WorkplaneShape[], after: readonly WorkplaneShape[]): string[] {
  const old = new Map(before.map((shape) => [shape.id, shape]));
  return after.filter((shape) => {
    const prior = old.get(shape.id);
    return prior && (prior.x !== shape.x || prior.z !== shape.z || (prior.elevation ?? 0) !== (shape.elevation ?? 0));
  }).map((shape) => shape.id);
}

"use client";

import { useEffect, useState } from "react";
import { BAMBU_MATERIALS, type BambuMaterial } from "@/lib/bambuFilaments";
import type { BambuImported, BambuValue } from "@/lib/bambuSettingsImport";

/** One filament loaded in the printer (AMS slot order), as read from a Bambu Studio project or preset. */
export type LoadedFilament = { slot: number; color: string; type: string; name: string; materialId?: string; colorName?: string; code?: string };
export type LoadedFilamentState = { filaments: LoadedFilament[]; source: string; importedAt: string };

const KEY = "printcad.loadedFilaments.v1";
export const LOADED_FILAMENTS_EVENT = "printcad:loaded-filaments";

export function readLoadedFilaments(): LoadedFilamentState | null {
  try { const v = JSON.parse(localStorage.getItem(KEY) ?? "null") as LoadedFilamentState | null; return v && Array.isArray(v.filaments) ? v : null; } catch { return null; }
}
export function writeLoadedFilaments(state: LoadedFilamentState | null) {
  try { if (state) localStorage.setItem(KEY, JSON.stringify(state)); else localStorage.removeItem(KEY); } catch { /* storage full or blocked */ }
  window.dispatchEvent(new Event(LOADED_FILAMENTS_EVENT));
}
export function useLoadedFilaments() {
  const [state, setState] = useState<LoadedFilamentState | null>(null);
  useEffect(() => {
    const read = () => setState(readLoadedFilaments());
    read();
    window.addEventListener(LOADED_FILAMENTS_EVENT, read);
    window.addEventListener("storage", read);
    return () => { window.removeEventListener(LOADED_FILAMENTS_EVENT, read); window.removeEventListener("storage", read); };
  }, []);
  return state;
}

const list = (v: BambuValue | undefined): string[] => (v === undefined ? [] : Array.isArray(v) ? v : String(v).split(";")).map((s) => String(s).trim());
/** "#FF6A13FF" / "#ff6a13" -> "#ff6a13". */
const hex = (s: string) => { const m = /^#?([0-9a-f]{6})([0-9a-f]{2})?$/i.exec(s.trim()); return m ? `#${m[1].toLowerCase()}` : ""; };
/** "Bambu PLA Basic @BBL X1C" -> "PLA Basic". */
const cleanName = (s: string) => s.replace(/\s*@.*$/, "").replace(/^Bambu\s+/i, "").replace(/^Generic\s+/i, "Generic ").trim();

function findMaterial(id: string | undefined, name: string, type: string): BambuMaterial | undefined {
  if (id) { const byId = BAMBU_MATERIALS.find((m) => m.id === id); if (byId) return byId; }
  const n = cleanName(name).toLowerCase();
  return BAMBU_MATERIALS.find((m) => m.name.toLowerCase() === n) ?? (n.startsWith("generic") || !n ? undefined : BAMBU_MATERIALS.find((m) => n.includes(m.name.toLowerCase())))
    ?? (type ? undefined : undefined);
}

/** Pulls the loaded filaments (colour, type, preset name, id) out of imported Bambu settings. */
export function extractLoadedFilaments(imported: BambuImported): LoadedFilament[] {
  const raw = { ...imported.raw, ...imported.identity };
  const colours = list(raw.filament_colour ?? raw.default_filament_colour);
  const types = list(raw.filament_type);
  const names = list(raw.filament_settings_id ?? raw.name ?? raw.filament_vendor);
  const ids = list(raw.filament_ids ?? raw.filament_id);
  const count = Math.max(colours.length, types.length, names.length);
  const out: LoadedFilament[] = [];
  for (let i = 0; i < count; i++) {
    const color = hex(colours[i] ?? colours[0] ?? "") || "#cccccc";
    const type = types[i] ?? types[0] ?? "";
    const name = names[i] ?? names[0] ?? type;
    const material = findMaterial(ids[i], name, type);
    // Bambu colour name: same hex in this material first, then in any material of the same type.
    const pool = material ? [material] : BAMBU_MATERIALS.filter((m) => m.type === type);
    let colorName: string | undefined; let code: string | undefined;
    for (const m of pool) { const c = m.colors.find((x) => x.h.toLowerCase() === color); if (c) { colorName = c.n; code = c.c || undefined; break; } }
    out.push({ slot: i + 1, color, type: type || material?.type || "", name: cleanName(name) || material?.name || type || "Filament", ...(material ? { materialId: material.id } : {}), ...(colorName ? { colorName } : {}), ...(code ? { code } : {}) });
  }
  return out;
}

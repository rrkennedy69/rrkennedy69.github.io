import { useSyncExternalStore } from "react";

/** The build plate's colour (Manage → plate colour), kept per browser. Night Vision ignores it. */
export const PLATE_COLOR_STORAGE_KEY = "printcad.plateColor.v1";
export const DEFAULT_PLATE_COLOR = "#c7ccd1";
export const PLATE_COLOR_PRESETS = [
  { id: "default", color: DEFAULT_PLATE_COLOR },
  { id: "darkGray", color: "#4a4f55" },
  { id: "black", color: "#1b1c1e" },
  { id: "goldPei", color: "#c9a14a" },
  { id: "silver", color: "#d9dde1" },
  { id: "white", color: "#f4f5f6" },
  { id: "blue", color: "#3f6fb0" },
] as const;
const EVENT = "printcad-plate-color";

export function normalizePlateColor(value: unknown): string {
  return typeof value === "string" && /^#[0-9a-f]{6}$/i.test(value) ? value.toLowerCase() : DEFAULT_PLATE_COLOR;
}
export function plateColor(): string {
  try { return normalizePlateColor(globalThis.localStorage?.getItem(PLATE_COLOR_STORAGE_KEY)); } catch { return DEFAULT_PLATE_COLOR; }
}
export function setPlateColor(color: string) {
  try { globalThis.localStorage?.setItem(PLATE_COLOR_STORAGE_KEY, normalizePlateColor(color)); } catch { /* session only */ }
  if (typeof window !== "undefined") window.dispatchEvent(new Event(EVENT));
}
export function usePlateColor(): string {
  return useSyncExternalStore(
    (notify) => { window.addEventListener(EVENT, notify); window.addEventListener("storage", notify); return () => { window.removeEventListener(EVENT, notify); window.removeEventListener("storage", notify); }; },
    plateColor,
    () => DEFAULT_PLATE_COLOR,
  );
}

function luminance(hex: string) {
  const [r, g, b] = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255).map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4));
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
function mix(hex: string, toward: string, amount: number) {
  const c = (h: string, i: number) => parseInt(h.slice(i, i + 2), 16);
  return "#" + [1, 3, 5].map((i) => Math.round(c(hex, i) + (c(toward, i) - c(hex, i)) * amount).toString(16).padStart(2, "0")).join("");
}
/** Grid, outline and edge colours that keep contrast on a plate of this colour. */
export function plateContrast(color: string) {
  const plate = normalizePlateColor(color);
  const light = luminance(plate) > 0.28;
  return {
    plate,
    light,
    grid: light ? mix(plate, "#000000", 0.22) : mix(plate, "#ffffff", 0.22),
    gridMajor: light ? mix(plate, "#000000", 0.42) : mix(plate, "#ffffff", 0.42),
    outline: light ? mix(plate, "#000000", 0.55) : mix(plate, "#ffffff", 0.55),
    rim: light ? mix(plate, "#000000", 0.12) : mix(plate, "#ffffff", 0.08),
  };
}

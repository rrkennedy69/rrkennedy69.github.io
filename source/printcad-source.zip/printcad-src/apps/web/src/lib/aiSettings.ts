/**
 * AI helper settings. The API key lives only in this browser's localStorage and is sent straight from
 * the browser to the endpoint the user chose - never to PrintCaddy's servers.
 */
export type AiProvider = "local" | "openai-compatible" | "anthropic";

export type AiSettings = {
  provider: AiProvider;
  /** OpenAI-compatible base URL (xAI, OpenAI, OpenRouter, a local server ...). */
  baseUrl: string;
  model: string;
  apiKey: string;
  /** Send a picture of the selected area along when the model can see. */
  vision: boolean;
  /** On-device model id (WebLLM). */
  localModel: string;
  /** The user agreed to download the on-device model. */
  localConsent: boolean;
};

export const AI_SETTINGS_KEY = "printcad.aiSettings.v1";
export const AI_SETTINGS_EVENT = "printcad:ai-settings";

export const AI_PRESETS: { id: string; label: string; provider: AiProvider; baseUrl: string; model: string }[] = [
  { id: "xai", label: "xAI (Grok)", provider: "openai-compatible", baseUrl: "https://api.x.ai/v1", model: "grok-4" },
  { id: "openai", label: "OpenAI", provider: "openai-compatible", baseUrl: "https://api.openai.com/v1", model: "gpt-4o-mini" },
  { id: "anthropic", label: "Anthropic", provider: "anthropic", baseUrl: "https://api.anthropic.com/v1", model: "claude-sonnet-4-5" },
  { id: "custom", label: "Other OpenAI-compatible", provider: "openai-compatible", baseUrl: "http://localhost:11434/v1", model: "llama3.2" },
];

export const LOCAL_MODELS: { id: string; label: string; downloadMb: number }[] = [
  { id: "Qwen2.5-1.5B-Instruct-q4f16_1-MLC", label: "Qwen2.5 1.5B (better)", downloadMb: 1000 },
  { id: "Qwen2.5-0.5B-Instruct-q4f16_1-MLC", label: "Qwen2.5 0.5B (smallest)", downloadMb: 350 },
];

export const DEFAULT_AI_SETTINGS: AiSettings = {
  provider: "local",
  baseUrl: "https://api.x.ai/v1",
  model: "grok-4",
  apiKey: "",
  vision: true,
  localModel: LOCAL_MODELS[0].id,
  localConsent: false,
};

export function readAiSettings(): AiSettings {
  if (typeof window === "undefined") return DEFAULT_AI_SETTINGS;
  try {
    const raw = JSON.parse(window.localStorage.getItem(AI_SETTINGS_KEY) ?? "null");
    if (!raw || typeof raw !== "object") return DEFAULT_AI_SETTINGS;
    const s = { ...DEFAULT_AI_SETTINGS, ...raw } as AiSettings;
    if (!["local", "openai-compatible", "anthropic"].includes(s.provider)) s.provider = "local";
    return s;
  } catch {
    return DEFAULT_AI_SETTINGS;
  }
}

export function writeAiSettings(next: AiSettings) {
  try {
    window.localStorage.setItem(AI_SETTINGS_KEY, JSON.stringify(next));
    window.dispatchEvent(new Event(AI_SETTINGS_EVENT));
  } catch { /* storage blocked */ }
}

/** True when a cloud key is set and chosen. */
export function usesCloud(s: AiSettings) {
  return s.provider !== "local" && s.apiKey.trim().length > 0;
}

export function maskKey(key: string) {
  const k = key.trim();
  if (!k) return "";
  return k.length <= 8 ? "••••" : `${k.slice(0, 4)}••••••••${k.slice(-4)}`;
}

/** Which settings tab to open next ("ai" from the AI panel's gear). */
export const pendingSettingsSection: { value: string | null } = { value: null };

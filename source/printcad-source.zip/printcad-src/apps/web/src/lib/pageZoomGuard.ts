/**
 * Keeps iPad Safari (and Mac Safari) from zooming the whole page on a pinch, and routes the pinch to the view under it.
 * iOS ignores user-scalable=no, so every gesture is refused at the window. The guard is also the ONE place a Safari
 * pinch (gesturechange with a scale) is turned into zoom: views register with registerPinchTarget, and the guard
 * finds the view under the cursor by its bounding box (an overlay above the canvas still counts). A Ctrl wheel
 * (pinch in Chrome/Edge, possibly iPadOS) aimed at an overlay above a view is re-sent to that view; one aimed at the
 * view itself goes through untouched. While a Safari gesture is running, real Ctrl wheel steps are dropped so a
 * browser that sends both never zooms twice.
 */
export const PAGE_ZOOM_GUARD_SCRIPT = `try{(function(){var o={passive:false,capture:true};var w=window;var T=[];var px=-1,py=-1,gs=1,ga=false,gt=null;
w.__pcPinch={add:function(el,fn){var t={el:el,fn:fn};T.push(t);return function(){var i=T.indexOf(t);if(i>=0)T.splice(i,1)}}};
function hit(x,y,tg){for(var i=T.length-1;i>=0;i--){var t=T[i];if(!t.el.isConnected)continue;if(tg&&t.el.contains&&t.el.contains(tg))return t;var r=t.el.getBoundingClientRect();if(r.width>0&&x>=r.left&&x<=r.right&&y>=r.top&&y<=r.bottom)return t}return null}
function pos(e){var x=typeof e.clientX==="number"&&(e.clientX||e.clientY)?e.clientX:px,y=typeof e.clientX==="number"&&(e.clientX||e.clientY)?e.clientY:py;if(x<0){x=innerWidth/2;y=innerHeight/2}return [x,y]}
w.addEventListener("pointermove",function(e){px=e.clientX;py=e.clientY},{passive:true,capture:true});
w.addEventListener("pointerover",function(e){px=e.clientX;py=e.clientY},{passive:true,capture:true});
function g(e){if(e.cancelable)e.preventDefault();var p=pos(e);if(e.type==="gesturestart"){gs=1;ga=true;gt=hit(p[0],p[1],e.target);return}
if(e.type==="gestureend"){ga=false;gt=null;return}
var s=e.scale;if(!(typeof s==="number"&&s>0))return;var r=s/gs;gs=s;var t=gt||hit(p[0],p[1],e.target);if(t&&r!==1){try{t.fn(r,p[0],p[1])}catch(_){}}}
w.addEventListener("gesturestart",g,o);w.addEventListener("gesturechange",g,o);w.addEventListener("gestureend",g,o);
w.addEventListener("wheel",function(e){if(!e.ctrlKey||e.__pcRouted)return;if(e.cancelable)e.preventDefault();if(ga){e.stopImmediatePropagation();return}
var t=hit(e.clientX,e.clientY,null);if(!t||t.el.contains(e.target))return;e.stopImmediatePropagation();var c=new WheelEvent("wheel",{deltaX:e.deltaX,deltaY:e.deltaY,deltaMode:e.deltaMode,ctrlKey:true,clientX:e.clientX,clientY:e.clientY,bubbles:true,cancelable:true});c.__pcRouted=1;t.el.dispatchEvent(c)},o);
w.addEventListener("touchmove",function(e){if(e.touches&&e.touches.length>1&&e.cancelable)e.preventDefault()},o);
var lt=0;w.addEventListener("touchend",function(e){var s=e.timeStamp;if(s-lt<300&&e.cancelable&&e.changedTouches.length===1){var q=e.target;if(q&&q.closest&&q.closest("canvas"))e.preventDefault()}lt=s},o);
document.documentElement.dataset.pageZoomGuard="on"})()}catch(e){}`;

type PinchFn = (ratio: number, clientX: number, clientY: number) => void;
/** Lets the page guard send a Safari pinch (scale ratio since the last step) to this element. Returns the remover. */
export function registerPinchTarget(el: Element, fn: PinchFn): () => void {
  const reg = (globalThis as { __pcPinch?: { add: (el: Element, fn: PinchFn) => () => void } }).__pcPinch;
  return reg ? reg.add(el, fn) : () => {};
}

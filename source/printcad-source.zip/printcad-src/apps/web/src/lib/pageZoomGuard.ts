/**
 * Keeps iPad Safari (and Mac Safari) from zooming the whole page on a pinch, whether made with fingers or a
 * Magic Keyboard trackpad. iOS ignores user-scalable=no, so the gestures are refused at the window, before
 * anything else sees them. A pinch over the 3D view is still turned into zoom by viewportScene.ts, whose own
 * canvas listeners run on the way down (these only call preventDefault and never stop propagation).
 */
export const PAGE_ZOOM_GUARD_SCRIPT = `try{(function(){var o={passive:false,capture:true};var w=window;function n(e){if(e.cancelable)e.preventDefault()}
w.addEventListener("gesturestart",n,o);w.addEventListener("gesturechange",n,o);w.addEventListener("gestureend",n,o);
w.addEventListener("wheel",function(e){if(e.ctrlKey&&e.cancelable)e.preventDefault()},o);
w.addEventListener("touchmove",function(e){if(e.touches&&e.touches.length>1&&e.cancelable)e.preventDefault()},o);
var t=0;w.addEventListener("touchend",function(e){var s=e.timeStamp;if(s-t<300&&e.cancelable&&e.changedTouches.length===1){var g=e.target;if(g&&g.closest&&g.closest("canvas"))e.preventDefault()}t=s},o);
document.documentElement.dataset.pageZoomGuard="on"})()}catch(e){}`;

/**
 * Keeps iPad Safari (and Mac Safari) from zooming the whole page on a pinch, and routes the pinch to the view under it.
 * iOS ignores user-scalable=no, so every gesture is refused at the window. The guard is also the ONE place a Safari
 * pinch (gesturechange with a scale) is turned into zoom: views register with registerPinchTarget, and the guard
 * finds the view under the cursor by its bounding box (an overlay above the canvas still counts). A Ctrl wheel
 * (pinch in Chrome/Edge, possibly iPadOS) aimed at an overlay above a view is re-sent to that view; one aimed at the
 * view itself goes through untouched. While a Safari gesture is running, real Ctrl wheel steps are dropped so a
 * browser that sends both never zooms twice.
 */
export const PAGE_ZOOM_GUARD_SCRIPT = `try{(function(){var o={passive:false,capture:true},q={passive:true,capture:true};var w=window;var T=[];var px=-1,py=-1,gs=1,ga=false,gt=null;
var src=null,srcAt=0;function lock(k){var n=Date.now();if(src&&src!==k&&n-srcAt<250)return false;src=k;srcAt=n;return true}
var dbg=null,L=[];try{if(/[?&]debugInput=1/.test(location.search)){dbg=1}}catch(_){}
function log(m){if(!dbg)return;L.push(m);if(L.length>28)L.shift();if(dbg===1&&document.body){dbg=document.createElement("pre");dbg.id="pc-debug-input";dbg.style.cssText="position:fixed;left:4px;bottom:4px;z-index:2147483647;max-width:96vw;max-height:55vh;overflow:hidden;margin:0;padding:6px;background:rgba(0,0,0,.78);color:#7f7;font:11px/1.3 ui-monospace,monospace;pointer-events:none;white-space:pre-wrap";document.body.appendChild(dbg)}if(dbg!==1)dbg.textContent="debugInput  "+navigator.userAgent.slice(0,90)+"\\n"+L.join("\\n")}
function tn(e){var t=e.target;return t&&t.tagName?t.tagName.toLowerCase()+(t.className&&typeof t.className==="string"?"."+t.className.split(" ")[0]:""):"?"}
w.__pcPinch={add:function(el,fn){var t={el:el,fn:fn};T.push(t);return function(){var i=T.indexOf(t);if(i>=0)T.splice(i,1)}},log:log};
function hit(x,y,tg){for(var i=T.length-1;i>=0;i--){var t=T[i];if(!t.el.isConnected)continue;if(tg&&t.el.contains&&t.el.contains(tg))return t;var r=t.el.getBoundingClientRect();if(r.width>0&&x>=r.left&&x<=r.right&&y>=r.top&&y<=r.bottom)return t}return null}
function pos(e){var ok=typeof e.clientX==="number"&&(e.clientX||e.clientY);var x=ok?e.clientX:px,y=ok?e.clientY:py;if(x<0){x=innerWidth/2;y=innerHeight/2}return [x,y]}
function zoom(k,t,r,x,y){if(!t||!(r>0)||r===1)return;if(!lock(k)){log("  drop "+k+" (lock "+src+")");return}try{t.fn(r,x,y);log("  ZOOM via "+k+" x"+r.toFixed(3))}catch(err){log("  zoom error "+err)}}
w.addEventListener("pointermove",function(e){px=e.clientX;py=e.clientY;if(dbg&&e.pointerType!=="mouse")log("pointermove "+e.pointerType+" id"+e.pointerId)},q);
w.addEventListener("pointerover",function(e){px=e.clientX;py=e.clientY},q);
["pointerdown","pointerup","pointercancel"].forEach(function(n){w.addEventListener(n,function(e){log(n+" "+e.pointerType+" id"+e.pointerId+" btn"+e.button+" "+tn(e))},q)});
/* Safari: refusing gesturestart can end the sequence, so only change/end are refused; the viewport meta, touch-action and the change refusal stop page zoom. */
function g(e){var p=pos(e);log(e.type+" scale="+(e.scale&&e.scale.toFixed?e.scale.toFixed(3):e.scale)+" xy="+Math.round(p[0])+","+Math.round(p[1])+" "+tn(e));
if(e.type==="gesturestart"){gs=1;ga=true;gt=hit(p[0],p[1],e.target);return}
if(e.cancelable)e.preventDefault();
if(e.type==="gestureend"){ga=false;gt=null;return}
var s=e.scale;if(!(typeof s==="number"&&s>0))return;var r=s/gs;gs=s;zoom("gesture",gt||hit(p[0],p[1],e.target),r,p[0],p[1])}
w.addEventListener("gesturestart",g,q);w.addEventListener("gesturechange",g,o);w.addEventListener("gestureend",g,o);
w.addEventListener("wheel",function(e){if(e.ctrlKey||dbg&&Math.abs(e.deltaY)>0)log("wheel ctrl="+e.ctrlKey+" dY="+e.deltaY.toFixed(2)+" mode"+e.deltaMode+(e.__pcRouted?" routed":"")+" "+tn(e));
if(!e.ctrlKey||e.__pcRouted)return;if(e.cancelable)e.preventDefault();
if(ga||!lock("wheel")){e.stopImmediatePropagation();log("  drop wheel (lock "+src+")");return}
var t=hit(e.clientX,e.clientY,null);if(!t)return;if(t.el.contains(e.target)){log("  wheel -> view");return}
e.stopImmediatePropagation();var c=new WheelEvent("wheel",{deltaX:e.deltaX,deltaY:e.deltaY,deltaMode:e.deltaMode,ctrlKey:true,clientX:e.clientX,clientY:e.clientY,bubbles:true,cancelable:true});c.__pcRouted=1;t.el.dispatchEvent(c);log("  wheel re-sent to view")},o);
/* Indirect (trackpad) touches: some iPadOS versions turn a trackpad pinch into two touches of touchType "indirect". */
var td=0,tt=null;function dist(ts){var a=ts[0],b=ts[1];return Math.hypot(a.clientX-b.clientX,a.clientY-b.clientY)}
function isInd(e){for(var i=0;i<e.touches.length;i++)if(e.touches[i].touchType==="indirect")return true;return false}
["touchstart","touchmove","touchend","touchcancel"].forEach(function(n){w.addEventListener(n,function(e){var ts=e.touches||[];var ty=[];for(var i=0;i<ts.length;i++)ty.push(ts[i].touchType||"?");
if(n!=="touchmove"||dbg&&L.length&&L[L.length-1].indexOf("touchmove")!==0)log(n+" n="+ts.length+" ["+ty.join(",")+"] "+tn(e));
var inView=e.target&&T.some(function(t){return t.el.contains(e.target)});
if(n==="touchmove"&&ts.length>1&&e.cancelable&&!inView)e.preventDefault();
if(ts.length===2&&isInd(e)){var d=dist(ts);var cx=(ts[0].clientX+ts[1].clientX)/2,cy=(ts[0].clientY+ts[1].clientY)/2;
if(n==="touchstart"||!td){td=d;tt=hit(px>=0?px:cx,px>=0?py:cy,e.target);return}
if(n==="touchmove"&&td>0&&d>0&&!ga){if(e.cancelable)e.preventDefault();zoom("indirect-touch",tt,d/td,px>=0?px:cx,px>=0?py:cy);td=d}}else if(ts.length<2){td=0;tt=null}},o)});
var lt=0;w.addEventListener("touchend",function(e){var s=e.timeStamp;if(s-lt<300&&e.cancelable&&e.changedTouches.length===1){var c=e.target;if(c&&c.closest&&c.closest("canvas"))e.preventDefault()}lt=s},o);
document.documentElement.dataset.pageZoomGuard="on";if(dbg)w.addEventListener("load",function(){log("debugInput ready: views="+T.length)})})()}catch(e){}`;

type PinchFn = (ratio: number, clientX: number, clientY: number) => void;
/** Lets the page guard send a Safari pinch (scale ratio since the last step) to this element. Returns the remover. */
export function registerPinchTarget(el: Element, fn: PinchFn): () => void {
  const reg = (globalThis as { __pcPinch?: { add: (el: Element, fn: PinchFn) => () => void } }).__pcPinch;
  return reg ? reg.add(el, fn) : () => {};
}

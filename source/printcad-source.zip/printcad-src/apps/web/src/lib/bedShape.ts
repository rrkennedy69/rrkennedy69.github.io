import * as THREE from "three";
import { BED_SHAPE_FILES } from "@/lib/bedShapes.generated";

/**
 * The real outline of a printer's build plate (tab, slot, notches, cut-outs), drawn under the
 * printable area. Shapes come from OrcaSlicer's bed models (AGPL-3.0) as small JSON files in
 * public/beds, fetched the first time a printer is shown. Geometry only: no text or logos.
 */
type Ring = number[][];
type Poly = { outer: Ring; holes: Ring[] };
export type BedShapeData = { source: string; bottom: number; outline: Poly; levels: Array<{ z: number; polys: Poly[] }> };

const cache = new Map<string, Promise<BedShapeData | null>>();
export function bedShapeFile(printerId: string | null | undefined) {
  return printerId ? BED_SHAPE_FILES[printerId] ?? null : null;
}
export function loadBedShape(printerId: string | null | undefined): Promise<BedShapeData | null> {
  const file = bedShapeFile(printerId);
  if (!file) return Promise.resolve(null);
  let pending = cache.get(file);
  if (!pending) {
    pending = fetch(`/beds/${file}`).then((r) => (r.ok ? r.json() : null)).catch(() => null);
    cache.set(file, pending);
  }
  return pending;
}

/** Bed millimetres (0,0 = front left of the printable area) → plate plane coordinates centred on it. */
function toShape(poly: Poly, width: number, depth: number) {
  const pt = ([x, y]: number[]) => new THREE.Vector2(x - width / 2, y - depth / 2);
  const shape = new THREE.Shape(poly.outer.map(pt));
  poly.holes.forEach((h) => shape.holes.push(new THREE.Path(h.map(pt))));
  return shape;
}

export type BedLook = { plate: string; rim: string; outline: string };

/** A rounded plate a little larger than the printable area, for printers without a bed model. */
export function fallbackBedShape(width: number, depth: number): BedShapeData {
  const m = 6, r = 8, pts: Ring = [];
  const box = [-m, -m, width + m, depth + m];
  const corners = [[box[2] - r, box[1] + r, -90], [box[2] - r, box[3] - r, 0], [box[0] + r, box[3] - r, 90], [box[0] + r, box[1] + r, 180]];
  corners.forEach(([cx, cy, a0]) => { for (let i = 0; i <= 6; i += 1) { const a = ((a0 + i * 15) * Math.PI) / 180; pts.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]); } });
  return { source: "", bottom: -2, outline: { outer: pts, holes: [] }, levels: [] };
}

/** A group lying in the plate plane (XY, +Z up toward the viewer), to add under the printable surface. */
export function buildBedShape(data: BedShapeData, width: number, depth: number, look: BedLook, shadows: boolean) {
  const group = new THREE.Group();
  group.name = "BuildPlateModel";
  const thickness = Math.max(1.5, Math.min(4, -data.bottom || 2));
  const slab = new THREE.Mesh(
    new THREE.ExtrudeGeometry(toShape(data.outline, width, depth), { depth: thickness, bevelEnabled: false, curveSegments: 4 }),
    new THREE.MeshStandardMaterial({ color: look.rim, roughness: 0.55, metalness: 0.15, polygonOffset: true, polygonOffsetFactor: 2, polygonOffsetUnits: 24 }),
  );
  slab.position.z = -thickness - 0.15;
  slab.receiveShadow = shadows;
  group.add(slab);
  const lineMaterial = new THREE.LineBasicMaterial({ color: look.outline, transparent: true, opacity: 0.9, depthWrite: false });
  const addRing = (ring: Ring, z: number) => {
    const points = ring.map(([x, y]) => new THREE.Vector3(x - width / 2, y - depth / 2, z));
    points.push(points[0].clone());
    group.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points), lineMaterial));
  };
  addRing(data.outline.outer, -0.12);
  data.outline.holes.forEach((h) => addRing(h, -0.12));
  // Raised strips and recesses of the model: their edges, faintly.
  const detail = new THREE.LineBasicMaterial({ color: look.outline, transparent: true, opacity: 0.45, depthWrite: false });
  data.levels.forEach((level) => level.polys.forEach((p) => [p.outer, ...p.holes].forEach((ring) => {
    const points = ring.map(([x, y]) => new THREE.Vector3(x - width / 2, y - depth / 2, -0.1));
    points.push(points[0].clone());
    group.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points), detail));
  })));
  return group;
}

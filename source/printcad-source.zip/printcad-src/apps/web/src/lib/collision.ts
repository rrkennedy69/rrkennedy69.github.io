import { useSyncExternalStore } from "react";
import { meshAabb } from "./editorMeshCore";
import type { WorkplaneShape } from "@/types/layerling";

/** Collision (Manage → Collision): a moved part stops flush against solid parts instead of passing through. */
export const COLLISION_STORAGE_KEY = "printcad.collision.v1";
const listeners = new Set<() => void>();
let cached: boolean | null = null;

export function collisionEnabled(): boolean {
  if (cached !== null) return cached;
  try {
    cached = typeof window !== "undefined" && window.localStorage.getItem(COLLISION_STORAGE_KEY) === "1";
  } catch {
    cached = false;
  }
  return cached;
}

export function setCollisionEnabled(on: boolean) {
  cached = on;
  try { window.localStorage.setItem(COLLISION_STORAGE_KEY, on ? "1" : "0"); } catch { /* private mode */ }
  listeners.forEach((listener) => listener());
}

export function useCollisionEnabled() {
  return useSyncExternalStore(
    (listener) => { listeners.add(listener); return () => listeners.delete(listener); },
    collisionEnabled,
    () => false,
  );
}

type Box = { minX: number; maxX: number; minY: number; maxY: number; minZ: number; maxZ: number };
const EPS = 1e-6;
const AXES = [["minX", "maxX"], ["minZ", "maxZ"], ["minY", "maxY"]] as const;

/**
 * Moves `before` towards `after` (only x, z and elevation are swept) one axis at a time and
 * stops each axis flush at the first solid obstacle (holes, hidden parts and `ignore` don't
 * block). Obstacles it already overlaps at the start don't hold it, so a part can always get free.
 */
export function collideMove(
  shapes: readonly WorkplaneShape[],
  before: WorkplaneShape,
  after: WorkplaneShape,
  ignore: ReadonlySet<string> = new Set(),
): WorkplaneShape {
  const delta = [after.x - before.x, after.z - before.z, (after.elevation ?? 0) - (before.elevation ?? 0)];
  if (delta.every((d) => Math.abs(d) < EPS)) return after;
  const start = meshAabb(before);
  const obstacles: Box[] = shapes
    .filter((shape) => shape.id !== before.id && !ignore.has(shape.id) && !shape.hole && !shape.hidden)
    .map((shape) => meshAabb(shape))
    .filter((ob) => !overlaps(start, ob));
  const box: Box = { ...start };
  const moved = [0, 0, 0];
  AXES.forEach(([lo, hi], axis) => {
    let d = delta[axis];
    if (Math.abs(d) < EPS) return;
    for (const ob of obstacles) {
      const others = AXES.filter((_, i) => i !== axis);
      if (!others.every(([l, h]) => box[l] < ob[h] - EPS && box[h] > ob[l] + EPS)) continue;
      if (d > 0 && box[hi] <= ob[lo] + EPS && box[hi] + d > ob[lo]) d = Math.max(0, ob[lo] - box[hi]);
      if (d < 0 && box[lo] >= ob[hi] - EPS && box[lo] + d < ob[hi]) d = Math.min(0, ob[hi] - box[lo]);
    }
    box[lo] += d;
    box[hi] += d;
    moved[axis] = d;
  });
  return { ...after, x: before.x + moved[0], z: before.z + moved[1], elevation: (before.elevation ?? 0) + moved[2] };
}

function overlaps(a: Box, b: Box) {
  return AXES.every(([l, h]) => a[l] < b[h] - EPS && a[h] > b[l] + EPS);
}

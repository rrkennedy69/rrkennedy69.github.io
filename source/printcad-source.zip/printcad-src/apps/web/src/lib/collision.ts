import { useSyncExternalStore } from "react";
import { meshAabb } from "./editorMeshCore";
import type { WorkplaneShape } from "@/types/layerling";

/** Collision (Manage → Collision): a moved part stops flush against solid parts instead of passing through. */
export const COLLISION_STORAGE_KEY = "printcad.collision.v1";
const listeners = new Set<() => void>();
let cached: boolean | null = null;

export function collisionEnabled(): boolean {
  if (cached !== null) return cached;
  try {
    cached = typeof window !== "undefined" && window.localStorage.getItem(COLLISION_STORAGE_KEY) === "1";
  } catch {
    cached = false;
  }
  return cached;
}

export function setCollisionEnabled(on: boolean) {
  cached = on;
  try { window.localStorage.setItem(COLLISION_STORAGE_KEY, on ? "1" : "0"); } catch { /* private mode */ }
  listeners.forEach((listener) => listener());
}

export function useCollisionEnabled() {
  return useSyncExternalStore(
    (listener) => { listeners.add(listener); return () => listeners.delete(listener); },
    collisionEnabled,
    () => false,
  );
}

type Box = { minX: number; maxX: number; minY: number; maxY: number; minZ: number; maxZ: number };
const EPS = 1e-6;
const AXES = [["minX", "maxX"], ["minZ", "maxZ"], ["minY", "maxY"]] as const;

/**
 * Moves `before` towards `after` (only x, z and elevation are swept) one axis at a time and
 * stops each axis flush at the first solid obstacle (holes, hidden parts and `ignore` don't
 * block). Obstacles it already overlaps at the start don't hold it, so a part can always get free.
 */
export function collideMove(
  shapes: readonly WorkplaneShape[],
  before: WorkplaneShape,
  after: WorkplaneShape,
  ignore: ReadonlySet<string> = new Set(),
): WorkplaneShape {
  const delta = [after.x - before.x, after.z - before.z, (after.elevation ?? 0) - (before.elevation ?? 0)];
  if (delta.every((d) => Math.abs(d) < EPS)) return after;
  const start = meshAabb(before);
  const obstacles: Box[] = shapes
    .filter((shape) => shape.id !== before.id && !ignore.has(shape.id) && !shape.hole && !shape.hidden)
    .map((shape) => meshAabb(shape))
    .filter((ob) => !overlaps(start, ob));
  const box: Box = { ...start };
  const moved = [0, 0, 0];
  AXES.forEach(([lo, hi], axis) => {
    let d = delta[axis];
    if (Math.abs(d) < EPS) return;
    for (const ob of obstacles) {
      const others = AXES.filter((_, i) => i !== axis);
      if (!others.every(([l, h]) => box[l] < ob[h] - EPS && box[h] > ob[l] + EPS)) continue;
      if (d > 0 && box[hi] <= ob[lo] + EPS && box[hi] + d > ob[lo]) d = Math.max(0, ob[lo] - box[hi]);
      if (d < 0 && box[lo] >= ob[hi] - EPS && box[lo] + d < ob[hi]) d = Math.min(0, ob[hi] - box[lo]);
    }
    box[lo] += d;
    box[hi] += d;
    moved[axis] = d;
  });
  return { ...after, x: before.x + moved[0], z: before.z + moved[1], elevation: (before.elevation ?? 0) + moved[2] };
}

function overlaps(a: Box, b: Box) {
  return AXES.every(([l, h]) => a[l] < b[h] - EPS && a[h] > b[l] + EPS);
}

function shapeOverlapsAny(shape: WorkplaneShape, obstacles: Box[]) {
  const box = meshAabb(shape);
  return obstacles.some((ob) => overlaps(box, ob));
}

/**
 * Collision for any change (Manage → Collision): parts whose position or size changed between
 * `before` and `after` stop at contact with the parts that did not change. A move stops flush
 * (collideMove); a resize clamps each growing face at the contact plane. Whatever is left that
 * would still overlap a part it did not overlap before falls back to the last position that
 * did not, so a part never ends up inside another. Holes and hidden parts don't block.
 */
export function enforceCollision(before: readonly WorkplaneShape[], after: readonly WorkplaneShape[]): WorkplaneShape[] {
  const old = new Map(before.map((shape) => [shape.id, shape]));
  const changed = new Set(after.filter((shape) => {
    const b = old.get(shape.id);
    return b && (b.x !== shape.x || b.z !== shape.z || (b.elevation ?? 0) !== (shape.elevation ?? 0)
      || b.width !== shape.width || b.depth !== shape.depth || b.height !== shape.height);
  }).map((shape) => shape.id));
  if (!changed.size) return after as WorkplaneShape[];
  const fixed = after.filter((shape) => !changed.has(shape.id));
  let touched = false;
  const result = after.map((shape) => {
    if (!changed.has(shape.id)) return shape;
    const b = old.get(shape.id)!;
    const startBox = meshAabb(b);
    const obstacles = fixed.filter((o) => !o.hole && !o.hidden).map((o) => meshAabb(o)).filter((ob) => !overlaps(startBox, ob));
    if (!obstacles.length) return shape;
    // 1. the move, at the old size
    const moved = settleMove(fixed, b, { ...b, x: shape.x, z: shape.z, elevation: shape.elevation }, new Set(changed));
    let next: WorkplaneShape = { ...shape, x: moved.x, z: moved.z, elevation: moved.elevation };
    // 2. the resize: clamp the faces that grew
    const from = meshAabb({ ...b, x: moved.x, z: moved.z, elevation: moved.elevation });
    const to = meshAabb(next);
    const clamped: Box = { ...to };
    AXES.forEach(([lo, hi], axis) => {
      const others = AXES.filter((_, i) => i !== axis);
      for (const ob of obstacles) {
        if (!others.every(([l, h]) => to[l] < ob[h] - EPS && to[h] > ob[l] + EPS)) continue;
        if (to[hi] > from[hi] + EPS && from[hi] <= ob[lo] + EPS && clamped[hi] > ob[lo]) clamped[hi] = Math.max(from[hi], ob[lo]);
        if (to[lo] < from[lo] - EPS && from[lo] >= ob[hi] - EPS && clamped[lo] < ob[hi]) clamped[lo] = Math.min(from[lo], ob[hi]);
      }
    });
    if (AXES.some(([lo, hi]) => Math.abs(clamped[lo] - to[lo]) > EPS || Math.abs(clamped[hi] - to[hi]) > EPS)) {
      const quarter = Math.round(((((shape.rotation ?? 0) % 180) + 180) % 180) / 90) === 1;
      const ext = (box: Box, [lo, hi]: readonly [keyof Box, keyof Box]) => box[hi] - box[lo];
      const k = AXES.map((axis) => ext(to, axis) > EPS ? ext(clamped, axis) / ext(to, axis) : 1);
      const [kx, kz, ky] = [k[0], k[1], k[2]];
      next = {
        ...next,
        width: next.width * (quarter ? kz : kx),
        depth: next.depth * (quarter ? kx : kz),
        height: next.height * ky,
      };
      const re = meshAabb(next);
      next = {
        ...next,
        x: next.x + (clamped.minX + clamped.maxX - re.minX - re.maxX) / 2,
        z: next.z + (clamped.minZ + clamped.maxZ - re.minZ - re.maxZ) / 2,
        elevation: (next.elevation ?? 0) + clamped.minY - re.minY,
      };
    }
    // 3. never end inside another part
    if (shapeOverlapsAny(next, obstacles)) {
      const sizeOnly = { ...b, x: moved.x, z: moved.z, elevation: moved.elevation };
      next = shapeOverlapsAny(sizeOnly, obstacles) ? b : { ...shape, ...sizeOnly };
    }
    if (next !== shape) touched = true;
    return next;
  });
  return touched ? result : (after as WorkplaneShape[]);
}

/**
 * One step of a live drag with Collision on: the dragged parts (`movers`, at where they are
 * now) try to go `delta` further. Each axis is cut back to the shortest distance any mover can
 * travel before touching a solid part, so the group stops flush and slides along the face.
 */
export function collideDragStep(
  shapes: readonly WorkplaneShape[],
  movers: readonly WorkplaneShape[],
  delta: { dx: number; dy: number; dz: number },
): { dx: number; dy: number; dz: number } {
  const ignore = new Set(movers.map((m) => m.id));
  const out = { ...delta };
  for (const m of movers) {
    const r = collideMove(shapes, m, { ...m, x: m.x + delta.dx, z: m.z + delta.dz, elevation: (m.elevation ?? 0) + delta.dy }, ignore);
    const ax = r.x - m.x, az = r.z - m.z, ay = (r.elevation ?? 0) - (m.elevation ?? 0);
    if (Math.abs(ax) < Math.abs(out.dx)) out.dx = ax;
    if (Math.abs(az) < Math.abs(out.dz)) out.dz = az;
    if (Math.abs(ay) < Math.abs(out.dy)) out.dy = ay;
  }
  const obstacles = shapes.filter((s) => !ignore.has(s.id) && !s.hole && !s.hidden).map((s) => meshAabb(s));
  const fits = (d: typeof out) => movers.every((m) => {
    const start = meshAabb(m);
    const free = obstacles.filter((ob) => !overlaps(start, ob));
    return !shapeOverlapsAny({ ...m, x: m.x + d.dx, z: m.z + d.dz, elevation: (m.elevation ?? 0) + d.dy }, free);
  });
  if (fits(out)) return out;
  for (const keep of [{ ...out, dz: 0 }, { ...out, dx: 0 }, { ...out, dx: 0, dz: 0 }]) if (fits(keep)) return keep;
  return { dx: 0, dy: 0, dz: 0 };
}

/**
 * A move that lands somewhere free is kept as it is (a live drag already went around what was
 * in the way); only a landing inside a solid part is swept back to the contact face.
 */
export function settleMove(
  shapes: readonly WorkplaneShape[],
  before: WorkplaneShape,
  after: WorkplaneShape,
  ignore: ReadonlySet<string> = new Set(),
): WorkplaneShape {
  const start = meshAabb(before);
  const free = shapes
    .filter((shape) => shape.id !== before.id && !ignore.has(shape.id) && !shape.hole && !shape.hidden)
    .map((shape) => meshAabb(shape))
    .filter((ob) => !overlaps(start, ob));
  return shapeOverlapsAny(after, free) ? collideMove(shapes, before, after, ignore) : after;
}

/** Whether any of `ids` sits inside a solid part outside `ids` (used by the drag test probe). */
export function solidOverlap(shapes: readonly WorkplaneShape[], ids: readonly string[]): boolean {
  const set = new Set(ids);
  const obstacles = shapes.filter((s) => !set.has(s.id) && !s.hole && !s.hidden).map((s) => meshAabb(s));
  return shapes.some((s) => set.has(s.id) && shapeOverlapsAny(s, obstacles));
}

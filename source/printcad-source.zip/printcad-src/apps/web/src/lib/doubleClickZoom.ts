import { useSyncExternalStore } from "react";

/** Double-click to zoom (left rail): double-click or double-tap a body to frame it. On by default. */
export const DBL_ZOOM_STORAGE_KEY = "printcad.doubleClickZoom.v1";
const listeners = new Set<() => void>();
let cached: boolean | null = null;

export function dblZoomOn(): boolean {
  if (cached !== null) return cached;
  try { cached = typeof window === "undefined" || window.localStorage.getItem(DBL_ZOOM_STORAGE_KEY) !== "0"; } catch { cached = true; }
  return cached;
}

export function setDblZoomOn(on: boolean) {
  cached = on;
  try { window.localStorage.setItem(DBL_ZOOM_STORAGE_KEY, on ? "1" : "0"); } catch { /* private mode */ }
  listeners.forEach((listener) => listener());
}

export function useDblZoomOn() {
  return useSyncExternalStore((l) => { listeners.add(l); return () => listeners.delete(l); }, dblZoomOn, () => true);
}

const SUPPORTED_IMPORT_EXTENSIONS = new Set(["stl", "obj", "svg", "3mf", "dxf"]);

function fileExtension(fileName: string) {
  return fileName.split(".").pop()?.toLowerCase() ?? "";
}

export function importExtensionSupported(fileName: string) {
  return SUPPORTED_IMPORT_EXTENSIONS.has(fileExtension(fileName));
}
